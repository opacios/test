<?php
/**
 * Created by PhpStorm.
 * User: mfosso
 * Date: 05/06/2018
 * Time: 08:00
 */

namespace Drupal\santander_products\Feeds\Processor\Form;

use Drupal\feeds\Feeds\Processor\Form\DefaultEntityProcessorForm;

class ProductDefaultEntityProcessorForm extends DefaultEntityProcessorForm{

}