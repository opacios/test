<?php
/**
 * Created by PhpStorm.
 * User: mfosso
 * Date: 05/06/2018
 * Time: 07:58
 */

namespace Drupal\santander_products\Feeds\Processor\Form;

use  Drupal\feeds\Feeds\Processor\Form\EntityProcessorOptionForm;

class ProductEntityProcessorOptionForm extends EntityProcessorOptionForm{

}