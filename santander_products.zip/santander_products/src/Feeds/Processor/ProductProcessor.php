<?php
/**
 * Created by PhpStorm.
 * User: mfosso
 * Date: 05/06/2018
 * Time: 04:43
 */

namespace Drupal\santander_products\Feeds\Processor;

use Drupal\feeds\Feeds\Processor\EntityProcessorBase;

/**
 * Defines a product processor.
 *
 * Creates products (rates) from feed items.
 *
 * @FeedsProcessor(
 *   id = "entity:product",
 *   title = @Translation("Product"),
 *   description = @Translation("Creates products from feed items."),
 *   entity_type = "product",
 *   arguments = {"@entity_type.manager", "@entity.query", "@entity_type.bundle.info"},
 *   form = {
 *     "configuration" = "Drupal\santander_products\Feeds\Processor\Form\ProductDefaultEntityProcessorForm",
 *     "option" = "Drupal\santander_products\Feeds\Processor\Form\ProductEntityProcessorOptionForm",
 *   },
 * )
 */

class ProductProcessor extends EntityProcessorBase{
  /**
   * {@inheritdoc}
   */
  public function entityLabel() {
    return $this->t('Product');
  }

  /**
   * {@inheritdoc}
   */
  public function entityLabelPlural() {
    return $this->t('Products');
  }
}