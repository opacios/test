<?php

namespace Drupal\santander_products\Form;

use Drupal\Core\Entity\ContentEntityDeleteForm;

/**
 * Provides a form for deleting Product entities.
 *
 * @ingroup santander_products
 */
class ProductDeleteForm extends ContentEntityDeleteForm {


}
