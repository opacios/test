<?php

namespace Drupal\santander_products;

use Drupal\content_translation\ContentTranslationHandler;

/**
 * Defines the translation handler for product.
 */
class ProductTranslationHandler extends ContentTranslationHandler {

  // Override here the needed methods from ContentTranslationHandler.

}
