 ;(function($) {

   var calcMorgagesComp = {

     $step1Container : null,
     $step2Container : null,
     $step3Container : null,
     $step4Container : null,

     step2Initialized : false,
     step3Initialized : false,
     step4Initialized : false,
     
     $importantInfo : null,

     currentStep : 1,
     originalTable : null,
     limit: 0,
     repExampleMnid: 0,
     sorted: false,
     largeLoanThreshold: 0,

     type : '',
     property : 0,
     borrow : 0,
     years : 0,
     san_select : 0,
     htb_exclusive : 0,
     loan : 0,
     showAll : true,

     typeOptions : {
       mover : 'Moving home',
       ftb : 'First time buyer',
       remortgage : 'Remortgaging to us'
     },

     init: function () {
       var that = this;
       sCalculator.initTooltips();

       this.$step1Container = $(".calc-steps .step_1");
       this.$step2Container = $(".calc-steps .step_2");
       this.$step3Container = $(".calc-steps .step_3");
       this.$step4Container = $(".calc-steps .step_4");


       this.$importantInfo = $("#block-system-main .field-name-field-important-info");
       if(this.$importantInfo.length) {
         var impInfoHtml = this.$importantInfo.html();
         if(impInfoHtml.indexOf('<p><!--break--></p>') > 0) {
           impInfoHtml = '<div class="imp_info_s_1">' + impInfoHtml.replace('<p><!--break--></p>', '</div><div class="imp_info_s_2" style="display: none;">') + '</div>';
           this.$importantInfo.html(impInfoHtml);
         }
       }

       this.step1Init();


       //to do .. comment this
       //$(".agree_step").addClass("non_active");
       //$(".calc-steps").addClass("active");
       //this.step2SetActive();
     },//end init

     importantInfoUpdate : function() {
       if(this.currentStep <= 1) {
         $(".imp_info_s_1", this.$importantInfo).show();
         $(".imp_info_s_2", this.$importantInfo).hide();
       }
       else {
         $(".imp_info_s_1", this.$importantInfo).hide();
         $(".imp_info_s_2", this.$importantInfo).show();
       }
     },


     //mortgage step
     step1Init : function() {
       var that = this;

       $(".flat-checkbox span").click(function(){
         var $container = $(this).parent();
         $("span", $container).removeClass('active');
         $(this).addClass("active");

         if($container.data('name')) {
           var name = $container.data('name');
           $container.addClass('value-set');
           switch(name) {
             case 'san_select':
             case 'htb_exclusive':
             //case 'current_account':
               that[name] = $(this).data('value');
               that.step1OnChangeValue();
               break;
           }
         }
       });

       $("#btype").change(function() {
         that.type = $(this).val();
         that.step1OnChangeValue();
       }).trigger('change');

       $("#mortgage-years")
         .val(25)
         .change(function() {
           that.years = $(this).val();
           that.step1OnChangeValue();
         })
         .trigger('change');


       $("#field-property")
         .on('change keyup', function() {
           var v = sCalculator.getNumericFieldVal($(this));
           var valueSet = false;
           if(!isNaN(v)) {
             that.property = v;
             if(v > 0) valueSet = true;
           }
           else {
             that.property = 0;
           }
           $(this)[ valueSet ? 'addClass' : 'removeClass' ]('value-set');

           that.step1OnChangeValue();
         })
         .numericField({decimalPlaces: 0, negative: false});

       $("#field-borrow")
         .on('change keyup', function() {
           var v = sCalculator.getNumericFieldVal($(this));
           var valueSet = false;
           if(!isNaN(v)) {
             that.borrow = v;
             if(v > 0) valueSet = true;
           }
           else {
             that.borrow = 0;
           }
           $(this)[ valueSet ? 'addClass' : 'removeClass' ]('value-set');

           that.step1OnChangeValue();
         })
         .numericField({decimalPlaces: 0, negative: false});
       
       $("#field-borrow")
       	.on('customShowTooltip', function() {
       		if($("#tooltip-field-borrow").is(':hidden')) 
       			$("#tooltip-field-borrow").siblings('span').click();
       	});

       $(".btn-next", this.$step1Container).click(function() {
         if(!$(this).hasClass('disabled')) {
           that.step2SetActive();
           that.resetMortgageList();
         }
       });

     },

     step1SetActive : function() {
       this.currentStep = 1;
       this.importantInfoUpdate();

       $(".calc-steps .calc-step").removeClass("active");
       $(".calc-steps .step_1").addClass("active");

       $('html, body').animate({
         scrollTop: $("#borrow-compmortgage").offset().top
       }, 100);
     },

     step1OnChangeValue : function() {
       if($(".value-set", this.$step1Container).length == 4 && $("#btype").val()) {
         $(".btn-next", this.$step1Container).removeClass('disabled');
       }
       else {
         $(".btn-next", this.$step1Container).addClass('disabled');
       }
     },


     onFilterChange : function() {
       var that = this;
       var type = $("#filter-type").val(),
         ltv = $("#filter-ltv").val(),
         period = $("#filter-initperiod").val();

       var allVisible = true;
       var visibleRowsNo = 0;
       var mobileInd = 0;
       var totalRows = 0;
       $(".mortgages-table .r").each(function() {
         if($(this).hasClass('not-eligible')) return;

         mobileInd ++;

         var showRow = true;
         if(type && $(this).data('ptype') != type) {
           showRow = false;
         }
         else if(ltv && $(".td-max-ltv", this).html() != ltv) {
           showRow = false;
         }
         else if(period && $(this).data('period') != period) {
        	 if(period == '2y' && $(this).data('period') == '18mo') {
        		 showRow = true;
        	 }
        	 else {
        		 showRow = false;
        	 }
         }
         if(!showRow) allVisible = false;

         if(showRow)  visibleRowsNo ++;
         
         $(this)[showRow && visibleRowsNo <= that.limit ? 'addClass' : 'removeClass' ]('mobile-display');

         $(this)[showRow ? 'show' : 'hide' ]();
         
         if(!showRow) {
           if($('.check-td input:checked', $(this)).length) {
             $('.check-td input:checked', $(this)).prop("checked", false);
           }
         }
       });
       if($(".mortgages-table .eligible").length == 0 && $("#comp-mortgage-no-results").length == 0) {
    	   $(".mortgages-table thead").hide();
    	   $(".show-all-btn").hide();
    	   $(".res-table-c h3").hide();
    	   $(".table-filter").hide();
   		   $("table.selections").after('<div id="comp-mortgage-no-results" style="display: block; color: #f00; margin: 10px 0 0 0;"><p>We don\'t currently have any mortgages available based on your estimated property value and how much you want to borrow. Please change what you\'re looking for if you wish to compare our mortgage rates.</p></div>');
    	   $("#borrow-compmortgage.node-compmorgage .calc-steps .step_2 .res-table-c").css("padding", '0');
    	   $("#comp-mortgage-no-results").show();
       }
       else {
    	   if($("#comp-mortgage-no-results").length > 0) {
    		   $("#comp-mortgage-no-results").remove();
    		   $("#borrow-compmortgage.node-compmorgage .calc-steps .step_2 .res-table-c").css("padding", '40px 0');
    		   $(".res-table-c h3").show();
    		   $(".table-filter").show();
    		   $(".mortgages-table thead").show();
        	   $(".show-all-btn").show();
    		   $(".mortgages-table tbody").html(that.originalTable);
    		   that.resetMortgageList();
    	   }
       }
     },

     //income step
     step2Init : function() {
       var that = this;

       this.step2Initialized = true;
       

       that.showAll = false;
       $(".show-all-btn", this.$step2Container).html(that.showAll ? 'Show less' : 'Show all');

       //filters
       $("#filter-type, #filter-ltv, #filter-initperiod").change(function() {
           console.log(that.originalTable);
    	 $(".mortgages-table tbody").html(that.originalTable);
    	 that.onFilterChange();
    	 that.resetMortgageList();
    	 that.removeDuplicates();
       });


       $(".show-all-btn", this.$step2Container).click(function() {
         that.showAll = !that.showAll;
         $(".show-all-btn", this.$step2Container).html(that.showAll ? 'Show less' : 'Show all');

         that.onFilterChange();
         
         if(!that.showAll) {
           that.resetMortgageList();
	       $('html, body').animate({
	         scrollTop: $(".res-table-c").offset().top - 100
	       }, 50);
         }
         else {
      	   $(".mortgages-table tbody").html(that.originalTable);
      	   that.resetMortgageList();
         }
         
         that.removeDuplicates();
         return false;
       });
       

       $(".mortgages-table").on('click', 'input[type=checkbox]', function() {
         var checkedNo = $(".mortgages-table input:checked").length;
         if( checkedNo > 3) {
           this.checked = false;
         }
         $(".btn-next", this.$step2Container)[ checkedNo < 1 ? 'addClass' : 'removeClass' ]('disabled');
       });

       $(".btn-back", this.$step2Container).click(function() {
         that.step1SetActive();
         $(".nav-pills li:nth-child(2)", this.$step2Container).removeClass('checked').addClass('active');
         $(".nav-pills li:last-child", this.$step2Container).removeClass('active');
         $(".next-steps", this.$step2Container).addClass('visible-lg-block');
         $(".res-table-c", this.$step2Container).show();
         $(".btn-mobile-next", this.$step2Container).attr('style', '');

         $("#filter-type, #filter-initperiod, #filter-ltv").val("");
       });

       $(".btn-next", this.$step2Container).click(function() {
         if(!$(this).hasClass('disabled')) {
           that.step3SetActive();
         }
       });
       $(".btn-table-back", this.$step2Container).click(function() {
    	 $(".mortgages-table, .show-all-btn, .btn-next, .table-filter, .rep-title, .representative-examples, .rep-info, .res-table-c > h3", this.$step2Container).show();
    	 $(".btn-back, .btn-comp", this.$step2Container).attr('style', '');
         $(".mortgages-comp-table, .btn-table-back", that.$step2Container).hide();
       });

       var headArr = [];
       $(".mortgages-table .h-row th").each(function() {
         headArr.push($(this).html());
       });

       $('.mortgages-table').on('click', 'tr.r th', function(event){
    	 if($(event.target).hasClass("online-exclusive-anchor") && $("#online-exclusive-text").length) {
    		 $('html, body').animate({
           	  scrollTop: $("#online-exclusive-text").offset().top
           	}, 50);
    		 return true;
         }
    	 
    	 if($(event.target).hasClass("select-exclusive-anchor") && $("#select-exclusive-text").length) {
    		 $('html, body').animate({
           	  scrollTop: $("#select-exclusive-text").offset().top - 100
           	}, 50);
    		 return true;
         }
    	 if($(event.target).hasClass("htb-exclusive-anchor") && $("#htb-exclusive-text").length) {
    		 $('html, body').animate({
              	  scrollTop: $("#htb-exclusive-text").offset().top - 100
              	}, 50);
    		 return true;
         }
    	 
         $(this).toggleClass('active');
         $(this).siblings('.mortgages-table tr.r td').toggleClass('active')
           .each(function(ind) {
             if(!$(this).data("colheadadded")) {
               $(this).prepend('<div class="mobile-col-head visible-xs-block visible-sm-block">' + headArr[ind + 1] + '</div>');
               $(this).data("colheadadded", 1);
             }
         });
       });

       $(".btn-mobile-next", this.$step2Container).click(function() {
         $(".res-table-c", this.$step2Container).hide();
         $(".nav-pills .active", this.$step2Container).removeClass('active').addClass('checked');
         $(".nav-pills li:last-child", this.$step2Container).addClass('active');
         $(".next-steps", this.$step2Container).removeClass('visible-lg-block');
         $('html, body').animate({
           scrollTop: $(".next-steps", this.$step2Container).offset().top - 50
         }, 100);
         $(".btn-mobile-next", this.$step2Container).attr('style', 'display:none !important');
       });
     },

     resetMortgageList : function() {
       var that = this;
       
       $(".mortgages-table .r").each(function() {
         var data = $(this).data();
         //check if is buyer
         if (that.isBuyer(data.ctype) && that.isRange(data.min, data.max) && that.isLTVrange(data.ltv) && that.isEligible(data.eligibility)) {
           $(this).removeClass('not-eligible mobile-display').addClass('eligible');
         }
         else {
           $(this).addClass('not-eligible').removeClass('eligible');
           $('.check-td input:checked', $(this)).prop("checked", false);
         }
       });
       that.originalTable = $($(".mortgages-table tbody").get(0)).html();
       if(!that.showAll)
    	   that.sort_table();
       $(".mortgages-table .eligible").removeClass('odd');
       $(".mortgages-table .eligible").each(function(ind) {
         if(ind % 2 == 1) $(this).addClass('odd');
       })
       this.onFilterChange();
     },

     // Is buyer type
     isBuyer: function(a) {
       a = a.replace(new RegExp(',', 'g'), '|');
       a = a.replace('and', '|');
       a = a.replace('&', '|');
       a = a.replace(new RegExp(' ', 'g'), '');

       var exp = new RegExp(a);
       return this.type.match(exp);
     },
     // Is on range
     isRange: function(min, max) {
       return (this.borrow >= min && this.borrow <= max) ? true : false;
     },
     // Is on the LTV range
     isLTVrange: function(n) {
       n = Math.round( (parseFloat(n) * 100)) / 100;
       return n >= this.loan;
     },
     isEligible: function(s) {
       if (s.replace(/ /g, '') == 'select') {
         return (this.san_select == 0) ? false : true;
       }
       
       if (s.replace(/ /g, '') == 'htb') {
           return (this.htb_exclusive == 0) ? false : true;
         }

       if (s.replace(/ /g, '') == 'loyalty') {
		 return (this.san_select == 0) ? false : true;
       }

       return true;
     },

     //deprecated .. moved to server side
     sort_table : function (){
       var that = this;
    //   var hasRepExample = false;
       var indexes = {}, tmpRows = [], mortgValue, eligibility, period, ptype, mNid, repExample = '', repExampleMortgValue = '', newHtml = '', count = 0;
      
       that.sorted = true;
       
     /*  if(that.htb_exclusive) {
    	   $(".mortgages-table tbody .r").each(function() {
        	   
    	     	 period = $(this).data("period");
    	      	 ptype = $(this).data("ptype");
    	      	 mNid = $(this).data("mnid");
    	      	 eligibility = $(this).data("eligibility");
    	      	  
    	      	 if(eligibility.replace(/ /g, '') != 'htb') return;
    	      	 if($(this).hasClass('not-eligible')) return;
    	    	 if($(this).is(':hidden')) {
    	    		 return;
    	    	 }
    	    	 
    	    	 
    	    	  if(!indexes[ptype]) {
    	    		  indexes[ptype] = {};
    	    	  }
    	    		
    	   		  if(!indexes[ptype][period]) {
    	   			  indexes[ptype][period] = {count: 1, markup: '', mortgValue: ''};
    	   		  }
    	    	  if(indexes[ptype][period]['count'] <= 1) {
    	    		  count += 1;
    	    		  
    	    		  mortgValue = $(this).find('.td-m-cost').html();
    	    		  mortgValue = mortgValue.replace(/£/g, "");
    	    		  mortgValue = mortgValue.replace(/,/g, "");
    	    		  mortgValue = parseFloat(mortgValue);

    	    		  indexes[ptype][period]['count'] += 1;
    	    		  indexes[ptype][period]['markup'] += this.outerHTML;
    	    		  indexes[ptype][period]['mortgValue'] = mortgValue;
    	    		 
    	    	  }
    	    	  else 
    	    		  return;
    	       });
       }*/
       $(".mortgages-table tbody .r").each(function() {
    	   
     	  period = $(this).data("period");
      	  ptype = $(this).data("ptype");
      	  mNid = $(this).data("mnid");

      	 if($(this).hasClass('not-eligible')) return;
    	 if($(this).is(':hidden')) {
    		 return;
    	 }
    	 
    	  if(!indexes[ptype]) {
    		  indexes[ptype] = {};
    	  }
    		
   		  if(!indexes[ptype][period]) {
   			  indexes[ptype][period] = {count: 1, markup: '', mortgValue: ''};
   		  }
    	  if(indexes[ptype][period]['count'] <= 1) {
    		  count += 1;
    		  
    		  mortgValue = $(this).find('.td-m-cost').html();
    		  mortgValue = mortgValue.replace(/£/g, "");
    		  mortgValue = mortgValue.replace(/,/g, "");
    		  mortgValue = parseFloat(mortgValue);

    		  indexes[ptype][period]['count'] += 1;
    		  indexes[ptype][period]['markup'] += this.outerHTML;
    		  indexes[ptype][period]['mortgValue'] = mortgValue;
    		 
    	  }
    	  else 
    		  return;
       });
       
       $.each(indexes, function(i, val){
    	   $.each(val, function(ii, ival){
    		   tmpRows.push({markup: ival['markup'], mortgValue: ival['mortgValue']});
    	   });
       });
       tmpRows = tmpRows.sort(function(a,b){
    	   return a.mortgValue - b.mortgValue;
    	   });
       $.each(tmpRows, function(i, val) {
    	  newHtml += val.markup; 
       });
       
       $(".mortgages-table tbody").html(newHtml);
       
       that.limit = count;
       
     },
     
     removeDuplicates : function() {
    	 var that = this;
    	 var seen = {};
		  
		 $('.mortgages-table .r').each(function() {
			var dt = $(this).data();
		    var prodCode = dt.prodcode;
		   	if (seen[prodCode])
		       $(this).remove();
		    else {
		       if($(this).hasClass('eligible'))
		          seen[prodCode] = true;
		    	}
		}); 
     },

     step2SetActive : function() {
       var that = this;
       var repLTV;
  
       if(!this.step2Initialized) {
         this.step2Init();
       }
       this.scrollToNextSteps();
       
       this.currentStep = 2;
       this.importantInfoUpdate();

       var v = (this.borrow / this.property) * 100;
       this.loan =  (!isNaN(parseFloat(v)) && v >= 0 && v != 'Infinity') ? v : 0;
       repLTV = this.loan;
       $(".loan-value strong", this.$step2Container).html( (Math.round((parseFloat(this.loan) * 100)) / 100) + '%');
       // Calculate monthly cost
       if(that.sorted == true)
    	   $(".mortgages-table tbody").html(that.originalTable);
       $(".mortgages-table .r").each(function() {
         var n = $(this).data('initialrate');
         n = n / 100;
         var interest = (n / 12) / (1 - (Math.pow(1 + (n / 12), (-1 * (that.years * 12)))));
         var monthlyCost = Math.round(that.borrow * interest);
         $(".td-m-cost", this).html(sCalculator.formatMoney(monthlyCost, 0));
         $(this).data('monthlyCost', monthlyCost);
         $("#comp_td_cost_" + $(this).data("mnid")).html(sCalculator.formatMoney(monthlyCost, 0));

         var finalCost = monthlyCost * 0.01 * 12;
         if(finalCost > 120) finalCost = 120;
         $("#comp_td_cost_final_" + $(this).data("mnid")).html(sCalculator.formatMoney(finalCost, 0) + ' per year');
       });
       
       $('.representative-examples').show();
  
       var showExtra = that.showRepExample();;
       that.removeDuplicates();

       if(showExtra == true) {
	       $('.rep-title').show();
	       $('.rep-info').show();
       }
       else {
	       $('.rep-title').hide();
		   $('.rep-info').hide();
		   $('.representative-examples').hide();
       }
       
       $("#res-btype").html( this.typeOptions[this.type] );
       $("#res-terms").html(this.years + ' years');
       $("#res-property").html( sCalculator.formatMoney(this.property, 0) );
       $("#res-borrow").html( sCalculator.formatMoney(this.borrow, 0) );
       $("#res-select-customer").html( this.san_select ? 'Yes' : 'No' );

       $(".calc-steps .calc-step").removeClass("active");
       $(".calc-steps .step_2").addClass("active");
      
     },
     
     scrollToNextSteps : function() {
    	 var that = this;
    	 $('html, body').animate({
             scrollTop: $(".next-steps", that.$step2Container).offset().top - 50
           }, 50); 
     },
     
     showRepExample : function() {
    	 var that = this;
    	 $(".representative-examples .representative-example").hide();
    	 if(that.isLargeLoan()) {
    		 $(".representative-examples .large-loan").show();
    		 return true;
    	 }
    	 switch(that.type) {
	    	 case 'mover':
	    	 case 'ftb':
	    		 $(".representative-examples .mover-loan").show();
	    		 return true;
	    	 /*case 'ftb':
	    		 $(".representative-examples .ftb-loan").show();
	    		 return true;*/
	    	 case 'remortgage':
	    		 $(".representative-examples .remortgage-loan").show();
	    		 return true;
    	 }
    	 return false;
     },
     
     isLargeLoan : function() {
    	var that = this;
    	var threshold = parseFloat(that.largeLoanThreshold);
    	return !!(threshold > 0 && that.borrow >= threshold);
     },

     step3SetActive : function() {
       this.currentStep = 3;

       $(".mortgages-table, .show-all-btn, .btn-back, .btn-next, .table-filter, .rep-title, .representative-examples, .rep-info, .res-table-c > h3", this.$step2Container).hide();
       $(".btn-back, .btn-comp", this.$step2Container).attr('style', 'display:none!important');


       $(".mortgages-comp-table .m-nid-col", this.$step2Container).hide();
       var cols = 0;
       $(".mortgages-table input:checked").each( function() {
         $(".mortgages-comp-table .m-nid-" + $(this).val(), this.$step2Container).show();
         cols++;
       });
       $(".mortgages-comp-table .comp_table_final_txt").attr('colspan', cols);


       $(".mortgages-comp-table, .btn-table-back", this.$step2Container).show();
       $(".calc-steps .step_2 ul.nav li:nth-child(2)").removeClass("active").addClass("checked");
       $(".calc-steps .step_2 ul.nav li:last-child").addClass("active");


       $('html, body').animate({
         scrollTop: $(".mortgages-comp-table", this.$step2Container).offset().top
       }, 100);

     }

   };

   $(document).ready(function() {
     calcMorgagesComp.init();
     
     $(".online-exclusive-anchor").click(function() {
    	if($("#online-exclusive-text").length) {
    		$('html, body').animate({
    	       	  scrollTop: $("#online-exclusive-text").offset().top
    	       	}, 50);
    	}
     }); 
     
     $(".select-exclusive-anchor").click(function() {
     	if($("#select-exclusive-text").length) {
     		$('html, body').animate({
     	       	  scrollTop: $("#select-exclusive-text").offset().top
     	       	}, 50);
     	}
      });

       $(".htb-exclusive-anchor").click(function() {
           if($("#htb-exclusive-text").length) {
               $('html, body').animate({
                   scrollTop: $("#htb-exclusive-text").offset().top
               }, 50);
           }
       });

       if($(".agree").size()) {
    	  var ref = document.referrer;
    	  if(ref.match(/how-much-can-i-borrow/i) === false) {
    		  sessionStorage.removeItem('checkboxClicked');
    	  }
    	  var checkboxClicked = sessionStorage.getItem('checkboxClicked');
    	  var hideAgreeCheckbox = (ref.match(/how-much-can-i-borrow/i) && checkboxClicked);
    	  if(hideAgreeCheckbox) {
    		  $(".agree_step").addClass("non_active");
    		  $(".calc-steps").addClass("active");
    		  calcMorgagesComp.step1SetActive();
    	  }
        $(".agree input[type=checkbox]").click(function() {
            $(".btn", $(this).closest('.agree'))[ this.checked ? 'removeClass' : 'addClass' ]('disabled');
        });

        $(".agree .btn").click(function(){
          if(!$(this).hasClass('disabled')) {
            $(".agree_step").addClass("non_active");
            $(".calc-steps").addClass("active");
            sessionStorage.setItem('checkboxClicked', true);
            calcMorgagesComp.step1SetActive();
          }
        });
      }
   });
   
})(jQuery);
