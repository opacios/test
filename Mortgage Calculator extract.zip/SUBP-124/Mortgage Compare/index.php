<!DOCTYPE HTML>
<html lang="en-gb" dir="ltr">
<head>
    <meta charset="utf-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" /><script type="text/javascript">window.NREUM||(NREUM={}),__nr_require=function(e,t,n){function r(n){if(!t[n]){var o=t[n]={exports:{}};e[n][0].call(o.exports,function(t){var o=e[n][1][t];return r(o||t)},o,o.exports)}return t[n].exports}if("function"==typeof __nr_require)return __nr_require;for(var o=0;o<n.length;o++)r(n[o]);return r}({1:[function(e,t,n){function r(){}function o(e,t,n){return function(){return i(e,[f.now()].concat(u(arguments)),t?null:this,n),t?void 0:this}}var i=e("handle"),a=e(2),u=e(3),c=e("ee").get("tracer"),f=e("loader"),s=NREUM;"undefined"==typeof window.newrelic&&(newrelic=s);var p=["setPageViewName","setCustomAttribute","setErrorHandler","finished","addToTrace","inlineHit","addRelease"],d="api-",l=d+"ixn-";a(p,function(e,t){s[t]=o(d+t,!0,"api")}),s.addPageAction=o(d+"addPageAction",!0),s.setCurrentRouteName=o(d+"routeName",!0),t.exports=newrelic,s.interaction=function(){return(new r).get()};var m=r.prototype={createTracer:function(e,t){var n={},r=this,o="function"==typeof t;return i(l+"tracer",[f.now(),e,n],r),function(){if(c.emit((o?"":"no-")+"fn-start",[f.now(),r,o],n),o)try{return t.apply(this,arguments)}catch(e){throw c.emit("fn-err",[arguments,this,e],n),e}finally{c.emit("fn-end",[f.now()],n)}}}};a("setName,setAttribute,save,ignore,onEnd,getContext,end,get".split(","),function(e,t){m[t]=o(l+t)}),newrelic.noticeError=function(e){"string"==typeof e&&(e=new Error(e)),i("err",[e,f.now()])}},{}],2:[function(e,t,n){function r(e,t){var n=[],r="",i=0;for(r in e)o.call(e,r)&&(n[i]=t(r,e[r]),i+=1);return n}var o=Object.prototype.hasOwnProperty;t.exports=r},{}],3:[function(e,t,n){function r(e,t,n){t||(t=0),"undefined"==typeof n&&(n=e?e.length:0);for(var r=-1,o=n-t||0,i=Array(o<0?0:o);++r<o;)i[r]=e[t+r];return i}t.exports=r},{}],4:[function(e,t,n){t.exports={exists:"undefined"!=typeof window.performance&&window.performance.timing&&"undefined"!=typeof window.performance.timing.navigationStart}},{}],ee:[function(e,t,n){function r(){}function o(e){function t(e){return e&&e instanceof r?e:e?c(e,u,i):i()}function n(n,r,o,i){if(!d.aborted||i){e&&e(n,r,o);for(var a=t(o),u=m(n),c=u.length,f=0;f<c;f++)u[f].apply(a,r);var p=s[y[n]];return p&&p.push([b,n,r,a]),a}}function l(e,t){v[e]=m(e).concat(t)}function m(e){return v[e]||[]}function w(e){return p[e]=p[e]||o(n)}function g(e,t){f(e,function(e,n){t=t||"feature",y[n]=t,t in s||(s[t]=[])})}var v={},y={},b={on:l,emit:n,get:w,listeners:m,context:t,buffer:g,abort:a,aborted:!1};return b}function i(){return new r}function a(){(s.api||s.feature)&&(d.aborted=!0,s=d.backlog={})}var u="nr@context",c=e("gos"),f=e(2),s={},p={},d=t.exports=o();d.backlog=s},{}],gos:[function(e,t,n){function r(e,t,n){if(o.call(e,t))return e[t];var r=n();if(Object.defineProperty&&Object.keys)try{return Object.defineProperty(e,t,{value:r,writable:!0,enumerable:!1}),r}catch(i){}return e[t]=r,r}var o=Object.prototype.hasOwnProperty;t.exports=r},{}],handle:[function(e,t,n){function r(e,t,n,r){o.buffer([e],r),o.emit(e,t,n)}var o=e("ee").get("handle");t.exports=r,r.ee=o},{}],id:[function(e,t,n){function r(e){var t=typeof e;return!e||"object"!==t&&"function"!==t?-1:e===window?0:a(e,i,function(){return o++})}var o=1,i="nr@id",a=e("gos");t.exports=r},{}],loader:[function(e,t,n){function r(){if(!x++){var e=h.info=NREUM.info,t=d.getElementsByTagName("script")[0];if(setTimeout(s.abort,3e4),!(e&&e.licenseKey&&e.applicationID&&t))return s.abort();f(y,function(t,n){e[t]||(e[t]=n)}),c("mark",["onload",a()+h.offset],null,"api");var n=d.createElement("script");n.src="https://"+e.agent,t.parentNode.insertBefore(n,t)}}function o(){"complete"===d.readyState&&i()}function i(){c("mark",["domContent",a()+h.offset],null,"api")}function a(){return E.exists&&performance.now?Math.round(performance.now()):(u=Math.max((new Date).getTime(),u))-h.offset}var u=(new Date).getTime(),c=e("handle"),f=e(2),s=e("ee"),p=window,d=p.document,l="addEventListener",m="attachEvent",w=p.XMLHttpRequest,g=w&&w.prototype;NREUM.o={ST:setTimeout,SI:p.setImmediate,CT:clearTimeout,XHR:w,REQ:p.Request,EV:p.Event,PR:p.Promise,MO:p.MutationObserver};var v=""+location,y={beacon:"bam.nr-data.net",errorBeacon:"bam.nr-data.net",agent:"js-agent.newrelic.com/nr-1071.min.js"},b=w&&g&&g[l]&&!/CriOS/.test(navigator.userAgent),h=t.exports={offset:u,now:a,origin:v,features:{},xhrWrappable:b};e(1),d[l]?(d[l]("DOMContentLoaded",i,!1),p[l]("load",r,!1)):(d[m]("onreadystatechange",o),p[m]("onload",r)),c("mark",["firstbyte",u],null,"api");var x=0,E=e(4)},{}]},{},["loader"]);</script>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="description" content="Tell us what you’d like to borrow and for how long and our mortgage calculator will show you the rates you could get, and what your monthly payments might be." />
    <title>Compare Mortgages | Santander Mortgages - Santander UK | Santander UK</title>
    <link type="text/css" rel="stylesheet" href="http://hogarthsantander.prod.acquia-sites.com/info/sites/default/files/css/css_w8xk9_LdffDX1osjOMil0_i1x1J9F-pK5pzIjdhIFdc.css" media="all" />
    <link type="text/css" rel="stylesheet" href="http://hogarthsantander.prod.acquia-sites.com/info/sites/default/files/css/css_6LGNMr85VATs82JJZA1UmhKmIERt0Zio5wS7IMleoAE.css" media="all" />
    <link type="text/css" rel="stylesheet" href="http://hogarthsantander.prod.acquia-sites.com/info/sites/default/files/css/css_C3qIE2nQ_Vc8XV1gONZNiR3D7cKcg2QOyLOlyLKkCf8.css" media="all" />

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
    <script src="js/santander_calculator.js"></script>
    <script src="js/calc_mortgages_comp.js"></script>


</head>

<body class="html not-front logged-in no-sidebars page-taxonomy page-taxonomy-term page-taxonomy-term- page-taxonomy-term-5491" >
<div class="main-container">
    <div class="region region-header">
        <section id="block-santander-header-banner" class="block block-santander clearfix">



            <header id="node-header-1346" class="node-product-header ">
                <div class="page-logo">
                    <div class="container"><img src="http://hogarthsantander.prod.acquia-sites.com/info/sites/all/themes/santander_cms_core/logo.svg" width="262" alt="Santander" /></div>
                </div>


                <img class="img-header visible-xs" src="http://hogarthsantander.prod.acquia-sites.com/info/sites/default/files/styles/sm-full/public/hero_216.jpg?itok=0S38qx1Z" alt="" />
                <img src="http://hogarthsantander.prod.acquia-sites.com/info/sites/default/files/styles/lg-full/public/hero_216.jpg?itok=4od50w02" alt="" width="0" height="0" style="display: none;" />
                <div class="page-header" style="background-image: url(http://hogarthsantander.prod.acquia-sites.com/info/sites/default/files/styles/lg-full/public/hero_216.jpg?itok=4od50w02);">

                    <div class="container onecol" >
                        <div class="row inner">

                            <div class="header-main">
                                <div class="brackets">
                                    <div class="b-top-left"></div>
                                    <div class="b-top-right"></div>
                                    <div class="b-bottom-right"></div>
                                    <div class="b-bottom-left"></div>
                                </div>

                                <h1>Compare our mortgages</h1>
                                <h2 class="field-name-field-subhead">Find a mortgage rate to suit you. Whether you’re a first time buyer, moving home or remortgaging to us from another lender, we’ll show you the rates you could get and what it’ll cost</h2>

                            </div>


                        </div>
                    </div>
                </div>
            </header>


        </section>
    </div>


    <a id="main-content"></a>

    <div class="container"><h2 class="element-invisible">Primary tabs</h2><ul class="tabs--primary nav nav-tabs"><li class="active"><a href="/info/mortgages/compare-our-mortgages" class="active">View<span class="element-invisible">(active tab)</span></a></li>
            <li><a href="/info/taxonomy/term/5491/edit">Edit Group</a></li>
            <li><a href="/info/node/1346/edit">Product - New draft</a></li>
            <li><a href="/info/node/1351/edit">Edit calculator</a></li>
        </ul></div>
    <div class="region region-content">
        <section id="block-system-main" class="block block-system clearfix">



            <div id="node-1346" class="node node-product view-mode-full clearfix">
                <div class="container"><div class="field field-name-field-calculator-link field-type-calculator-link field-label-hidden">
                        <div id="borrow-compmortgage" class="feature-box node-calculator node-compmorgage">
                            <div class="page-content">
                                <ul class="nav nav-tabs" role="navigation">
                                    <li><a href="/info/mortgages/how-much-can-i-borrow">How much could I borrow?</a></li>
                                    <li class="active"><a class="active">Compare our mortgages</a><span class="element-invisible">(active tab)</span></li>
                                </ul>


                                <div class="agree_step">
                                    <div class="field field-name-body field-type-text-with-summary field-label-hidden text clearfix">
                                        <h2>Can I get a mortgage?</h2>
                                        <p>To apply for a mortgage with us you need to:</p>
                                        <ul><li>be at least 18 years of age and a UK resident</li>
                                            <li>want the mortgage for a property in the UK (but not in the Isle of Man)</li>
                                            <li>intend to live in the property</li>
                                            <li>have never had a home repossessed</li>
                                            <li>have never been declared bankrupt or subject to an individual voluntary arrangement</li>
                                            <li>be able to provide confirmation of all types of income</li>
                                        </ul>		  </div>

                                    <div class="agree">
                                        <input type="checkbox" id="agree-check" />
                                        <label for="agree-check">
                                            <p>Tick the box to confirm you qualify</p>
                                            <a href="javascript:void(0)" class="btn btn-primary btn-sm disabled">Continue</a>
                                        </label>
                                    </div>
                                </div>

                                <div class="calc-steps">

                                    <div class="inner-content">
                                        <div class="step_1 calc-step">


                                            <!--<h3></h3>-->

                                            <ul class="nav nav-pills">
                                                <li class="active"><span class="no">1</span><span class="txt">What are you looking for?</span></li>
                                                <li><span class="no">2</span><span class="txt">What rates are available?</span></li>
                                                <li><span class="no">3</span><span class="txt">Compare your choices</span></li>
                                            </ul>

                                            <div class="clearfix step-1-inner">
                                                <div class="left-col">
                                                    <div class="calc-field calc-field-btype">
                                                        <div class="txt-label "><label>What type of buyer are you?</label></div>					<select name="btype" id="btype" >
                                                            <option value="">Please select</option>
                                                            <option value="mover">Moving home</option>
                                                            <option value="ftb">First time buyer</option>
                                                            <option value="remortgage">Remortgaging to us</option>
                                                        </select>
                                                    </div>

                                                    <div class="calc-field calc-field-property">
                                                        <div class="amount-tooltip clearfix"><div class="amount-field-label"><label for="field-property">What is your estimated property value?</label></div><div class="form-type-numberfield form-item-submitted-property form-item">
                                                                <input id="field-property" class="form-control form-text form-number" type="number" name="submitted[property]" value="0" step="1" min="0" />
                                                            </div>
                                                        </div>				  </div>

                                                    <div class="calc-field calc-field-borrow">
                                                        <div class="amount-tooltip clearfix"><div class="amount-field-label"><label for="field-borrow">How much do you want to borrow?</label> <span class="tooltip_ico" aria-describedby="tooltip-field-borrow">help</span>  <div class="tooltip_txt" id="tooltip-field-borrow" aria-hidden="true"><p>The minimum loan size for our mortgages is £6,000, and the maxi<span>mum loan size for our mortgages is £3,000,000.</span></p>
                                                                </div></div><div class="form-type-numberfield form-item-submitted-borrow form-item">
                                                                <input id="field-borrow" class="form-control form-text form-number" type="number" name="submitted[borrow]" value="0" step="1" min="6000" max="3000000" />
                                                            </div>
                                                        </div>				  </div>

                                                    <div class="calc-field calc-field-years">
                                                        <div class="txt-label "><label>How long would you like your mortgage for?</label></div>					<select name="years" id="mortgage-years">
                                                            <option value="5">5 years</option>
                                                            <option value="6">6 years</option>
                                                            <option value="7">7 years</option>
                                                            <option value="8">8 years</option>
                                                            <option value="9">9 years</option>
                                                            <option value="10">10 years</option>
                                                            <option value="11">11 years</option>
                                                            <option value="12">12 years</option>
                                                            <option value="13">13 years</option>
                                                            <option value="14">14 years</option>
                                                            <option value="15">15 years</option>
                                                            <option value="16">16 years</option>
                                                            <option value="17">17 years</option>
                                                            <option value="18">18 years</option>
                                                            <option value="19">19 years</option>
                                                            <option value="20">20 years</option>
                                                            <option value="21">21 years</option>
                                                            <option value="22">22 years</option>
                                                            <option value="23">23 years</option>
                                                            <option value="24">24 years</option>
                                                            <option value="25">25 years</option>
                                                            <option value="26">26 years</option>
                                                            <option value="27">27 years</option>
                                                            <option value="28">28 years</option>
                                                            <option value="29">29 years</option>
                                                            <option value="30">30 years</option>
                                                            <option value="31">31 years</option>
                                                            <option value="32">32 years</option>
                                                            <option value="33">33 years</option>
                                                            <option value="34">34 years</option>
                                                            <option value="35">35 years</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="right-col">

                                                    <div class="calc-field calc-field-existing-mortgage">
                                                        <div class="txt-label "><label>Are you a Santander Select customer?</label></div>					<div class="flat-checkbox flat-checkbox-2 value-set" data-name="san_select">
                                                            <span data-value="1">Yes</span>
                                                            <span data-value="0" class="active">No</span>
                                                        </div>
                                                    </div>

                                                    <div class="calc-field calc-field-htb-exclusive">
                                                        <div class="txt-label "><label>Do you have a Santander Help to Buy: ISA?</label></div>					<div class="flat-checkbox flat-checkbox-2 value-set" data-name="htb_exclusive">
                                                            <span data-value="1">Yes</span>
                                                            <span data-value="0" class="active">No</span>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>

                                            <div class="step-actions clearfix">
                                                <a href="javascript:void(0)" class="btn btn-primary btn-sm disabled btn-next">What rates are available?</a>
                                            </div>

                                        </div>

                                    </div>

                                    <div class="step_2 calc-step">

                                        <div class="step_2_top">
                                            <!--<h3></h3>-->

                                            <ul class="nav nav-pills">
                                                <li class="checked"><span class="no">1</span><span class="txt">What are you looking for?</span></li>
                                                <li class="active"><span class="no">2</span><span class="txt">What rates are available?</span></li>
                                                <li><span class="no">3</span><span class="txt">Compare your choices</span></li>
                                            </ul>


                                            <div class="row">
                                                <div class="col-md-6 col-sm-12">

                                                    <div class="loan-value">Your loan to value is: <strong>80.00%</strong></div>


                                                    <table class="selections" border="0" width="100%" cellpadding="0" cellspacing="0">
                                                        <tr><th>Buyer type:</th><td id="res-btype">-</td></tr>
                                                        <tr><th>Mortgage term:</th><td id="res-terms">-</td></tr>
                                                        <tr><th>Property value:</th><td id="res-property">$1.250.000</td></tr>
                                                        <tr><th>Mortgage value:</th><td id="res-borrow">$1.250.000</td></tr>
                                                        <tr><th>Santander Select customer:</th><td id="res-select-customer">Yes</td></tr>
                                                    </table>

                                                </div>
                                                <div class="col-md-6 col-sm-12 next-steps">

                                                    <h2>Next steps?</h2>
                                                    <div class="next-step-1">
                                                        <div id="field-next-step1" class="text richtext"><p>If you haven’t already found out <a href="http://www.santander.co.uk/info/mortgages/how-much-can-i-borrow" target="_blank">how much you could borrow</a> our quick and easy calculator could help.</p>
                                                        </div>                </div>
                                                    <div class="next-step-4">
                                                        <div id="field-next-step4" class="text richtext"><p>Get a decision in principle and then apply for a mortgage:</p>

                                                            <ul>
                                                                <li style="margin-left: 0.19in;"><a href="http://www.santander.co.uk/uk/mortgages/pre-apply"><u>online</u></a></li>
                                                                <li style="margin-left: 0.19in;">by phone by calling us on <strong>0800 068 6064</strong>. Lines are open 9am to 7pm Monday to Friday and 9am to 2pm Saturdays.</li>
                                                                <li style="margin-left: 0.19in;"><a href="https://branchlocator.santander.com/?view=gb&amp;defaultLanguage=en" target="_blank"><u>in branch</u></a></li>
                                                            </ul>
                                                        </div>                </div>
                                                </div>
                                            </div>

                                        </div>


                                        <div class="res-table-c">
                                            <h3>Refine my results by:</h3>
                                            <div class="row table-filter">
                                                <div class="col-md-4">Mortgage type<br />
                                                    <select id="filter-type">
                                                        <option value="">All rates</option>
                                                        <option value="fixed">Fixed rates</option>
                                                        <option value="tracker">Tracker rates</option>
                                                    </select>
                                                </div>
                                                <div class="col-md-4">Initial product period<br />
                                                    <select id="filter-initperiod">
                                                        <option value="">All terms</option>
                                                        <option value="2y">2 years</option>
                                                        <option value="3y">3 years</option>
                                                        <option value="5y">5 years</option>
                                                        <option value="10y">10 years</option>
                                                        <option value="lifetime">Lifetime</option>
                                                    </select>
                                                </div>
                                                <div class="col-md-4">Loan to value<br />
                                                    <select id="filter-ltv">
                                                        <option value="">All</option>
                                                        <option value="60%">60%</option>                                  <option value="70%">70%</option>                                  <option value="75%">75%</option>                                  <option value="80%">80%</option>                                  <option value="85%">85%</option>                                  <option value="90%">90%</option>                                  <option value="95%">95%</option>                              </select>
                                                </div>
                                            </div>

                                            <table cellspacing="0" cellpadding="0" class="mortgages-table">
                                                <thead><tr class="h-row">
                                                    <th>Mortgages available</th>
                                                    <th>Maximum loan to value</th>
                                                    <th>Initial rate</th>
                                                    <th>Differential to Bank of England base rate                <span>(currently 0.50%)</span></th>
                                                    <th>Then changing to Santander's Follow-on Rate (variable)</th>
                                                    <th>The overall cost for comparison is (APR)</th>
                                                    <th>Product fee</th>
                                                    <th>Additional benefits</th>
                                                    <th>Early repayment charge (ERC)</th>
                                                    <th>Monthly cost</th>
                                                    <th>Compare up to three rates</th>
                                                </tr></thead>
                                                <tbody>


                                                <tr class="r"
                                                    data-mnid="151366"
                                                    data-initialrate="1.29"
                                                    data-min="6000"
                                                    data-max="1000000"
                                                    data-ctype="remortgage"
                                                    data-ltv="60"
                                                    data-eligibility="all"
                                                    data-ptype="tracker"
                                                    data-period="2y"
                                                    data-prodcode="v993r"
                                                >
                                                    <th class="td-prod-type">2 year tracker (variable)</th>
                                                    <td class="td-max-ltv">60%</td>
                                                    <td>1.29%</td>
                                                    <td>0.79%</td>
                                                    <td>3.75%</td>
                                                    <td>3.0%</td>
                                                    <td>£999</td>
                                                    <td>Free valuation and standard legal fees paid</td>
                                                    <td>No ERC.
                                                        Repay paid legal fees</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151366" type="checkbox" value="151366" /><label for="ch-151366">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151151"
                                                    data-initialrate="1.29"
                                                    data-min="250000"
                                                    data-max="1500000"
                                                    data-ctype="remortgage"
                                                    data-ltv="75"
                                                    data-eligibility="all"
                                                    data-ptype="fixed"
                                                    data-period="2y"
                                                    data-prodcode="mc67r"
                                                >
                                                    <th class="td-prod-type">2 year fixed rate</th>
                                                    <td class="td-max-ltv">75%</td>
                                                    <td>1.29%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>3.3%</td>
                                                    <td>£1499</td>
                                                    <td>Free valuation and standard legal fees paid</td>
                                                    <td>3% + Repay paid legal fees</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151151" type="checkbox" value="151151" /><label for="ch-151151">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151156"
                                                    data-initialrate="1.29"
                                                    data-min="250000"
                                                    data-max="1500000"
                                                    data-ctype="mover & ftb"
                                                    data-ltv="75"
                                                    data-eligibility="all"
                                                    data-ptype="fixed"
                                                    data-period="2y"
                                                    data-prodcode="mc67v"
                                                >
                                                    <th class="td-prod-type">2 year fixed rate</th>
                                                    <td class="td-max-ltv">75%</td>
                                                    <td>1.29%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>3.3%</td>
                                                    <td>£1499</td>
                                                    <td>Free Valuation</td>
                                                    <td>3%</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151156" type="checkbox" value="151156" /><label for="ch-151156">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151371"
                                                    data-initialrate="1.29"
                                                    data-min="6000"
                                                    data-max="1000000"
                                                    data-ctype="mover & ftb"
                                                    data-ltv="60"
                                                    data-eligibility="all"
                                                    data-ptype="tracker"
                                                    data-period="2y"
                                                    data-prodcode="v993v"
                                                >
                                                    <th class="td-prod-type">2 year tracker (variable)</th>
                                                    <td class="td-max-ltv">60%</td>
                                                    <td>1.29%</td>
                                                    <td>0.79%</td>
                                                    <td>3.75%</td>
                                                    <td>3.2%</td>
                                                    <td>£999</td>
                                                    <td>Free Valuation</td>
                                                    <td>No ERC.
                                                    </td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151371" type="checkbox" value="151371" /><label for="ch-151371">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151121"
                                                    data-initialrate="1.34"
                                                    data-min="6000"
                                                    data-max="1000000"
                                                    data-ctype="remortgage"
                                                    data-ltv="60"
                                                    data-eligibility="all"
                                                    data-ptype="fixed"
                                                    data-period="2y"
                                                    data-prodcode="mc64r"
                                                >
                                                    <th class="td-prod-type">2 year fixed rate</th>
                                                    <td class="td-max-ltv">60%</td>
                                                    <td>1.34%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>3.3%</td>
                                                    <td>£999</td>
                                                    <td>Free valuation and standard legal fees paid</td>
                                                    <td>3% + Repay paid legal fees</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151121" type="checkbox" value="151121" /><label for="ch-151121">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151126"
                                                    data-initialrate="1.34"
                                                    data-min="6000"
                                                    data-max="1000000"
                                                    data-ctype="mover & ftb"
                                                    data-ltv="60"
                                                    data-eligibility="all"
                                                    data-ptype="fixed"
                                                    data-period="2y"
                                                    data-prodcode="mc64v"
                                                >
                                                    <th class="td-prod-type">2 year fixed rate</th>
                                                    <td class="td-max-ltv">60%</td>
                                                    <td>1.34%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>3.3%</td>
                                                    <td>£999</td>
                                                    <td>Free Valuation</td>
                                                    <td>3%</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151126" type="checkbox" value="151126" /><label for="ch-151126">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151161"
                                                    data-initialrate="1.39"
                                                    data-min="6000"
                                                    data-max="1000000"
                                                    data-ctype="remortgage"
                                                    data-ltv="75"
                                                    data-eligibility="select"
                                                    data-ptype="fixed"
                                                    data-period="2y"
                                                    data-prodcode="mc68r"
                                                >
                                                    <th class="td-prod-type">2 year fixed rate<br><a href="javascript:void(0);"><span class="santander-red select-exclusive-anchor">Select Exclusive</span></a></th>
                                                    <td class="td-max-ltv">75%</td>
                                                    <td>1.39%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>3.4%</td>
                                                    <td>£999</td>
                                                    <td>Free valuation and standard legal fees paid</td>
                                                    <td>3% + Repay paid legal fees</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151161" type="checkbox" value="151161" /><label for="ch-151161">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151166"
                                                    data-initialrate="1.39"
                                                    data-min="6000"
                                                    data-max="1000000"
                                                    data-ctype="mover & ftb"
                                                    data-ltv="75"
                                                    data-eligibility="select"
                                                    data-ptype="fixed"
                                                    data-period="2y"
                                                    data-prodcode="mc68v"
                                                >
                                                    <th class="td-prod-type">2 year fixed rate<br><a href="javascript:void(0);"><span class="santander-red select-exclusive-anchor">Select Exclusive</span></a></th>
                                                    <td class="td-max-ltv">75%</td>
                                                    <td>1.39%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>3.4%</td>
                                                    <td>£999</td>
                                                    <td>Free Valuation</td>
                                                    <td>3%</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151166" type="checkbox" value="151166" /><label for="ch-151166">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151176"
                                                    data-initialrate="1.44"
                                                    data-min="6000"
                                                    data-max="1500000"
                                                    data-ctype="mover & ftb"
                                                    data-ltv="75"
                                                    data-eligibility="all"
                                                    data-ptype="fixed"
                                                    data-period="2y"
                                                    data-prodcode="mc70v"
                                                >
                                                    <th class="td-prod-type">2 year fixed rate</th>
                                                    <td class="td-max-ltv">75%</td>
                                                    <td>1.44%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>3.4%</td>
                                                    <td>£999</td>
                                                    <td>Free Valuation</td>
                                                    <td>3%</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151176" type="checkbox" value="151176" /><label for="ch-151176">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151171"
                                                    data-initialrate="1.44"
                                                    data-min="6000"
                                                    data-max="1500000"
                                                    data-ctype="remortgage"
                                                    data-ltv="75"
                                                    data-eligibility="all"
                                                    data-ptype="fixed"
                                                    data-period="2y"
                                                    data-prodcode="mc70r"
                                                >
                                                    <th class="td-prod-type">2 year fixed rate</th>
                                                    <td class="td-max-ltv">75%</td>
                                                    <td>1.44%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>3.4%</td>
                                                    <td>£999</td>
                                                    <td>Free valuation and standard legal fees paid</td>
                                                    <td>3% + Repay paid legal fees</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151171" type="checkbox" value="151171" /><label for="ch-151171">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151196"
                                                    data-initialrate="1.54"
                                                    data-min="6000"
                                                    data-max="1000000"
                                                    data-ctype="mover & ftb"
                                                    data-ltv="85"
                                                    data-eligibility="all"
                                                    data-ptype="fixed"
                                                    data-period="2y"
                                                    data-prodcode="mc72h"
                                                >
                                                    <th class="td-prod-type">2 year fixed rate</th>
                                                    <td class="td-max-ltv">85%</td>
                                                    <td>1.54%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>3.4%</td>
                                                    <td>£999</td>
                                                    <td>Free valuation and £250 cashback</td>
                                                    <td>3% + Repay £250 cashback</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151196" type="checkbox" value="151196" /><label for="ch-151196">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151191"
                                                    data-initialrate="1.54"
                                                    data-min="6000"
                                                    data-max="1000000"
                                                    data-ctype="remortgage"
                                                    data-ltv="85"
                                                    data-eligibility="all"
                                                    data-ptype="fixed"
                                                    data-period="2y"
                                                    data-prodcode="mc72r"
                                                >
                                                    <th class="td-prod-type">2 year fixed rate</th>
                                                    <td class="td-max-ltv">85%</td>
                                                    <td>1.54%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>3.4%</td>
                                                    <td>£999</td>
                                                    <td>Free valuation and standard legal fees paid</td>
                                                    <td>3% + Repay paid legal fees</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151191" type="checkbox" value="151191" /><label for="ch-151191">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151391"
                                                    data-initialrate="1.59"
                                                    data-min="6000"
                                                    data-max="1000000"
                                                    data-ctype="mover & ftb"
                                                    data-ltv="75"
                                                    data-eligibility="all"
                                                    data-ptype="tracker"
                                                    data-period="2y"
                                                    data-prodcode="v994v"
                                                >
                                                    <th class="td-prod-type">2 year tracker (variable)</th>
                                                    <td class="td-max-ltv">75%</td>
                                                    <td>1.59%</td>
                                                    <td>1.09%</td>
                                                    <td>3.75%</td>
                                                    <td>3.4%</td>
                                                    <td>£999</td>
                                                    <td>Free Valuation</td>
                                                    <td>No ERC.
                                                    </td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151391" type="checkbox" value="151391" /><label for="ch-151391">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151386"
                                                    data-initialrate="1.59"
                                                    data-min="6000"
                                                    data-max="1000000"
                                                    data-ctype="remortgage"
                                                    data-ltv="75"
                                                    data-eligibility="all"
                                                    data-ptype="tracker"
                                                    data-period="2y"
                                                    data-prodcode="v994r"
                                                >
                                                    <th class="td-prod-type">2 year tracker (variable)</th>
                                                    <td class="td-max-ltv">75%</td>
                                                    <td>1.59%</td>
                                                    <td>1.09%</td>
                                                    <td>3.75%</td>
                                                    <td>3.2%</td>
                                                    <td>£999</td>
                                                    <td>Free valuation and standard legal fees paid</td>
                                                    <td>No ERC.
                                                        Repay paid legal fees</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151386" type="checkbox" value="151386" /><label for="ch-151386">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151131"
                                                    data-initialrate="1.74"
                                                    data-min="25000"
                                                    data-max="550000"
                                                    data-ctype="remortgage"
                                                    data-ltv="60"
                                                    data-eligibility="all"
                                                    data-ptype="fixed"
                                                    data-period="2y"
                                                    data-prodcode="mc65r"
                                                >
                                                    <th class="td-prod-type">2 year fixed rate</th>
                                                    <td class="td-max-ltv">60%</td>
                                                    <td>1.74%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>3.2%</td>
                                                    <td>£0</td>
                                                    <td>Free valuation and standard legal fees paid</td>
                                                    <td>3% + Repay paid legal fees</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151131" type="checkbox" value="151131" /><label for="ch-151131">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151136"
                                                    data-initialrate="1.74"
                                                    data-min="6000"
                                                    data-max="550000"
                                                    data-ctype="mover & ftb"
                                                    data-ltv="60"
                                                    data-eligibility="all"
                                                    data-ptype="fixed"
                                                    data-period="2y"
                                                    data-prodcode="mc65v"
                                                >
                                                    <th class="td-prod-type">2 year fixed rate</th>
                                                    <td class="td-max-ltv">60%</td>
                                                    <td>1.74%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>3.3%</td>
                                                    <td>£0</td>
                                                    <td>Free Valuation</td>
                                                    <td>3%</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151136" type="checkbox" value="151136" /><label for="ch-151136">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151141"
                                                    data-initialrate="1.74"
                                                    data-min="250000"
                                                    data-max="3000000"
                                                    data-ctype="remortgage"
                                                    data-ltv="70"
                                                    data-eligibility="all"
                                                    data-ptype="fixed"
                                                    data-period="2y"
                                                    data-prodcode="mc66r"
                                                >
                                                    <th class="td-prod-type">2 year fixed rate</th>
                                                    <td class="td-max-ltv">70%</td>
                                                    <td>1.74%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>3.5%</td>
                                                    <td>£1999</td>
                                                    <td>Free valuation and standard legal fees paid</td>
                                                    <td>3% + Repay paid legal fees</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151141" type="checkbox" value="151141" /><label for="ch-151141">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151146"
                                                    data-initialrate="1.74"
                                                    data-min="250000"
                                                    data-max="3000000"
                                                    data-ctype="mover & ftb"
                                                    data-ltv="70"
                                                    data-eligibility="all"
                                                    data-ptype="fixed"
                                                    data-period="2y"
                                                    data-prodcode="mc66v"
                                                >
                                                    <th class="td-prod-type">2 year fixed rate</th>
                                                    <td class="td-max-ltv">70%</td>
                                                    <td>1.74%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>3.5%</td>
                                                    <td>£1999</td>
                                                    <td>Free Valuation</td>
                                                    <td>3%</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151146" type="checkbox" value="151146" /><label for="ch-151146">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151186"
                                                    data-initialrate="1.79"
                                                    data-min="6000"
                                                    data-max="550000"
                                                    data-ctype="mover & ftb"
                                                    data-ltv="75"
                                                    data-eligibility="all"
                                                    data-ptype="fixed"
                                                    data-period="2y"
                                                    data-prodcode="mc71v"
                                                >
                                                    <th class="td-prod-type">2 year fixed rate</th>
                                                    <td class="td-max-ltv">75%</td>
                                                    <td>1.79%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>3.5%</td>
                                                    <td>£0</td>
                                                    <td>Free Valuation</td>
                                                    <td>3%</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151186" type="checkbox" value="151186" /><label for="ch-151186">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151181"
                                                    data-initialrate="1.79"
                                                    data-min="25000"
                                                    data-max="550000"
                                                    data-ctype="remortgage"
                                                    data-ltv="75"
                                                    data-eligibility="all"
                                                    data-ptype="fixed"
                                                    data-period="2y"
                                                    data-prodcode="mc71r"
                                                >
                                                    <th class="td-prod-type">2 year fixed rate</th>
                                                    <td class="td-max-ltv">75%</td>
                                                    <td>1.79%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>3.4%</td>
                                                    <td>£0</td>
                                                    <td>Free valuation and standard legal fees paid</td>
                                                    <td>3% + Repay paid legal fees</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151181" type="checkbox" value="151181" /><label for="ch-151181">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151396"
                                                    data-initialrate="1.84"
                                                    data-min="6000"
                                                    data-max="1000000"
                                                    data-ctype="remortgage"
                                                    data-ltv="85"
                                                    data-eligibility="all"
                                                    data-ptype="tracker"
                                                    data-period="2y"
                                                    data-prodcode="v995r"
                                                >
                                                    <th class="td-prod-type">2 year tracker (variable)</th>
                                                    <td class="td-max-ltv">85%</td>
                                                    <td>1.84%</td>
                                                    <td>1.34%</td>
                                                    <td>3.75%</td>
                                                    <td>3.5%</td>
                                                    <td>£999</td>
                                                    <td>Free valuation and standard legal fees paid</td>
                                                    <td>No ERC.
                                                        Repay paid legal fees</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151396" type="checkbox" value="151396" /><label for="ch-151396">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151401"
                                                    data-initialrate="1.84"
                                                    data-min="6000"
                                                    data-max="1000000"
                                                    data-ctype="mover & ftb"
                                                    data-ltv="85"
                                                    data-eligibility="all"
                                                    data-ptype="tracker"
                                                    data-period="2y"
                                                    data-prodcode="v995v"
                                                >
                                                    <th class="td-prod-type">2 year tracker (variable)</th>
                                                    <td class="td-max-ltv">85%</td>
                                                    <td>1.84%</td>
                                                    <td>1.34%</td>
                                                    <td>3.75%</td>
                                                    <td>3.5%</td>
                                                    <td>£999</td>
                                                    <td>Free Valuation</td>
                                                    <td>No ERC.
                                                    </td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151401" type="checkbox" value="151401" /><label for="ch-151401">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151241"
                                                    data-initialrate="1.89"
                                                    data-min="6000"
                                                    data-max="1000000"
                                                    data-ctype="mover & ftb"
                                                    data-ltv="60"
                                                    data-eligibility="all"
                                                    data-ptype="fixed"
                                                    data-period="5y"
                                                    data-prodcode="kg76v"
                                                >
                                                    <th class="td-prod-type">5 year fixed rate</th>
                                                    <td class="td-max-ltv">60%</td>
                                                    <td>1.89%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>3.0%</td>
                                                    <td>£999</td>
                                                    <td>Free Valuation</td>
                                                    <td>5%</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151241" type="checkbox" value="151241" /><label for="ch-151241">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151201"
                                                    data-initialrate="1.89"
                                                    data-min="6000"
                                                    data-max="550000"
                                                    data-ctype="ftb"
                                                    data-ltv="85"
                                                    data-eligibility="htb"
                                                    data-ptype="fixed"
                                                    data-period="2y"
                                                    data-prodcode="mc73h"
                                                >
                                                    <th class="td-prod-type">2 year fixed rate<br><a href="javascript:void(0);"><span class="santander-red htb-exclusive-anchor">Help to Buy: ISA exclusive</span></a></th>
                                                    <td class="td-max-ltv">85%</td>
                                                    <td>1.89%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>3.5%</td>
                                                    <td>£0</td>
                                                    <td>Free valuation and £250 cashback</td>
                                                    <td>3% + Repay £250 cashback</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151201" type="checkbox" value="151201" /><label for="ch-151201">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151236"
                                                    data-initialrate="1.89"
                                                    data-min="6000"
                                                    data-max="1000000"
                                                    data-ctype="remortgage"
                                                    data-ltv="60"
                                                    data-eligibility="all"
                                                    data-ptype="fixed"
                                                    data-period="5y"
                                                    data-prodcode="kg76r"
                                                >
                                                    <th class="td-prod-type">5 year fixed rate</th>
                                                    <td class="td-max-ltv">60%</td>
                                                    <td>1.89%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>2.8%</td>
                                                    <td>£999</td>
                                                    <td>Free valuation and standard legal fees paid</td>
                                                    <td>5% + Repay paid legal fees</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151236" type="checkbox" value="151236" /><label for="ch-151236">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151211"
                                                    data-initialrate="1.94"
                                                    data-min="6000"
                                                    data-max="550000"
                                                    data-ctype="mover & ftb"
                                                    data-ltv="85"
                                                    data-eligibility="all"
                                                    data-ptype="fixed"
                                                    data-period="2y"
                                                    data-prodcode="mc74h"
                                                >
                                                    <th class="td-prod-type">2 year fixed rate</th>
                                                    <td class="td-max-ltv">85%</td>
                                                    <td>1.94%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>3.5%</td>
                                                    <td>£0</td>
                                                    <td>Free valuation and £250 cashback</td>
                                                    <td>3% + Repay £250 cashback</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151211" type="checkbox" value="151211" /><label for="ch-151211">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151206"
                                                    data-initialrate="1.94"
                                                    data-min="25000"
                                                    data-max="550000"
                                                    data-ctype="remortgage"
                                                    data-ltv="85"
                                                    data-eligibility="all"
                                                    data-ptype="fixed"
                                                    data-period="2y"
                                                    data-prodcode="mc74r"
                                                >
                                                    <th class="td-prod-type">2 year fixed rate</th>
                                                    <td class="td-max-ltv">85%</td>
                                                    <td>1.94%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>3.4%</td>
                                                    <td>£0</td>
                                                    <td>Free valuation and standard legal fees paid</td>
                                                    <td>3% + Repay paid legal fees</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151206" type="checkbox" value="151206" /><label for="ch-151206">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151381"
                                                    data-initialrate="1.94"
                                                    data-min="250000"
                                                    data-max="3000000"
                                                    data-ctype="mover & ftb"
                                                    data-ltv="70"
                                                    data-eligibility="all"
                                                    data-ptype="tracker"
                                                    data-period="2y"
                                                    data-prodcode="v981v"
                                                >
                                                    <th class="td-prod-type">2 year tracker (variable)</th>
                                                    <td class="td-max-ltv">70%</td>
                                                    <td>1.94%</td>
                                                    <td>1.44%</td>
                                                    <td>3.75%</td>
                                                    <td>3.5%</td>
                                                    <td>£1999</td>
                                                    <td>Free Valuation</td>
                                                    <td>No ERC.
                                                    </td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151381" type="checkbox" value="151381" /><label for="ch-151381">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151216"
                                                    data-initialrate="1.94"
                                                    data-min="6000"
                                                    data-max="570000"
                                                    data-ctype="ftb"
                                                    data-ltv="90"
                                                    data-eligibility="all"
                                                    data-ptype="fixed"
                                                    data-period="2y"
                                                    data-prodcode="mc75h"
                                                >
                                                    <th class="td-prod-type">2 year fixed rate<br><span class="santander-red">First Time Buyer Exclusive</span></th>
                                                    <td class="td-max-ltv">90%</td>
                                                    <td>1.94%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>3.5%</td>
                                                    <td>£999</td>
                                                    <td>Free valuation and £250 cashback</td>
                                                    <td>3% + Repay £250 cashback</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151216" type="checkbox" value="151216" /><label for="ch-151216">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151376"
                                                    data-initialrate="1.94"
                                                    data-min="250000"
                                                    data-max="3000000"
                                                    data-ctype="remortgage"
                                                    data-ltv="70"
                                                    data-eligibility="all"
                                                    data-ptype="tracker"
                                                    data-period="2y"
                                                    data-prodcode="v981r"
                                                >
                                                    <th class="td-prod-type">2 year tracker (variable)</th>
                                                    <td class="td-max-ltv">70%</td>
                                                    <td>1.94%</td>
                                                    <td>1.44%</td>
                                                    <td>3.75%</td>
                                                    <td>3.5%</td>
                                                    <td>£1999</td>
                                                    <td>Free valuation and standard legal fees paid</td>
                                                    <td>No ERC.
                                                        Repay paid legal fees</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151376" type="checkbox" value="151376" /><label for="ch-151376">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151281"
                                                    data-initialrate="1.99"
                                                    data-min="6000"
                                                    data-max="1500000"
                                                    data-ctype="mover & ftb"
                                                    data-ltv="75"
                                                    data-eligibility="all"
                                                    data-ptype="fixed"
                                                    data-period="5y"
                                                    data-prodcode="kg80v"
                                                >
                                                    <th class="td-prod-type">5 year fixed rate</th>
                                                    <td class="td-max-ltv">75%</td>
                                                    <td>1.99%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>3.1%</td>
                                                    <td>£999</td>
                                                    <td>Free Valuation</td>
                                                    <td>5%</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151281" type="checkbox" value="151281" /><label for="ch-151281">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151276"
                                                    data-initialrate="1.99"
                                                    data-min="6000"
                                                    data-max="1500000"
                                                    data-ctype="remortgage"
                                                    data-ltv="75"
                                                    data-eligibility="all"
                                                    data-ptype="fixed"
                                                    data-period="5y"
                                                    data-prodcode="kg80r"
                                                >
                                                    <th class="td-prod-type">5 year fixed rate</th>
                                                    <td class="td-max-ltv">75%</td>
                                                    <td>1.99%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>3.0%</td>
                                                    <td>£999</td>
                                                    <td>Free valuation and standard legal fees paid</td>
                                                    <td>5% + Repay paid legal fees</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151276" type="checkbox" value="151276" /><label for="ch-151276">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151296"
                                                    data-initialrate="2.04"
                                                    data-min="6000"
                                                    data-max="1000000"
                                                    data-ctype="ftb"
                                                    data-ltv="80"
                                                    data-eligibility="all"
                                                    data-ptype="fixed"
                                                    data-period="5y"
                                                    data-prodcode="kg82h"
                                                >
                                                    <th class="td-prod-type">5 year fixed rate<br><span class="santander-red">First Time Buyer Exclusive</span></th>
                                                    <td class="td-max-ltv">80%</td>
                                                    <td>2.04%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>3.2%</td>
                                                    <td>£999</td>
                                                    <td>Free valuation and £250 cashback</td>
                                                    <td>5% + Repay £250 cashback</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151296" type="checkbox" value="151296" /><label for="ch-151296">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151261"
                                                    data-initialrate="2.09"
                                                    data-min="250000"
                                                    data-max="3000000"
                                                    data-ctype="mover & ftb"
                                                    data-ltv="60"
                                                    data-eligibility="all"
                                                    data-ptype="fixed"
                                                    data-period="5y"
                                                    data-prodcode="kg78v"
                                                >
                                                    <th class="td-prod-type">5 year fixed rate</th>
                                                    <td class="td-max-ltv">60%</td>
                                                    <td>2.09%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>3.1%</td>
                                                    <td>£1999</td>
                                                    <td>Free Valuation</td>
                                                    <td>5%</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151261" type="checkbox" value="151261" /><label for="ch-151261">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151256"
                                                    data-initialrate="2.09"
                                                    data-min="250000"
                                                    data-max="3000000"
                                                    data-ctype="remortgage"
                                                    data-ltv="60"
                                                    data-eligibility="all"
                                                    data-ptype="fixed"
                                                    data-period="5y"
                                                    data-prodcode="kg78r"
                                                >
                                                    <th class="td-prod-type">5 year fixed rate</th>
                                                    <td class="td-max-ltv">60%</td>
                                                    <td>2.09%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>3.1%</td>
                                                    <td>£1999</td>
                                                    <td>Free valuation and standard legal fees paid</td>
                                                    <td>5% + Repay paid legal fees</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151256" type="checkbox" value="151256" /><label for="ch-151256">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151251"
                                                    data-initialrate="2.14"
                                                    data-min="6000"
                                                    data-max="550000"
                                                    data-ctype="mover & ftb"
                                                    data-ltv="60"
                                                    data-eligibility="all"
                                                    data-ptype="fixed"
                                                    data-period="5y"
                                                    data-prodcode="kg77v"
                                                >
                                                    <th class="td-prod-type">5 year fixed rate</th>
                                                    <td class="td-max-ltv">60%</td>
                                                    <td>2.14%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>2.8%</td>
                                                    <td>£0</td>
                                                    <td>Free Valuation</td>
                                                    <td>5%</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151251" type="checkbox" value="151251" /><label for="ch-151251">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151246"
                                                    data-initialrate="2.14"
                                                    data-min="25000"
                                                    data-max="550000"
                                                    data-ctype="remortgage"
                                                    data-ltv="60"
                                                    data-eligibility="all"
                                                    data-ptype="fixed"
                                                    data-period="5y"
                                                    data-prodcode="kg77r"
                                                >
                                                    <th class="td-prod-type">5 year fixed rate</th>
                                                    <td class="td-max-ltv">60%</td>
                                                    <td>2.14%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>2.6%</td>
                                                    <td>£0</td>
                                                    <td>Free valuation and standard legal fees paid</td>
                                                    <td>5% + Repay paid legal fees</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151246" type="checkbox" value="151246" /><label for="ch-151246">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151306"
                                                    data-initialrate="2.19"
                                                    data-min="6000"
                                                    data-max="1000000"
                                                    data-ctype="mover & ftb"
                                                    data-ltv="80"
                                                    data-eligibility="all"
                                                    data-ptype="fixed"
                                                    data-period="5y"
                                                    data-prodcode="kg83h"
                                                >
                                                    <th class="td-prod-type">5 year fixed rate</th>
                                                    <td class="td-max-ltv">80%</td>
                                                    <td>2.19%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>3.2%</td>
                                                    <td>£999</td>
                                                    <td>Free valuation and £250 cashback</td>
                                                    <td>5% + Repay £250 cashback</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151306" type="checkbox" value="151306" /><label for="ch-151306">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151301"
                                                    data-initialrate="2.19"
                                                    data-min="6000"
                                                    data-max="1000000"
                                                    data-ctype="remortgage"
                                                    data-ltv="80"
                                                    data-eligibility="all"
                                                    data-ptype="fixed"
                                                    data-period="5y"
                                                    data-prodcode="kg83r"
                                                >
                                                    <th class="td-prod-type">5 year fixed rate</th>
                                                    <td class="td-max-ltv">80%</td>
                                                    <td>2.19%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>3.2%</td>
                                                    <td>£999</td>
                                                    <td>Free valuation and standard legal fees paid</td>
                                                    <td>5% + Repay paid legal fees</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151301" type="checkbox" value="151301" /><label for="ch-151301">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151286"
                                                    data-initialrate="2.24"
                                                    data-min="25000"
                                                    data-max="550000"
                                                    data-ctype="remortgage"
                                                    data-ltv="75"
                                                    data-eligibility="all"
                                                    data-ptype="fixed"
                                                    data-period="5y"
                                                    data-prodcode="kg81r"
                                                >
                                                    <th class="td-prod-type">5 year fixed rate</th>
                                                    <td class="td-max-ltv">75%</td>
                                                    <td>2.24%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>3.0%</td>
                                                    <td>£0</td>
                                                    <td>Free valuation and standard legal fees paid</td>
                                                    <td>5% + Repay paid legal fees</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151286" type="checkbox" value="151286" /><label for="ch-151286">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151326"
                                                    data-initialrate="2.24"
                                                    data-min="6000"
                                                    data-max="1000000"
                                                    data-ctype="mover & ftb"
                                                    data-ltv="85"
                                                    data-eligibility="all"
                                                    data-ptype="fixed"
                                                    data-period="5y"
                                                    data-prodcode="kg85h"
                                                >
                                                    <th class="td-prod-type">5 year fixed rate</th>
                                                    <td class="td-max-ltv">85%</td>
                                                    <td>2.24%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>3.2%</td>
                                                    <td>£999</td>
                                                    <td>Free valuation and £250 cashback</td>
                                                    <td>5% + Repay £250 cashback</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151326" type="checkbox" value="151326" /><label for="ch-151326">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151321"
                                                    data-initialrate="2.24"
                                                    data-min="6000"
                                                    data-max="1000000"
                                                    data-ctype="remortgage"
                                                    data-ltv="85"
                                                    data-eligibility="all"
                                                    data-ptype="fixed"
                                                    data-period="5y"
                                                    data-prodcode="kg85r"
                                                >
                                                    <th class="td-prod-type">5 year fixed rate</th>
                                                    <td class="td-max-ltv">85%</td>
                                                    <td>2.24%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>3.2%</td>
                                                    <td>£999</td>
                                                    <td>Free valuation and standard legal fees paid</td>
                                                    <td>5% + Repay paid legal fees</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151321" type="checkbox" value="151321" /><label for="ch-151321">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151291"
                                                    data-initialrate="2.24"
                                                    data-min="6000"
                                                    data-max="550000"
                                                    data-ctype="mover & ftb"
                                                    data-ltv="75"
                                                    data-eligibility="all"
                                                    data-ptype="fixed"
                                                    data-period="5y"
                                                    data-prodcode="kg81v"
                                                >
                                                    <th class="td-prod-type">5 year fixed rate</th>
                                                    <td class="td-max-ltv">75%</td>
                                                    <td>2.24%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>3.2%</td>
                                                    <td>£0</td>
                                                    <td>Free Valuation</td>
                                                    <td>5%</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151291" type="checkbox" value="151291" /><label for="ch-151291">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151271"
                                                    data-initialrate="2.29"
                                                    data-min="250000"
                                                    data-max="3000000"
                                                    data-ctype="mover & ftb"
                                                    data-ltv="70"
                                                    data-eligibility="all"
                                                    data-ptype="fixed"
                                                    data-period="5y"
                                                    data-prodcode="kg79v"
                                                >
                                                    <th class="td-prod-type">5 year fixed rate</th>
                                                    <td class="td-max-ltv">70%</td>
                                                    <td>2.29%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>3.2%</td>
                                                    <td>£1999</td>
                                                    <td>Free Valuation</td>
                                                    <td>5%</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151271" type="checkbox" value="151271" /><label for="ch-151271">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151221"
                                                    data-initialrate="2.29"
                                                    data-min="25000"
                                                    data-max="570000"
                                                    data-ctype="remortgage"
                                                    data-ltv="90"
                                                    data-eligibility="all"
                                                    data-ptype="fixed"
                                                    data-period="2y"
                                                    data-prodcode="mc76r"
                                                >
                                                    <th class="td-prod-type">2 year fixed rate</th>
                                                    <td class="td-max-ltv">90%</td>
                                                    <td>2.29%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>3.5%</td>
                                                    <td>£0</td>
                                                    <td>Free valuation and standard legal fees paid</td>
                                                    <td>3% + Repay paid legal fees</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151221" type="checkbox" value="151221" /><label for="ch-151221">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151226"
                                                    data-initialrate="2.29"
                                                    data-min="6000"
                                                    data-max="570000"
                                                    data-ctype="mover & ftb"
                                                    data-ltv="90"
                                                    data-eligibility="all"
                                                    data-ptype="fixed"
                                                    data-period="2y"
                                                    data-prodcode="mc76v"
                                                >
                                                    <th class="td-prod-type">2 year fixed rate</th>
                                                    <td class="td-max-ltv">90%</td>
                                                    <td>2.29%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>3.6%</td>
                                                    <td>£0</td>
                                                    <td>Free Valuation</td>
                                                    <td>3%</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151226" type="checkbox" value="151226" /><label for="ch-151226">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151266"
                                                    data-initialrate="2.29"
                                                    data-min="250000"
                                                    data-max="3000000"
                                                    data-ctype="remortgage"
                                                    data-ltv="70"
                                                    data-eligibility="all"
                                                    data-ptype="fixed"
                                                    data-period="5y"
                                                    data-prodcode="kg79r"
                                                >
                                                    <th class="td-prod-type">5 year fixed rate</th>
                                                    <td class="td-max-ltv">70%</td>
                                                    <td>2.29%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>3.2%</td>
                                                    <td>£1999</td>
                                                    <td>Free valuation and standard legal fees paid</td>
                                                    <td>5% + Repay paid legal fees</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151266" type="checkbox" value="151266" /><label for="ch-151266">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151421"
                                                    data-initialrate="2.34"
                                                    data-min="25000"
                                                    data-max="1000000"
                                                    data-ctype="remortgage"
                                                    data-ltv="75"
                                                    data-eligibility="select"
                                                    data-ptype="tracker"
                                                    data-period="lifetime"
                                                    data-prodcode="j171r"
                                                >
                                                    <th class="td-prod-type">Lifetime Tracker (variable)<br><a href="javascript:void(0);"><span class="santander-red select-exclusive-anchor">Select Exclusive</span></a></th>
                                                    <td class="td-max-ltv">75%</td>
                                                    <td>2.34%</td>
                                                    <td>1.84%</td>
                                                    <td>n/a</td>
                                                    <td>2.4%</td>
                                                    <td>£999</td>
                                                    <td>Free valuation and standard legal fees paid</td>
                                                    <td>No ERC.
                                                        Repay paid legal fees</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151421" type="checkbox" value="151421" /><label for="ch-151421">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151426"
                                                    data-initialrate="2.34"
                                                    data-min="25000"
                                                    data-max="1000000"
                                                    data-ctype="mover & ftb"
                                                    data-ltv="75"
                                                    data-eligibility="select"
                                                    data-ptype="tracker"
                                                    data-period="lifetime"
                                                    data-prodcode="j171v"
                                                >
                                                    <th class="td-prod-type">Lifetime Tracker (variable)<br><a href="javascript:void(0);"><span class="santander-red select-exclusive-anchor">Select Exclusive</span></a></th>
                                                    <td class="td-max-ltv">75%</td>
                                                    <td>2.34%</td>
                                                    <td>1.84%</td>
                                                    <td>n/a</td>
                                                    <td>2.4%</td>
                                                    <td>£999</td>
                                                    <td>Free Valuation</td>
                                                    <td>No ERC.
                                                    </td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151426" type="checkbox" value="151426" /><label for="ch-151426">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151416"
                                                    data-initialrate="2.39"
                                                    data-min="25000"
                                                    data-max="1000000"
                                                    data-ctype="mover & ftb"
                                                    data-ltv="75"
                                                    data-eligibility="all"
                                                    data-ptype="tracker"
                                                    data-period="lifetime"
                                                    data-prodcode="j170v"
                                                >
                                                    <th class="td-prod-type">Lifetime Tracker (variable)</th>
                                                    <td class="td-max-ltv">75%</td>
                                                    <td>2.39%</td>
                                                    <td>1.89%</td>
                                                    <td>n/a</td>
                                                    <td>2.5%</td>
                                                    <td>£999</td>
                                                    <td>Free Valuation</td>
                                                    <td>No ERC.
                                                    </td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151416" type="checkbox" value="151416" /><label for="ch-151416">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151411"
                                                    data-initialrate="2.39"
                                                    data-min="25000"
                                                    data-max="1000000"
                                                    data-ctype="remortgage"
                                                    data-ltv="75"
                                                    data-eligibility="all"
                                                    data-ptype="tracker"
                                                    data-period="lifetime"
                                                    data-prodcode="j170r"
                                                >
                                                    <th class="td-prod-type">Lifetime Tracker (variable)</th>
                                                    <td class="td-max-ltv">75%</td>
                                                    <td>2.39%</td>
                                                    <td>1.89%</td>
                                                    <td>n/a</td>
                                                    <td>2.4%</td>
                                                    <td>£999</td>
                                                    <td>Free valuation and standard legal fees paid</td>
                                                    <td>No ERC.
                                                        Repay paid legal fees</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151411" type="checkbox" value="151411" /><label for="ch-151411">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151311"
                                                    data-initialrate="2.49"
                                                    data-min="25000"
                                                    data-max="550000"
                                                    data-ctype="remortgage"
                                                    data-ltv="80"
                                                    data-eligibility="all"
                                                    data-ptype="fixed"
                                                    data-period="5y"
                                                    data-prodcode="kg84r"
                                                >
                                                    <th class="td-prod-type">5 year fixed rate</th>
                                                    <td class="td-max-ltv">80%</td>
                                                    <td>2.49%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>3.3%</td>
                                                    <td>£0</td>
                                                    <td>Free valuation and standard legal fees paid</td>
                                                    <td>5% + Repay paid legal fees</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151311" type="checkbox" value="151311" /><label for="ch-151311">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151316"
                                                    data-initialrate="2.49"
                                                    data-min="6000"
                                                    data-max="550000"
                                                    data-ctype="mover & ftb"
                                                    data-ltv="80"
                                                    data-eligibility="all"
                                                    data-ptype="fixed"
                                                    data-period="5y"
                                                    data-prodcode="kg84h"
                                                >
                                                    <th class="td-prod-type">5 year fixed rate</th>
                                                    <td class="td-max-ltv">80%</td>
                                                    <td>2.49%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>3.3%</td>
                                                    <td>£0</td>
                                                    <td>Free valuation and £250 cashback</td>
                                                    <td>5% + Repay £250 cashback</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151316" type="checkbox" value="151316" /><label for="ch-151316">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151331"
                                                    data-initialrate="2.59"
                                                    data-min="25000"
                                                    data-max="550000"
                                                    data-ctype="remortgage"
                                                    data-ltv="85"
                                                    data-eligibility="all"
                                                    data-ptype="fixed"
                                                    data-period="5y"
                                                    data-prodcode="kg86r"
                                                >
                                                    <th class="td-prod-type">5 year fixed rate</th>
                                                    <td class="td-max-ltv">85%</td>
                                                    <td>2.59%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>3.3%</td>
                                                    <td>£0</td>
                                                    <td>Free valuation and standard legal fees paid</td>
                                                    <td>5% + Repay paid legal fees</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151331" type="checkbox" value="151331" /><label for="ch-151331">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151336"
                                                    data-initialrate="2.59"
                                                    data-min="6000"
                                                    data-max="550000"
                                                    data-ctype="mover & ftb"
                                                    data-ltv="85"
                                                    data-eligibility="all"
                                                    data-ptype="fixed"
                                                    data-period="5y"
                                                    data-prodcode="kg86h"
                                                >
                                                    <th class="td-prod-type">5 year fixed rate</th>
                                                    <td class="td-max-ltv">85%</td>
                                                    <td>2.59%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>3.4%</td>
                                                    <td>£0</td>
                                                    <td>Free valuation and £250 cashback</td>
                                                    <td>5% + Repay £250 cashback</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151336" type="checkbox" value="151336" /><label for="ch-151336">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151341"
                                                    data-initialrate="2.74"
                                                    data-min="6000"
                                                    data-max="570000"
                                                    data-ctype="remortgage"
                                                    data-ltv="90"
                                                    data-eligibility="all"
                                                    data-ptype="fixed"
                                                    data-period="5y"
                                                    data-prodcode="kg87r"
                                                >
                                                    <th class="td-prod-type">5 year fixed rate</th>
                                                    <td class="td-max-ltv">90%</td>
                                                    <td>2.74%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>3.3%</td>
                                                    <td>£999</td>
                                                    <td>Free valuation and standard legal fees paid</td>
                                                    <td>5% + Repay paid legal fees</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151341" type="checkbox" value="151341" /><label for="ch-151341">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151346"
                                                    data-initialrate="2.74"
                                                    data-min="6000"
                                                    data-max="570000"
                                                    data-ctype="mover & ftb"
                                                    data-ltv="90"
                                                    data-eligibility="all"
                                                    data-ptype="fixed"
                                                    data-period="5y"
                                                    data-prodcode="kg87h"
                                                >
                                                    <th class="td-prod-type">5 year fixed rate</th>
                                                    <td class="td-max-ltv">90%</td>
                                                    <td>2.74%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>3.4%</td>
                                                    <td>£999</td>
                                                    <td>Free valuation and £250 cashback</td>
                                                    <td>5% + Repay £250 cashback</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151346" type="checkbox" value="151346" /><label for="ch-151346">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151351"
                                                    data-initialrate="3.04"
                                                    data-min="6000"
                                                    data-max="570000"
                                                    data-ctype="ftb"
                                                    data-ltv="90"
                                                    data-eligibility="htb"
                                                    data-ptype="fixed"
                                                    data-period="5y"
                                                    data-prodcode="kg88h"
                                                >
                                                    <th class="td-prod-type">5 year fixed rate<br><a href="javascript:void(0);"><span class="santander-red htb-exclusive-anchor">Help to Buy: ISA exclusive</span></a></th>
                                                    <td class="td-max-ltv">90%</td>
                                                    <td>3.04%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>3.6%</td>
                                                    <td>£0</td>
                                                    <td>Free valuation and £250 cashback</td>
                                                    <td>5% + Repay £250 cashback</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151351" type="checkbox" value="151351" /><label for="ch-151351">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151356"
                                                    data-initialrate="3.14"
                                                    data-min="6000"
                                                    data-max="570000"
                                                    data-ctype="mover & ftb"
                                                    data-ltv="90"
                                                    data-eligibility="all"
                                                    data-ptype="fixed"
                                                    data-period="5y"
                                                    data-prodcode="kg89h"
                                                >
                                                    <th class="td-prod-type">5 year fixed rate</th>
                                                    <td class="td-max-ltv">90%</td>
                                                    <td>3.14%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>3.6%</td>
                                                    <td>£0</td>
                                                    <td>Free valuation and £250 cashback</td>
                                                    <td>5% + Repay £250 cashback</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151356" type="checkbox" value="151356" /><label for="ch-151356">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151231"
                                                    data-initialrate="3.89"
                                                    data-min="6000"
                                                    data-max="570000"
                                                    data-ctype="mover & ftb"
                                                    data-ltv="95"
                                                    data-eligibility="all"
                                                    data-ptype="fixed"
                                                    data-period="2y"
                                                    data-prodcode="mc77h"
                                                >
                                                    <th class="td-prod-type">2 year fixed rate</th>
                                                    <td class="td-max-ltv">95%</td>
                                                    <td>3.89%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>3.9%</td>
                                                    <td>£0</td>
                                                    <td>Free valuation and £250 cashback</td>
                                                    <td>3% + Repay £250 cashback</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151231" type="checkbox" value="151231" /><label for="ch-151231">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151406"
                                                    data-initialrate="3.99"
                                                    data-min="6000"
                                                    data-max="570000"
                                                    data-ctype="mover & ftb"
                                                    data-ltv="95"
                                                    data-eligibility="all"
                                                    data-ptype="tracker"
                                                    data-period="2y"
                                                    data-prodcode="v984v"
                                                >
                                                    <th class="td-prod-type">2 year tracker (variable)</th>
                                                    <td class="td-max-ltv">95%</td>
                                                    <td>3.99%</td>
                                                    <td>3.49%</td>
                                                    <td>3.75%</td>
                                                    <td>3.9%</td>
                                                    <td>£0</td>
                                                    <td>Free Valuation</td>
                                                    <td>No ERC.
                                                    </td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151406" type="checkbox" value="151406" /><label for="ch-151406">&nbsp;</label></td>
                                                </tr>


                                                <tr class="r"
                                                    data-mnid="151361"
                                                    data-initialrate="4.44"
                                                    data-min="6000"
                                                    data-max="570000"
                                                    data-ctype="mover & ftb"
                                                    data-ltv="95"
                                                    data-eligibility="all"
                                                    data-ptype="fixed"
                                                    data-period="5y"
                                                    data-prodcode="kg90h"
                                                >
                                                    <th class="td-prod-type">5 year fixed rate</th>
                                                    <td class="td-max-ltv">95%</td>
                                                    <td>4.44%</td>
                                                    <td>n/a</td>
                                                    <td>3.75%</td>
                                                    <td>4.1%</td>
                                                    <td>£0</td>
                                                    <td>Free valuation and £250 cashback</td>
                                                    <td>5% + Repay £250 cashback</td>
                                                    <td class="td-m-cost">-</td>
                                                    <td class="description" style="display:none">Description here</td>
                                                    <td class="check-td"><input id="ch-151361" type="checkbox" value="151361" /><label for="ch-151361">&nbsp;</label></td>
                                                </tr>
                                                </tbody>
                                            </table>

                                            <table cellspacing="0" cellpadding="0" style="display:none" class="mortgages-comp-table">
                                                <tr class="h-row">
                                                    <th></th>
                                                    <th class="m-nid-col m-nid-151366">2 year tracker (variable)</th>
                                                    <th class="m-nid-col m-nid-151151">2 year fixed rate</th>
                                                    <th class="m-nid-col m-nid-151156">2 year fixed rate</th>
                                                    <th class="m-nid-col m-nid-151371">2 year tracker (variable)</th>
                                                    <th class="m-nid-col m-nid-151121">2 year fixed rate</th>
                                                    <th class="m-nid-col m-nid-151126">2 year fixed rate</th>
                                                    <th class="m-nid-col m-nid-151161">2 year fixed rate<br><a href="javascript:void(0);"><span class="santander-red select-exclusive-anchor">Select Exclusive</span></a></th>
                                                    <th class="m-nid-col m-nid-151166">2 year fixed rate<br><a href="javascript:void(0);"><span class="santander-red select-exclusive-anchor">Select Exclusive</span></a></th>
                                                    <th class="m-nid-col m-nid-151176">2 year fixed rate</th>
                                                    <th class="m-nid-col m-nid-151171">2 year fixed rate</th>
                                                    <th class="m-nid-col m-nid-151196">2 year fixed rate</th>
                                                    <th class="m-nid-col m-nid-151191">2 year fixed rate</th>
                                                    <th class="m-nid-col m-nid-151391">2 year tracker (variable)</th>
                                                    <th class="m-nid-col m-nid-151386">2 year tracker (variable)</th>
                                                    <th class="m-nid-col m-nid-151131">2 year fixed rate</th>
                                                    <th class="m-nid-col m-nid-151136">2 year fixed rate</th>
                                                    <th class="m-nid-col m-nid-151141">2 year fixed rate</th>
                                                    <th class="m-nid-col m-nid-151146">2 year fixed rate</th>
                                                    <th class="m-nid-col m-nid-151186">2 year fixed rate</th>
                                                    <th class="m-nid-col m-nid-151181">2 year fixed rate</th>
                                                    <th class="m-nid-col m-nid-151396">2 year tracker (variable)</th>
                                                    <th class="m-nid-col m-nid-151401">2 year tracker (variable)</th>
                                                    <th class="m-nid-col m-nid-151241">5 year fixed rate</th>
                                                    <th class="m-nid-col m-nid-151201">2 year fixed rate<br><a href="javascript:void(0);"><span class="santander-red htb-exclusive-anchor">Help to Buy: ISA exclusive</span></a></th>
                                                    <th class="m-nid-col m-nid-151236">5 year fixed rate</th>
                                                    <th class="m-nid-col m-nid-151211">2 year fixed rate</th>
                                                    <th class="m-nid-col m-nid-151206">2 year fixed rate</th>
                                                    <th class="m-nid-col m-nid-151381">2 year tracker (variable)</th>
                                                    <th class="m-nid-col m-nid-151216">2 year fixed rate<br><span class="santander-red">First Time Buyer Exclusive</span></th>
                                                    <th class="m-nid-col m-nid-151376">2 year tracker (variable)</th>
                                                    <th class="m-nid-col m-nid-151281">5 year fixed rate</th>
                                                    <th class="m-nid-col m-nid-151276">5 year fixed rate</th>
                                                    <th class="m-nid-col m-nid-151296">5 year fixed rate<br><span class="santander-red">First Time Buyer Exclusive</span></th>
                                                    <th class="m-nid-col m-nid-151261">5 year fixed rate</th>
                                                    <th class="m-nid-col m-nid-151256">5 year fixed rate</th>
                                                    <th class="m-nid-col m-nid-151251">5 year fixed rate</th>
                                                    <th class="m-nid-col m-nid-151246">5 year fixed rate</th>
                                                    <th class="m-nid-col m-nid-151306">5 year fixed rate</th>
                                                    <th class="m-nid-col m-nid-151301">5 year fixed rate</th>
                                                    <th class="m-nid-col m-nid-151286">5 year fixed rate</th>
                                                    <th class="m-nid-col m-nid-151326">5 year fixed rate</th>
                                                    <th class="m-nid-col m-nid-151321">5 year fixed rate</th>
                                                    <th class="m-nid-col m-nid-151291">5 year fixed rate</th>
                                                    <th class="m-nid-col m-nid-151271">5 year fixed rate</th>
                                                    <th class="m-nid-col m-nid-151221">2 year fixed rate</th>
                                                    <th class="m-nid-col m-nid-151226">2 year fixed rate</th>
                                                    <th class="m-nid-col m-nid-151266">5 year fixed rate</th>
                                                    <th class="m-nid-col m-nid-151421">Lifetime Tracker (variable)<br><a href="javascript:void(0);"><span class="santander-red select-exclusive-anchor">Select Exclusive</span></a></th>
                                                    <th class="m-nid-col m-nid-151426">Lifetime Tracker (variable)<br><a href="javascript:void(0);"><span class="santander-red select-exclusive-anchor">Select Exclusive</span></a></th>
                                                    <th class="m-nid-col m-nid-151416">Lifetime Tracker (variable)</th>
                                                    <th class="m-nid-col m-nid-151411">Lifetime Tracker (variable)</th>
                                                    <th class="m-nid-col m-nid-151311">5 year fixed rate</th>
                                                    <th class="m-nid-col m-nid-151316">5 year fixed rate</th>
                                                    <th class="m-nid-col m-nid-151331">5 year fixed rate</th>
                                                    <th class="m-nid-col m-nid-151336">5 year fixed rate</th>
                                                    <th class="m-nid-col m-nid-151341">5 year fixed rate</th>
                                                    <th class="m-nid-col m-nid-151346">5 year fixed rate</th>
                                                    <th class="m-nid-col m-nid-151351">5 year fixed rate<br><a href="javascript:void(0);"><span class="santander-red htb-exclusive-anchor">Help to Buy: ISA exclusive</span></a></th>
                                                    <th class="m-nid-col m-nid-151356">5 year fixed rate</th>
                                                    <th class="m-nid-col m-nid-151231">2 year fixed rate</th>
                                                    <th class="m-nid-col m-nid-151406">2 year tracker (variable)</th>
                                                    <th class="m-nid-col m-nid-151361">5 year fixed rate</th>
                                                </tr>
                                                <tr class="r">
                                                    <th>Description</th>

                                                    <td class="m-nid-col m-nid-151366 comp-description-col" style="text-align:left;"><strong>Tracker rate</strong> - Your payments will increase or decrease in line with the Bank of England base rate. You will need to ensure you can afford any changes in payments.</td>
                                                    <td class="m-nid-col m-nid-151151 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151156 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151371 comp-description-col" style="text-align:left;"><strong>Tracker rate</strong> - Your payments will increase or decrease in line with the Bank of England base rate. You will need to ensure you can afford any changes in payments.</td>
                                                    <td class="m-nid-col m-nid-151121 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151126 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151161 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151166 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151176 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151171 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151196 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151191 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151391 comp-description-col" style="text-align:left;"><strong>Tracker rate</strong> - Your payments will increase or decrease in line with the Bank of England base rate. You will need to ensure you can afford any changes in payments.</td>
                                                    <td class="m-nid-col m-nid-151386 comp-description-col" style="text-align:left;"><strong>Tracker rate</strong> - Your payments will increase or decrease in line with the Bank of England base rate. You will need to ensure you can afford any changes in payments.</td>
                                                    <td class="m-nid-col m-nid-151131 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151136 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151141 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151146 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151186 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151181 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151396 comp-description-col" style="text-align:left;"><strong>Tracker rate</strong> - Your payments will increase or decrease in line with the Bank of England base rate. You will need to ensure you can afford any changes in payments.</td>
                                                    <td class="m-nid-col m-nid-151401 comp-description-col" style="text-align:left;"><strong>Tracker rate</strong> - Your payments will increase or decrease in line with the Bank of England base rate. You will need to ensure you can afford any changes in payments.</td>
                                                    <td class="m-nid-col m-nid-151241 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151201 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151236 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151211 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151206 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151381 comp-description-col" style="text-align:left;"><strong>Tracker rate</strong> - Your payments will increase or decrease in line with the Bank of England base rate. You will need to ensure you can afford any changes in payments.</td>
                                                    <td class="m-nid-col m-nid-151216 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151376 comp-description-col" style="text-align:left;"><strong>Tracker rate</strong> - Your payments will increase or decrease in line with the Bank of England base rate. You will need to ensure you can afford any changes in payments.</td>
                                                    <td class="m-nid-col m-nid-151281 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151276 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151296 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151261 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151256 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151251 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151246 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151306 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151301 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151286 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151326 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151321 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151291 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151271 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151221 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151226 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151266 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151421 comp-description-col" style="text-align:left;"><strong>Tracker rate</strong> - Your payments will increase or decrease in line with the Bank of England base rate. You will need to ensure you can afford any changes in payments.</td>
                                                    <td class="m-nid-col m-nid-151426 comp-description-col" style="text-align:left;"><strong>Tracker rate</strong> - Your payments will increase or decrease in line with the Bank of England base rate. You will need to ensure you can afford any changes in payments.</td>
                                                    <td class="m-nid-col m-nid-151416 comp-description-col" style="text-align:left;"><strong>Tracker rate</strong> - Your payments will increase or decrease in line with the Bank of England base rate. You will need to ensure you can afford any changes in payments.</td>
                                                    <td class="m-nid-col m-nid-151411 comp-description-col" style="text-align:left;"><strong>Tracker rate</strong> - Your payments will increase or decrease in line with the Bank of England base rate. You will need to ensure you can afford any changes in payments.</td>
                                                    <td class="m-nid-col m-nid-151311 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151316 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151331 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151336 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151341 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151346 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151351 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151356 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151231 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>
                                                    <td class="m-nid-col m-nid-151406 comp-description-col" style="text-align:left;"><strong>Tracker rate</strong> - Your payments will increase or decrease in line with the Bank of England base rate. You will need to ensure you can afford any changes in payments.</td>
                                                    <td class="m-nid-col m-nid-151361 comp-description-col" style="text-align:left;"><strong>Fixed rate</strong> - Your payments remain the same during the fixed rate period, no matter what happens to the Bank of England base rate.</td>                            </tr>
                                                <tr class="r">
                                                    <th>How does the term affect me?</th>

                                                    <td class="m-nid-col m-nid-151366 comp-affect-me-col" style="text-align:left;">Our tracker rates are available over two years. The rate tracks above the Bank of England base rate during the tracker period. At the end of the tracker period you will need to select a new product, or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate interest rate changes which will alter your mortgage payments.</td>
                                                    <td class="m-nid-col m-nid-151151 comp-affect-me-col" style="text-align:left;">A two year deal is one of the shortest fixed rate terms Santander offer. At the end of the fixed rate period, you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151156 comp-affect-me-col" style="text-align:left;">A two year deal is one of the shortest fixed rate terms Santander offer. At the end of the fixed rate period, you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151371 comp-affect-me-col" style="text-align:left;">Our tracker rates are available over two years. The rate tracks above the Bank of England base rate during the tracker period. At the end of the tracker period you will need to select a new product, or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate interest rate changes which will alter your mortgage payments.</td>
                                                    <td class="m-nid-col m-nid-151121 comp-affect-me-col" style="text-align:left;">A two year deal is one of the shortest fixed rate terms Santander offer. At the end of the fixed rate period, you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151126 comp-affect-me-col" style="text-align:left;">A two year deal is one of the shortest fixed rate terms Santander offer. At the end of the fixed rate period, you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151161 comp-affect-me-col" style="text-align:left;">A two year deal is one of the shortest fixed rate terms Santander offer. At the end of the fixed rate period, you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151166 comp-affect-me-col" style="text-align:left;">A two year deal is one of the shortest fixed rate terms Santander offer. At the end of the fixed rate period, you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151176 comp-affect-me-col" style="text-align:left;">A two year deal is one of the shortest fixed rate terms Santander offer. At the end of the fixed rate period, you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151171 comp-affect-me-col" style="text-align:left;">A two year deal is one of the shortest fixed rate terms Santander offer. At the end of the fixed rate period, you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151196 comp-affect-me-col" style="text-align:left;">A two year deal is one of the shortest fixed rate terms Santander offer. At the end of the fixed rate period, you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151191 comp-affect-me-col" style="text-align:left;">A two year deal is one of the shortest fixed rate terms Santander offer. At the end of the fixed rate period, you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151391 comp-affect-me-col" style="text-align:left;">Our tracker rates are available over two years. The rate tracks above the Bank of England base rate during the tracker period. At the end of the tracker period you will need to select a new product, or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate interest rate changes which will alter your mortgage payments.</td>
                                                    <td class="m-nid-col m-nid-151386 comp-affect-me-col" style="text-align:left;">Our tracker rates are available over two years. The rate tracks above the Bank of England base rate during the tracker period. At the end of the tracker period you will need to select a new product, or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate interest rate changes which will alter your mortgage payments.</td>
                                                    <td class="m-nid-col m-nid-151131 comp-affect-me-col" style="text-align:left;">A two year deal is one of the shortest fixed rate terms Santander offer. At the end of the fixed rate period, you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151136 comp-affect-me-col" style="text-align:left;">A two year deal is one of the shortest fixed rate terms Santander offer. At the end of the fixed rate period, you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151141 comp-affect-me-col" style="text-align:left;">A two year deal is one of the shortest fixed rate terms Santander offer. At the end of the fixed rate period, you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151146 comp-affect-me-col" style="text-align:left;">A two year deal is one of the shortest fixed rate terms Santander offer. At the end of the fixed rate period, you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151186 comp-affect-me-col" style="text-align:left;">A two year deal is one of the shortest fixed rate terms Santander offer. At the end of the fixed rate period, you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151181 comp-affect-me-col" style="text-align:left;">A two year deal is one of the shortest fixed rate terms Santander offer. At the end of the fixed rate period, you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151396 comp-affect-me-col" style="text-align:left;">Our tracker rates are available over two years. The rate tracks above the Bank of England base rate during the tracker period. At the end of the tracker period you will need to select a new product, or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate interest rate changes which will alter your mortgage payments.</td>
                                                    <td class="m-nid-col m-nid-151401 comp-affect-me-col" style="text-align:left;">Our tracker rates are available over two years. The rate tracks above the Bank of England base rate during the tracker period. At the end of the tracker period you will need to select a new product, or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate interest rate changes which will alter your mortgage payments.</td>
                                                    <td class="m-nid-col m-nid-151241 comp-affect-me-col" style="text-align:left;">You will know what your payments will be over five years, giving you peace of mind. You will also benefit from only having paid one product fee during the five year fixed rate period. However, at the end of the fixed rate period you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151201 comp-affect-me-col" style="text-align:left;">A two year deal is one of the shortest fixed rate terms Santander offer. At the end of the fixed rate period, you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151236 comp-affect-me-col" style="text-align:left;">You will know what your payments will be over five years, giving you peace of mind. You will also benefit from only having paid one product fee during the five year fixed rate period. However, at the end of the fixed rate period you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151211 comp-affect-me-col" style="text-align:left;">A two year deal is one of the shortest fixed rate terms Santander offer. At the end of the fixed rate period, you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151206 comp-affect-me-col" style="text-align:left;">A two year deal is one of the shortest fixed rate terms Santander offer. At the end of the fixed rate period, you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151381 comp-affect-me-col" style="text-align:left;">Our tracker rates are available over two years. The rate tracks above the Bank of England base rate during the tracker period. At the end of the tracker period you will need to select a new product, or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate interest rate changes which will alter your mortgage payments.</td>
                                                    <td class="m-nid-col m-nid-151216 comp-affect-me-col" style="text-align:left;">A two year deal is one of the shortest fixed rate terms Santander offer. At the end of the fixed rate period, you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151376 comp-affect-me-col" style="text-align:left;">Our tracker rates are available over two years. The rate tracks above the Bank of England base rate during the tracker period. At the end of the tracker period you will need to select a new product, or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate interest rate changes which will alter your mortgage payments.</td>
                                                    <td class="m-nid-col m-nid-151281 comp-affect-me-col" style="text-align:left;">You will know what your payments will be over five years, giving you peace of mind. You will also benefit from only having paid one product fee during the five year fixed rate period. However, at the end of the fixed rate period you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151276 comp-affect-me-col" style="text-align:left;">You will know what your payments will be over five years, giving you peace of mind. You will also benefit from only having paid one product fee during the five year fixed rate period. However, at the end of the fixed rate period you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151296 comp-affect-me-col" style="text-align:left;">You will know what your payments will be over five years, giving you peace of mind. You will also benefit from only having paid one product fee during the five year fixed rate period. However, at the end of the fixed rate period you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151261 comp-affect-me-col" style="text-align:left;">You will know what your payments will be over five years, giving you peace of mind. You will also benefit from only having paid one product fee during the five year fixed rate period. However, at the end of the fixed rate period you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151256 comp-affect-me-col" style="text-align:left;">You will know what your payments will be over five years, giving you peace of mind. You will also benefit from only having paid one product fee during the five year fixed rate period. However, at the end of the fixed rate period you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151251 comp-affect-me-col" style="text-align:left;">You will know what your payments will be over five years, giving you peace of mind. You will also benefit from only having paid one product fee during the five year fixed rate period. However, at the end of the fixed rate period you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151246 comp-affect-me-col" style="text-align:left;">You will know what your payments will be over five years, giving you peace of mind. You will also benefit from only having paid one product fee during the five year fixed rate period. However, at the end of the fixed rate period you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151306 comp-affect-me-col" style="text-align:left;">You will know what your payments will be over five years, giving you peace of mind. You will also benefit from only having paid one product fee during the five year fixed rate period. However, at the end of the fixed rate period you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151301 comp-affect-me-col" style="text-align:left;">You will know what your payments will be over five years, giving you peace of mind. You will also benefit from only having paid one product fee during the five year fixed rate period. However, at the end of the fixed rate period you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151286 comp-affect-me-col" style="text-align:left;">You will know what your payments will be over five years, giving you peace of mind. You will also benefit from only having paid one product fee during the five year fixed rate period. However, at the end of the fixed rate period you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151326 comp-affect-me-col" style="text-align:left;">You will know what your payments will be over five years, giving you peace of mind. You will also benefit from only having paid one product fee during the five year fixed rate period. However, at the end of the fixed rate period you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151321 comp-affect-me-col" style="text-align:left;">You will know what your payments will be over five years, giving you peace of mind. You will also benefit from only having paid one product fee during the five year fixed rate period. However, at the end of the fixed rate period you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151291 comp-affect-me-col" style="text-align:left;">You will know what your payments will be over five years, giving you peace of mind. You will also benefit from only having paid one product fee during the five year fixed rate period. However, at the end of the fixed rate period you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151271 comp-affect-me-col" style="text-align:left;">You will know what your payments will be over five years, giving you peace of mind. You will also benefit from only having paid one product fee during the five year fixed rate period. However, at the end of the fixed rate period you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151221 comp-affect-me-col" style="text-align:left;">A two year deal is one of the shortest fixed rate terms Santander offer. At the end of the fixed rate period, you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151226 comp-affect-me-col" style="text-align:left;">A two year deal is one of the shortest fixed rate terms Santander offer. At the end of the fixed rate period, you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151266 comp-affect-me-col" style="text-align:left;">You will know what your payments will be over five years, giving you peace of mind. You will also benefit from only having paid one product fee during the five year fixed rate period. However, at the end of the fixed rate period you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151421 comp-affect-me-col" style="text-align:left;">The rate tracks above the Bank of England base rate for the life of the mortgage term. This is a Lifetime Tracker rate and means you needn’t look for a new deal every few years.</td>
                                                    <td class="m-nid-col m-nid-151426 comp-affect-me-col" style="text-align:left;">The rate tracks above the Bank of England base rate for the life of the mortgage term. This is a Lifetime Tracker rate and means you needn’t look for a new deal every few years.</td>
                                                    <td class="m-nid-col m-nid-151416 comp-affect-me-col" style="text-align:left;">The rate tracks above the Bank of England base rate for the life of the mortgage term. This is a Lifetime Tracker rate and means you needn’t look for a new deal every few years.</td>
                                                    <td class="m-nid-col m-nid-151411 comp-affect-me-col" style="text-align:left;">The rate tracks above the Bank of England base rate for the life of the mortgage term. This is a Lifetime Tracker rate and means you needn’t look for a new deal every few years.</td>
                                                    <td class="m-nid-col m-nid-151311 comp-affect-me-col" style="text-align:left;">You will know what your payments will be over five years, giving you peace of mind. You will also benefit from only having paid one product fee during the five year fixed rate period. However, at the end of the fixed rate period you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151316 comp-affect-me-col" style="text-align:left;">You will know what your payments will be over five years, giving you peace of mind. You will also benefit from only having paid one product fee during the five year fixed rate period. However, at the end of the fixed rate period you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151331 comp-affect-me-col" style="text-align:left;">You will know what your payments will be over five years, giving you peace of mind. You will also benefit from only having paid one product fee during the five year fixed rate period. However, at the end of the fixed rate period you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151336 comp-affect-me-col" style="text-align:left;">You will know what your payments will be over five years, giving you peace of mind. You will also benefit from only having paid one product fee during the five year fixed rate period. However, at the end of the fixed rate period you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151341 comp-affect-me-col" style="text-align:left;">You will know what your payments will be over five years, giving you peace of mind. You will also benefit from only having paid one product fee during the five year fixed rate period. However, at the end of the fixed rate period you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151346 comp-affect-me-col" style="text-align:left;">You will know what your payments will be over five years, giving you peace of mind. You will also benefit from only having paid one product fee during the five year fixed rate period. However, at the end of the fixed rate period you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151351 comp-affect-me-col" style="text-align:left;">You will know what your payments will be over five years, giving you peace of mind. You will also benefit from only having paid one product fee during the five year fixed rate period. However, at the end of the fixed rate period you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151356 comp-affect-me-col" style="text-align:left;">You will know what your payments will be over five years, giving you peace of mind. You will also benefit from only having paid one product fee during the five year fixed rate period. However, at the end of the fixed rate period you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151231 comp-affect-me-col" style="text-align:left;">A two year deal is one of the shortest fixed rate terms Santander offer. At the end of the fixed rate period, you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>
                                                    <td class="m-nid-col m-nid-151406 comp-affect-me-col" style="text-align:left;">Our tracker rates are available over two years. The rate tracks above the Bank of England base rate during the tracker period. At the end of the tracker period you will need to select a new product, or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate interest rate changes which will alter your mortgage payments.</td>
                                                    <td class="m-nid-col m-nid-151361 comp-affect-me-col" style="text-align:left;">You will know what your payments will be over five years, giving you peace of mind. You will also benefit from only having paid one product fee during the five year fixed rate period. However, at the end of the fixed rate period you will need to select a new deal or you will revert to our Follow-on Rate (FoR). Your budget will need to accommodate changes to your mortgage payments after the fixed rate period.</td>                            </tr>
                                                <tr class="r">
                                                    <th>Initial rate</th>

                                                    <td class="m-nid-col m-nid-151366">1.29%</td>
                                                    <td class="m-nid-col m-nid-151151">1.29%</td>
                                                    <td class="m-nid-col m-nid-151156">1.29%</td>
                                                    <td class="m-nid-col m-nid-151371">1.29%</td>
                                                    <td class="m-nid-col m-nid-151121">1.34%</td>
                                                    <td class="m-nid-col m-nid-151126">1.34%</td>
                                                    <td class="m-nid-col m-nid-151161">1.39%</td>
                                                    <td class="m-nid-col m-nid-151166">1.39%</td>
                                                    <td class="m-nid-col m-nid-151176">1.44%</td>
                                                    <td class="m-nid-col m-nid-151171">1.44%</td>
                                                    <td class="m-nid-col m-nid-151196">1.54%</td>
                                                    <td class="m-nid-col m-nid-151191">1.54%</td>
                                                    <td class="m-nid-col m-nid-151391">1.59%</td>
                                                    <td class="m-nid-col m-nid-151386">1.59%</td>
                                                    <td class="m-nid-col m-nid-151131">1.74%</td>
                                                    <td class="m-nid-col m-nid-151136">1.74%</td>
                                                    <td class="m-nid-col m-nid-151141">1.74%</td>
                                                    <td class="m-nid-col m-nid-151146">1.74%</td>
                                                    <td class="m-nid-col m-nid-151186">1.79%</td>
                                                    <td class="m-nid-col m-nid-151181">1.79%</td>
                                                    <td class="m-nid-col m-nid-151396">1.84%</td>
                                                    <td class="m-nid-col m-nid-151401">1.84%</td>
                                                    <td class="m-nid-col m-nid-151241">1.89%</td>
                                                    <td class="m-nid-col m-nid-151201">1.89%</td>
                                                    <td class="m-nid-col m-nid-151236">1.89%</td>
                                                    <td class="m-nid-col m-nid-151211">1.94%</td>
                                                    <td class="m-nid-col m-nid-151206">1.94%</td>
                                                    <td class="m-nid-col m-nid-151381">1.94%</td>
                                                    <td class="m-nid-col m-nid-151216">1.94%</td>
                                                    <td class="m-nid-col m-nid-151376">1.94%</td>
                                                    <td class="m-nid-col m-nid-151281">1.99%</td>
                                                    <td class="m-nid-col m-nid-151276">1.99%</td>
                                                    <td class="m-nid-col m-nid-151296">2.04%</td>
                                                    <td class="m-nid-col m-nid-151261">2.09%</td>
                                                    <td class="m-nid-col m-nid-151256">2.09%</td>
                                                    <td class="m-nid-col m-nid-151251">2.14%</td>
                                                    <td class="m-nid-col m-nid-151246">2.14%</td>
                                                    <td class="m-nid-col m-nid-151306">2.19%</td>
                                                    <td class="m-nid-col m-nid-151301">2.19%</td>
                                                    <td class="m-nid-col m-nid-151286">2.24%</td>
                                                    <td class="m-nid-col m-nid-151326">2.24%</td>
                                                    <td class="m-nid-col m-nid-151321">2.24%</td>
                                                    <td class="m-nid-col m-nid-151291">2.24%</td>
                                                    <td class="m-nid-col m-nid-151271">2.29%</td>
                                                    <td class="m-nid-col m-nid-151221">2.29%</td>
                                                    <td class="m-nid-col m-nid-151226">2.29%</td>
                                                    <td class="m-nid-col m-nid-151266">2.29%</td>
                                                    <td class="m-nid-col m-nid-151421">2.34%</td>
                                                    <td class="m-nid-col m-nid-151426">2.34%</td>
                                                    <td class="m-nid-col m-nid-151416">2.39%</td>
                                                    <td class="m-nid-col m-nid-151411">2.39%</td>
                                                    <td class="m-nid-col m-nid-151311">2.49%</td>
                                                    <td class="m-nid-col m-nid-151316">2.49%</td>
                                                    <td class="m-nid-col m-nid-151331">2.59%</td>
                                                    <td class="m-nid-col m-nid-151336">2.59%</td>
                                                    <td class="m-nid-col m-nid-151341">2.74%</td>
                                                    <td class="m-nid-col m-nid-151346">2.74%</td>
                                                    <td class="m-nid-col m-nid-151351">3.04%</td>
                                                    <td class="m-nid-col m-nid-151356">3.14%</td>
                                                    <td class="m-nid-col m-nid-151231">3.89%</td>
                                                    <td class="m-nid-col m-nid-151406">3.99%</td>
                                                    <td class="m-nid-col m-nid-151361">4.44%</td>                            </tr>
                                                <tr class="r">
                                                    <th>Differential to Bank of England base rate (currently 0.50%)</th>

                                                    <td class="m-nid-col m-nid-151366">0.79%</td>
                                                    <td class="m-nid-col m-nid-151151">n/a</td>
                                                    <td class="m-nid-col m-nid-151156">n/a</td>
                                                    <td class="m-nid-col m-nid-151371">0.79%</td>
                                                    <td class="m-nid-col m-nid-151121">n/a</td>
                                                    <td class="m-nid-col m-nid-151126">n/a</td>
                                                    <td class="m-nid-col m-nid-151161">n/a</td>
                                                    <td class="m-nid-col m-nid-151166">n/a</td>
                                                    <td class="m-nid-col m-nid-151176">n/a</td>
                                                    <td class="m-nid-col m-nid-151171">n/a</td>
                                                    <td class="m-nid-col m-nid-151196">n/a</td>
                                                    <td class="m-nid-col m-nid-151191">n/a</td>
                                                    <td class="m-nid-col m-nid-151391">1.09%</td>
                                                    <td class="m-nid-col m-nid-151386">1.09%</td>
                                                    <td class="m-nid-col m-nid-151131">n/a</td>
                                                    <td class="m-nid-col m-nid-151136">n/a</td>
                                                    <td class="m-nid-col m-nid-151141">n/a</td>
                                                    <td class="m-nid-col m-nid-151146">n/a</td>
                                                    <td class="m-nid-col m-nid-151186">n/a</td>
                                                    <td class="m-nid-col m-nid-151181">n/a</td>
                                                    <td class="m-nid-col m-nid-151396">1.34%</td>
                                                    <td class="m-nid-col m-nid-151401">1.34%</td>
                                                    <td class="m-nid-col m-nid-151241">n/a</td>
                                                    <td class="m-nid-col m-nid-151201">n/a</td>
                                                    <td class="m-nid-col m-nid-151236">n/a</td>
                                                    <td class="m-nid-col m-nid-151211">n/a</td>
                                                    <td class="m-nid-col m-nid-151206">n/a</td>
                                                    <td class="m-nid-col m-nid-151381">1.44%</td>
                                                    <td class="m-nid-col m-nid-151216">n/a</td>
                                                    <td class="m-nid-col m-nid-151376">1.44%</td>
                                                    <td class="m-nid-col m-nid-151281">n/a</td>
                                                    <td class="m-nid-col m-nid-151276">n/a</td>
                                                    <td class="m-nid-col m-nid-151296">n/a</td>
                                                    <td class="m-nid-col m-nid-151261">n/a</td>
                                                    <td class="m-nid-col m-nid-151256">n/a</td>
                                                    <td class="m-nid-col m-nid-151251">n/a</td>
                                                    <td class="m-nid-col m-nid-151246">n/a</td>
                                                    <td class="m-nid-col m-nid-151306">n/a</td>
                                                    <td class="m-nid-col m-nid-151301">n/a</td>
                                                    <td class="m-nid-col m-nid-151286">n/a</td>
                                                    <td class="m-nid-col m-nid-151326">n/a</td>
                                                    <td class="m-nid-col m-nid-151321">n/a</td>
                                                    <td class="m-nid-col m-nid-151291">n/a</td>
                                                    <td class="m-nid-col m-nid-151271">n/a</td>
                                                    <td class="m-nid-col m-nid-151221">n/a</td>
                                                    <td class="m-nid-col m-nid-151226">n/a</td>
                                                    <td class="m-nid-col m-nid-151266">n/a</td>
                                                    <td class="m-nid-col m-nid-151421">1.84%</td>
                                                    <td class="m-nid-col m-nid-151426">1.84%</td>
                                                    <td class="m-nid-col m-nid-151416">1.89%</td>
                                                    <td class="m-nid-col m-nid-151411">1.89%</td>
                                                    <td class="m-nid-col m-nid-151311">n/a</td>
                                                    <td class="m-nid-col m-nid-151316">n/a</td>
                                                    <td class="m-nid-col m-nid-151331">n/a</td>
                                                    <td class="m-nid-col m-nid-151336">n/a</td>
                                                    <td class="m-nid-col m-nid-151341">n/a</td>
                                                    <td class="m-nid-col m-nid-151346">n/a</td>
                                                    <td class="m-nid-col m-nid-151351">n/a</td>
                                                    <td class="m-nid-col m-nid-151356">n/a</td>
                                                    <td class="m-nid-col m-nid-151231">n/a</td>
                                                    <td class="m-nid-col m-nid-151406">3.49%</td>
                                                    <td class="m-nid-col m-nid-151361">n/a</td>                            </tr>
                                                <tr class="r">
                                                    <th>Then changing to Santander's Follow-on Rate (variable)</th>

                                                    <td class="m-nid-col m-nid-151366">3.75%</td>
                                                    <td class="m-nid-col m-nid-151151">3.75%</td>
                                                    <td class="m-nid-col m-nid-151156">3.75%</td>
                                                    <td class="m-nid-col m-nid-151371">3.75%</td>
                                                    <td class="m-nid-col m-nid-151121">3.75%</td>
                                                    <td class="m-nid-col m-nid-151126">3.75%</td>
                                                    <td class="m-nid-col m-nid-151161">3.75%</td>
                                                    <td class="m-nid-col m-nid-151166">3.75%</td>
                                                    <td class="m-nid-col m-nid-151176">3.75%</td>
                                                    <td class="m-nid-col m-nid-151171">3.75%</td>
                                                    <td class="m-nid-col m-nid-151196">3.75%</td>
                                                    <td class="m-nid-col m-nid-151191">3.75%</td>
                                                    <td class="m-nid-col m-nid-151391">3.75%</td>
                                                    <td class="m-nid-col m-nid-151386">3.75%</td>
                                                    <td class="m-nid-col m-nid-151131">3.75%</td>
                                                    <td class="m-nid-col m-nid-151136">3.75%</td>
                                                    <td class="m-nid-col m-nid-151141">3.75%</td>
                                                    <td class="m-nid-col m-nid-151146">3.75%</td>
                                                    <td class="m-nid-col m-nid-151186">3.75%</td>
                                                    <td class="m-nid-col m-nid-151181">3.75%</td>
                                                    <td class="m-nid-col m-nid-151396">3.75%</td>
                                                    <td class="m-nid-col m-nid-151401">3.75%</td>
                                                    <td class="m-nid-col m-nid-151241">3.75%</td>
                                                    <td class="m-nid-col m-nid-151201">3.75%</td>
                                                    <td class="m-nid-col m-nid-151236">3.75%</td>
                                                    <td class="m-nid-col m-nid-151211">3.75%</td>
                                                    <td class="m-nid-col m-nid-151206">3.75%</td>
                                                    <td class="m-nid-col m-nid-151381">3.75%</td>
                                                    <td class="m-nid-col m-nid-151216">3.75%</td>
                                                    <td class="m-nid-col m-nid-151376">3.75%</td>
                                                    <td class="m-nid-col m-nid-151281">3.75%</td>
                                                    <td class="m-nid-col m-nid-151276">3.75%</td>
                                                    <td class="m-nid-col m-nid-151296">3.75%</td>
                                                    <td class="m-nid-col m-nid-151261">3.75%</td>
                                                    <td class="m-nid-col m-nid-151256">3.75%</td>
                                                    <td class="m-nid-col m-nid-151251">3.75%</td>
                                                    <td class="m-nid-col m-nid-151246">3.75%</td>
                                                    <td class="m-nid-col m-nid-151306">3.75%</td>
                                                    <td class="m-nid-col m-nid-151301">3.75%</td>
                                                    <td class="m-nid-col m-nid-151286">3.75%</td>
                                                    <td class="m-nid-col m-nid-151326">3.75%</td>
                                                    <td class="m-nid-col m-nid-151321">3.75%</td>
                                                    <td class="m-nid-col m-nid-151291">3.75%</td>
                                                    <td class="m-nid-col m-nid-151271">3.75%</td>
                                                    <td class="m-nid-col m-nid-151221">3.75%</td>
                                                    <td class="m-nid-col m-nid-151226">3.75%</td>
                                                    <td class="m-nid-col m-nid-151266">3.75%</td>
                                                    <td class="m-nid-col m-nid-151421">n/a</td>
                                                    <td class="m-nid-col m-nid-151426">n/a</td>
                                                    <td class="m-nid-col m-nid-151416">n/a</td>
                                                    <td class="m-nid-col m-nid-151411">n/a</td>
                                                    <td class="m-nid-col m-nid-151311">3.75%</td>
                                                    <td class="m-nid-col m-nid-151316">3.75%</td>
                                                    <td class="m-nid-col m-nid-151331">3.75%</td>
                                                    <td class="m-nid-col m-nid-151336">3.75%</td>
                                                    <td class="m-nid-col m-nid-151341">3.75%</td>
                                                    <td class="m-nid-col m-nid-151346">3.75%</td>
                                                    <td class="m-nid-col m-nid-151351">3.75%</td>
                                                    <td class="m-nid-col m-nid-151356">3.75%</td>
                                                    <td class="m-nid-col m-nid-151231">3.75%</td>
                                                    <td class="m-nid-col m-nid-151406">3.75%</td>
                                                    <td class="m-nid-col m-nid-151361">3.75%</td>                            </tr>
                                                <tr class="r">
                                                    <th>The overall cost for comparison is (APR)</th>

                                                    <td class="m-nid-col m-nid-151366">3.0%</td>
                                                    <td class="m-nid-col m-nid-151151">3.3%</td>
                                                    <td class="m-nid-col m-nid-151156">3.3%</td>
                                                    <td class="m-nid-col m-nid-151371">3.2%</td>
                                                    <td class="m-nid-col m-nid-151121">3.3%</td>
                                                    <td class="m-nid-col m-nid-151126">3.3%</td>
                                                    <td class="m-nid-col m-nid-151161">3.4%</td>
                                                    <td class="m-nid-col m-nid-151166">3.4%</td>
                                                    <td class="m-nid-col m-nid-151176">3.4%</td>
                                                    <td class="m-nid-col m-nid-151171">3.4%</td>
                                                    <td class="m-nid-col m-nid-151196">3.4%</td>
                                                    <td class="m-nid-col m-nid-151191">3.4%</td>
                                                    <td class="m-nid-col m-nid-151391">3.4%</td>
                                                    <td class="m-nid-col m-nid-151386">3.2%</td>
                                                    <td class="m-nid-col m-nid-151131">3.2%</td>
                                                    <td class="m-nid-col m-nid-151136">3.3%</td>
                                                    <td class="m-nid-col m-nid-151141">3.5%</td>
                                                    <td class="m-nid-col m-nid-151146">3.5%</td>
                                                    <td class="m-nid-col m-nid-151186">3.5%</td>
                                                    <td class="m-nid-col m-nid-151181">3.4%</td>
                                                    <td class="m-nid-col m-nid-151396">3.5%</td>
                                                    <td class="m-nid-col m-nid-151401">3.5%</td>
                                                    <td class="m-nid-col m-nid-151241">3.0%</td>
                                                    <td class="m-nid-col m-nid-151201">3.5%</td>
                                                    <td class="m-nid-col m-nid-151236">2.8%</td>
                                                    <td class="m-nid-col m-nid-151211">3.5%</td>
                                                    <td class="m-nid-col m-nid-151206">3.4%</td>
                                                    <td class="m-nid-col m-nid-151381">3.5%</td>
                                                    <td class="m-nid-col m-nid-151216">3.5%</td>
                                                    <td class="m-nid-col m-nid-151376">3.5%</td>
                                                    <td class="m-nid-col m-nid-151281">3.1%</td>
                                                    <td class="m-nid-col m-nid-151276">3.0%</td>
                                                    <td class="m-nid-col m-nid-151296">3.2%</td>
                                                    <td class="m-nid-col m-nid-151261">3.1%</td>
                                                    <td class="m-nid-col m-nid-151256">3.1%</td>
                                                    <td class="m-nid-col m-nid-151251">2.8%</td>
                                                    <td class="m-nid-col m-nid-151246">2.6%</td>
                                                    <td class="m-nid-col m-nid-151306">3.2%</td>
                                                    <td class="m-nid-col m-nid-151301">3.2%</td>
                                                    <td class="m-nid-col m-nid-151286">3.0%</td>
                                                    <td class="m-nid-col m-nid-151326">3.2%</td>
                                                    <td class="m-nid-col m-nid-151321">3.2%</td>
                                                    <td class="m-nid-col m-nid-151291">3.2%</td>
                                                    <td class="m-nid-col m-nid-151271">3.2%</td>
                                                    <td class="m-nid-col m-nid-151221">3.5%</td>
                                                    <td class="m-nid-col m-nid-151226">3.6%</td>
                                                    <td class="m-nid-col m-nid-151266">3.2%</td>
                                                    <td class="m-nid-col m-nid-151421">2.4%</td>
                                                    <td class="m-nid-col m-nid-151426">2.4%</td>
                                                    <td class="m-nid-col m-nid-151416">2.5%</td>
                                                    <td class="m-nid-col m-nid-151411">2.4%</td>
                                                    <td class="m-nid-col m-nid-151311">3.3%</td>
                                                    <td class="m-nid-col m-nid-151316">3.3%</td>
                                                    <td class="m-nid-col m-nid-151331">3.3%</td>
                                                    <td class="m-nid-col m-nid-151336">3.4%</td>
                                                    <td class="m-nid-col m-nid-151341">3.3%</td>
                                                    <td class="m-nid-col m-nid-151346">3.4%</td>
                                                    <td class="m-nid-col m-nid-151351">3.6%</td>
                                                    <td class="m-nid-col m-nid-151356">3.6%</td>
                                                    <td class="m-nid-col m-nid-151231">3.9%</td>
                                                    <td class="m-nid-col m-nid-151406">3.9%</td>
                                                    <td class="m-nid-col m-nid-151361">4.1%</td>                            </tr>
                                                <tr class="r">
                                                    <th>Product fee</th>

                                                    <td class="m-nid-col m-nid-151366">£999</td>
                                                    <td class="m-nid-col m-nid-151151">£1499</td>
                                                    <td class="m-nid-col m-nid-151156">£1499</td>
                                                    <td class="m-nid-col m-nid-151371">£999</td>
                                                    <td class="m-nid-col m-nid-151121">£999</td>
                                                    <td class="m-nid-col m-nid-151126">£999</td>
                                                    <td class="m-nid-col m-nid-151161">£999</td>
                                                    <td class="m-nid-col m-nid-151166">£999</td>
                                                    <td class="m-nid-col m-nid-151176">£999</td>
                                                    <td class="m-nid-col m-nid-151171">£999</td>
                                                    <td class="m-nid-col m-nid-151196">£999</td>
                                                    <td class="m-nid-col m-nid-151191">£999</td>
                                                    <td class="m-nid-col m-nid-151391">£999</td>
                                                    <td class="m-nid-col m-nid-151386">£999</td>
                                                    <td class="m-nid-col m-nid-151131">£0</td>
                                                    <td class="m-nid-col m-nid-151136">£0</td>
                                                    <td class="m-nid-col m-nid-151141">£1999</td>
                                                    <td class="m-nid-col m-nid-151146">£1999</td>
                                                    <td class="m-nid-col m-nid-151186">£0</td>
                                                    <td class="m-nid-col m-nid-151181">£0</td>
                                                    <td class="m-nid-col m-nid-151396">£999</td>
                                                    <td class="m-nid-col m-nid-151401">£999</td>
                                                    <td class="m-nid-col m-nid-151241">£999</td>
                                                    <td class="m-nid-col m-nid-151201">£0</td>
                                                    <td class="m-nid-col m-nid-151236">£999</td>
                                                    <td class="m-nid-col m-nid-151211">£0</td>
                                                    <td class="m-nid-col m-nid-151206">£0</td>
                                                    <td class="m-nid-col m-nid-151381">£1999</td>
                                                    <td class="m-nid-col m-nid-151216">£999</td>
                                                    <td class="m-nid-col m-nid-151376">£1999</td>
                                                    <td class="m-nid-col m-nid-151281">£999</td>
                                                    <td class="m-nid-col m-nid-151276">£999</td>
                                                    <td class="m-nid-col m-nid-151296">£999</td>
                                                    <td class="m-nid-col m-nid-151261">£1999</td>
                                                    <td class="m-nid-col m-nid-151256">£1999</td>
                                                    <td class="m-nid-col m-nid-151251">£0</td>
                                                    <td class="m-nid-col m-nid-151246">£0</td>
                                                    <td class="m-nid-col m-nid-151306">£999</td>
                                                    <td class="m-nid-col m-nid-151301">£999</td>
                                                    <td class="m-nid-col m-nid-151286">£0</td>
                                                    <td class="m-nid-col m-nid-151326">£999</td>
                                                    <td class="m-nid-col m-nid-151321">£999</td>
                                                    <td class="m-nid-col m-nid-151291">£0</td>
                                                    <td class="m-nid-col m-nid-151271">£1999</td>
                                                    <td class="m-nid-col m-nid-151221">£0</td>
                                                    <td class="m-nid-col m-nid-151226">£0</td>
                                                    <td class="m-nid-col m-nid-151266">£1999</td>
                                                    <td class="m-nid-col m-nid-151421">£999</td>
                                                    <td class="m-nid-col m-nid-151426">£999</td>
                                                    <td class="m-nid-col m-nid-151416">£999</td>
                                                    <td class="m-nid-col m-nid-151411">£999</td>
                                                    <td class="m-nid-col m-nid-151311">£0</td>
                                                    <td class="m-nid-col m-nid-151316">£0</td>
                                                    <td class="m-nid-col m-nid-151331">£0</td>
                                                    <td class="m-nid-col m-nid-151336">£0</td>
                                                    <td class="m-nid-col m-nid-151341">£999</td>
                                                    <td class="m-nid-col m-nid-151346">£999</td>
                                                    <td class="m-nid-col m-nid-151351">£0</td>
                                                    <td class="m-nid-col m-nid-151356">£0</td>
                                                    <td class="m-nid-col m-nid-151231">£0</td>
                                                    <td class="m-nid-col m-nid-151406">£0</td>
                                                    <td class="m-nid-col m-nid-151361">£0</td>                            </tr>
                                                <tr class="r">
                                                    <th>When does this rate end?</th>

                                                    <td class="m-nid-col m-nid-151366">2nd anniversary</td>
                                                    <td class="m-nid-col m-nid-151151">2 June 2020</td>
                                                    <td class="m-nid-col m-nid-151156">2 June 2020</td>
                                                    <td class="m-nid-col m-nid-151371">2nd anniversary</td>
                                                    <td class="m-nid-col m-nid-151121">2 June 2020</td>
                                                    <td class="m-nid-col m-nid-151126">2 June 2020</td>
                                                    <td class="m-nid-col m-nid-151161">2 June 2020</td>
                                                    <td class="m-nid-col m-nid-151166">2 June 2020</td>
                                                    <td class="m-nid-col m-nid-151176">2 June 2020</td>
                                                    <td class="m-nid-col m-nid-151171">2 June 2020</td>
                                                    <td class="m-nid-col m-nid-151196">2 June 2020</td>
                                                    <td class="m-nid-col m-nid-151191">2 June 2020</td>
                                                    <td class="m-nid-col m-nid-151391">2nd anniversary</td>
                                                    <td class="m-nid-col m-nid-151386">2nd anniversary</td>
                                                    <td class="m-nid-col m-nid-151131">2 June 2020</td>
                                                    <td class="m-nid-col m-nid-151136">2 June 2020</td>
                                                    <td class="m-nid-col m-nid-151141">2 June 2020</td>
                                                    <td class="m-nid-col m-nid-151146">2 June 2020</td>
                                                    <td class="m-nid-col m-nid-151186">2 June 2020</td>
                                                    <td class="m-nid-col m-nid-151181">2 June 2020</td>
                                                    <td class="m-nid-col m-nid-151396">2nd anniversary</td>
                                                    <td class="m-nid-col m-nid-151401">2nd anniversary</td>
                                                    <td class="m-nid-col m-nid-151241">2 June 2023</td>
                                                    <td class="m-nid-col m-nid-151201">2 June 2020</td>
                                                    <td class="m-nid-col m-nid-151236">2 June 2023</td>
                                                    <td class="m-nid-col m-nid-151211">2 June 2020</td>
                                                    <td class="m-nid-col m-nid-151206">2 June 2020</td>
                                                    <td class="m-nid-col m-nid-151381">2nd anniversary</td>
                                                    <td class="m-nid-col m-nid-151216">2 June 2020</td>
                                                    <td class="m-nid-col m-nid-151376">2nd anniversary</td>
                                                    <td class="m-nid-col m-nid-151281">2 June 2023</td>
                                                    <td class="m-nid-col m-nid-151276">2 June 2023</td>
                                                    <td class="m-nid-col m-nid-151296">2 June 2023</td>
                                                    <td class="m-nid-col m-nid-151261">2 June 2023</td>
                                                    <td class="m-nid-col m-nid-151256">2 June 2023</td>
                                                    <td class="m-nid-col m-nid-151251">2 June 2023</td>
                                                    <td class="m-nid-col m-nid-151246">2 June 2023</td>
                                                    <td class="m-nid-col m-nid-151306">2 June 2023</td>
                                                    <td class="m-nid-col m-nid-151301">2 June 2023</td>
                                                    <td class="m-nid-col m-nid-151286">2 June 2023</td>
                                                    <td class="m-nid-col m-nid-151326">2 June 2023</td>
                                                    <td class="m-nid-col m-nid-151321">2 June 2023</td>
                                                    <td class="m-nid-col m-nid-151291">2 June 2023</td>
                                                    <td class="m-nid-col m-nid-151271">2 June 2023</td>
                                                    <td class="m-nid-col m-nid-151221">2 June 2020</td>
                                                    <td class="m-nid-col m-nid-151226">2 June 2020</td>
                                                    <td class="m-nid-col m-nid-151266">2 June 2023</td>
                                                    <td class="m-nid-col m-nid-151421">N/A</td>
                                                    <td class="m-nid-col m-nid-151426">N/A</td>
                                                    <td class="m-nid-col m-nid-151416">N/A</td>
                                                    <td class="m-nid-col m-nid-151411">N/A</td>
                                                    <td class="m-nid-col m-nid-151311">2 June 2023</td>
                                                    <td class="m-nid-col m-nid-151316">2 June 2023</td>
                                                    <td class="m-nid-col m-nid-151331">2 June 2023</td>
                                                    <td class="m-nid-col m-nid-151336">2 June 2023</td>
                                                    <td class="m-nid-col m-nid-151341">2 June 2023</td>
                                                    <td class="m-nid-col m-nid-151346">2 June 2023</td>
                                                    <td class="m-nid-col m-nid-151351">2 June 2023</td>
                                                    <td class="m-nid-col m-nid-151356">2 June 2023</td>
                                                    <td class="m-nid-col m-nid-151231">2 June 2020</td>
                                                    <td class="m-nid-col m-nid-151406">2nd anniversary</td>
                                                    <td class="m-nid-col m-nid-151361">2 June 2023</td>                            </tr>
                                                <tr class="r">
                                                    <th>Additional benefits</th>

                                                    <td class="m-nid-col m-nid-151366">Free valuation and standard legal fees paid</td>
                                                    <td class="m-nid-col m-nid-151151">Free valuation and standard legal fees paid</td>
                                                    <td class="m-nid-col m-nid-151156">Free Valuation</td>
                                                    <td class="m-nid-col m-nid-151371">Free Valuation</td>
                                                    <td class="m-nid-col m-nid-151121">Free valuation and standard legal fees paid</td>
                                                    <td class="m-nid-col m-nid-151126">Free Valuation</td>
                                                    <td class="m-nid-col m-nid-151161">Free valuation and standard legal fees paid</td>
                                                    <td class="m-nid-col m-nid-151166">Free Valuation</td>
                                                    <td class="m-nid-col m-nid-151176">Free Valuation</td>
                                                    <td class="m-nid-col m-nid-151171">Free valuation and standard legal fees paid</td>
                                                    <td class="m-nid-col m-nid-151196">Free valuation and £250 cashback</td>
                                                    <td class="m-nid-col m-nid-151191">Free valuation and standard legal fees paid</td>
                                                    <td class="m-nid-col m-nid-151391">Free Valuation</td>
                                                    <td class="m-nid-col m-nid-151386">Free valuation and standard legal fees paid</td>
                                                    <td class="m-nid-col m-nid-151131">Free valuation and standard legal fees paid</td>
                                                    <td class="m-nid-col m-nid-151136">Free Valuation</td>
                                                    <td class="m-nid-col m-nid-151141">Free valuation and standard legal fees paid</td>
                                                    <td class="m-nid-col m-nid-151146">Free Valuation</td>
                                                    <td class="m-nid-col m-nid-151186">Free Valuation</td>
                                                    <td class="m-nid-col m-nid-151181">Free valuation and standard legal fees paid</td>
                                                    <td class="m-nid-col m-nid-151396">Free valuation and standard legal fees paid</td>
                                                    <td class="m-nid-col m-nid-151401">Free Valuation</td>
                                                    <td class="m-nid-col m-nid-151241">Free Valuation</td>
                                                    <td class="m-nid-col m-nid-151201">Free valuation and £250 cashback</td>
                                                    <td class="m-nid-col m-nid-151236">Free valuation and standard legal fees paid</td>
                                                    <td class="m-nid-col m-nid-151211">Free valuation and £250 cashback</td>
                                                    <td class="m-nid-col m-nid-151206">Free valuation and standard legal fees paid</td>
                                                    <td class="m-nid-col m-nid-151381">Free Valuation</td>
                                                    <td class="m-nid-col m-nid-151216">Free valuation and £250 cashback</td>
                                                    <td class="m-nid-col m-nid-151376">Free valuation and standard legal fees paid</td>
                                                    <td class="m-nid-col m-nid-151281">Free Valuation</td>
                                                    <td class="m-nid-col m-nid-151276">Free valuation and standard legal fees paid</td>
                                                    <td class="m-nid-col m-nid-151296">Free valuation and £250 cashback</td>
                                                    <td class="m-nid-col m-nid-151261">Free Valuation</td>
                                                    <td class="m-nid-col m-nid-151256">Free valuation and standard legal fees paid</td>
                                                    <td class="m-nid-col m-nid-151251">Free Valuation</td>
                                                    <td class="m-nid-col m-nid-151246">Free valuation and standard legal fees paid</td>
                                                    <td class="m-nid-col m-nid-151306">Free valuation and £250 cashback</td>
                                                    <td class="m-nid-col m-nid-151301">Free valuation and standard legal fees paid</td>
                                                    <td class="m-nid-col m-nid-151286">Free valuation and standard legal fees paid</td>
                                                    <td class="m-nid-col m-nid-151326">Free valuation and £250 cashback</td>
                                                    <td class="m-nid-col m-nid-151321">Free valuation and standard legal fees paid</td>
                                                    <td class="m-nid-col m-nid-151291">Free Valuation</td>
                                                    <td class="m-nid-col m-nid-151271">Free Valuation</td>
                                                    <td class="m-nid-col m-nid-151221">Free valuation and standard legal fees paid</td>
                                                    <td class="m-nid-col m-nid-151226">Free Valuation</td>
                                                    <td class="m-nid-col m-nid-151266">Free valuation and standard legal fees paid</td>
                                                    <td class="m-nid-col m-nid-151421">Free valuation and standard legal fees paid</td>
                                                    <td class="m-nid-col m-nid-151426">Free Valuation</td>
                                                    <td class="m-nid-col m-nid-151416">Free Valuation</td>
                                                    <td class="m-nid-col m-nid-151411">Free valuation and standard legal fees paid</td>
                                                    <td class="m-nid-col m-nid-151311">Free valuation and standard legal fees paid</td>
                                                    <td class="m-nid-col m-nid-151316">Free valuation and £250 cashback</td>
                                                    <td class="m-nid-col m-nid-151331">Free valuation and standard legal fees paid</td>
                                                    <td class="m-nid-col m-nid-151336">Free valuation and £250 cashback</td>
                                                    <td class="m-nid-col m-nid-151341">Free valuation and standard legal fees paid</td>
                                                    <td class="m-nid-col m-nid-151346">Free valuation and £250 cashback</td>
                                                    <td class="m-nid-col m-nid-151351">Free valuation and £250 cashback</td>
                                                    <td class="m-nid-col m-nid-151356">Free valuation and £250 cashback</td>
                                                    <td class="m-nid-col m-nid-151231">Free valuation and £250 cashback</td>
                                                    <td class="m-nid-col m-nid-151406">Free Valuation</td>
                                                    <td class="m-nid-col m-nid-151361">Free valuation and £250 cashback</td>                            </tr>
                                                <tr class="r">
                                                    <th>Early repayment charge (ERC)</th>

                                                    <td class="m-nid-col m-nid-151366">No ERC.
                                                        Repay paid legal fees</td>
                                                    <td class="m-nid-col m-nid-151151">3% + Repay paid legal fees</td>
                                                    <td class="m-nid-col m-nid-151156">3%</td>
                                                    <td class="m-nid-col m-nid-151371">No ERC.
                                                    </td>
                                                    <td class="m-nid-col m-nid-151121">3% + Repay paid legal fees</td>
                                                    <td class="m-nid-col m-nid-151126">3%</td>
                                                    <td class="m-nid-col m-nid-151161">3% + Repay paid legal fees</td>
                                                    <td class="m-nid-col m-nid-151166">3%</td>
                                                    <td class="m-nid-col m-nid-151176">3%</td>
                                                    <td class="m-nid-col m-nid-151171">3% + Repay paid legal fees</td>
                                                    <td class="m-nid-col m-nid-151196">3% + Repay £250 cashback</td>
                                                    <td class="m-nid-col m-nid-151191">3% + Repay paid legal fees</td>
                                                    <td class="m-nid-col m-nid-151391">No ERC.
                                                    </td>
                                                    <td class="m-nid-col m-nid-151386">No ERC.
                                                        Repay paid legal fees</td>
                                                    <td class="m-nid-col m-nid-151131">3% + Repay paid legal fees</td>
                                                    <td class="m-nid-col m-nid-151136">3%</td>
                                                    <td class="m-nid-col m-nid-151141">3% + Repay paid legal fees</td>
                                                    <td class="m-nid-col m-nid-151146">3%</td>
                                                    <td class="m-nid-col m-nid-151186">3%</td>
                                                    <td class="m-nid-col m-nid-151181">3% + Repay paid legal fees</td>
                                                    <td class="m-nid-col m-nid-151396">No ERC.
                                                        Repay paid legal fees</td>
                                                    <td class="m-nid-col m-nid-151401">No ERC.
                                                    </td>
                                                    <td class="m-nid-col m-nid-151241">5%</td>
                                                    <td class="m-nid-col m-nid-151201">3% + Repay £250 cashback</td>
                                                    <td class="m-nid-col m-nid-151236">5% + Repay paid legal fees</td>
                                                    <td class="m-nid-col m-nid-151211">3% + Repay £250 cashback</td>
                                                    <td class="m-nid-col m-nid-151206">3% + Repay paid legal fees</td>
                                                    <td class="m-nid-col m-nid-151381">No ERC.
                                                    </td>
                                                    <td class="m-nid-col m-nid-151216">3% + Repay £250 cashback</td>
                                                    <td class="m-nid-col m-nid-151376">No ERC.
                                                        Repay paid legal fees</td>
                                                    <td class="m-nid-col m-nid-151281">5%</td>
                                                    <td class="m-nid-col m-nid-151276">5% + Repay paid legal fees</td>
                                                    <td class="m-nid-col m-nid-151296">5% + Repay £250 cashback</td>
                                                    <td class="m-nid-col m-nid-151261">5%</td>
                                                    <td class="m-nid-col m-nid-151256">5% + Repay paid legal fees</td>
                                                    <td class="m-nid-col m-nid-151251">5%</td>
                                                    <td class="m-nid-col m-nid-151246">5% + Repay paid legal fees</td>
                                                    <td class="m-nid-col m-nid-151306">5% + Repay £250 cashback</td>
                                                    <td class="m-nid-col m-nid-151301">5% + Repay paid legal fees</td>
                                                    <td class="m-nid-col m-nid-151286">5% + Repay paid legal fees</td>
                                                    <td class="m-nid-col m-nid-151326">5% + Repay £250 cashback</td>
                                                    <td class="m-nid-col m-nid-151321">5% + Repay paid legal fees</td>
                                                    <td class="m-nid-col m-nid-151291">5%</td>
                                                    <td class="m-nid-col m-nid-151271">5%</td>
                                                    <td class="m-nid-col m-nid-151221">3% + Repay paid legal fees</td>
                                                    <td class="m-nid-col m-nid-151226">3%</td>
                                                    <td class="m-nid-col m-nid-151266">5% + Repay paid legal fees</td>
                                                    <td class="m-nid-col m-nid-151421">No ERC.
                                                        Repay paid legal fees</td>
                                                    <td class="m-nid-col m-nid-151426">No ERC.
                                                    </td>
                                                    <td class="m-nid-col m-nid-151416">No ERC.
                                                    </td>
                                                    <td class="m-nid-col m-nid-151411">No ERC.
                                                        Repay paid legal fees</td>
                                                    <td class="m-nid-col m-nid-151311">5% + Repay paid legal fees</td>
                                                    <td class="m-nid-col m-nid-151316">5% + Repay £250 cashback</td>
                                                    <td class="m-nid-col m-nid-151331">5% + Repay paid legal fees</td>
                                                    <td class="m-nid-col m-nid-151336">5% + Repay £250 cashback</td>
                                                    <td class="m-nid-col m-nid-151341">5% + Repay paid legal fees</td>
                                                    <td class="m-nid-col m-nid-151346">5% + Repay £250 cashback</td>
                                                    <td class="m-nid-col m-nid-151351">5% + Repay £250 cashback</td>
                                                    <td class="m-nid-col m-nid-151356">5% + Repay £250 cashback</td>
                                                    <td class="m-nid-col m-nid-151231">3% + Repay £250 cashback</td>
                                                    <td class="m-nid-col m-nid-151406">No ERC.
                                                    </td>
                                                    <td class="m-nid-col m-nid-151361">5% + Repay £250 cashback</td>                            </tr>
                                                <tr class="r">
                                                    <th>Monthly cost</th>

                                                    <td class="m-nid-col m-nid-151366" id="comp_td_cost_151366"></td>
                                                    <td class="m-nid-col m-nid-151151" id="comp_td_cost_151151"></td>
                                                    <td class="m-nid-col m-nid-151156" id="comp_td_cost_151156"></td>
                                                    <td class="m-nid-col m-nid-151371" id="comp_td_cost_151371"></td>
                                                    <td class="m-nid-col m-nid-151121" id="comp_td_cost_151121"></td>
                                                    <td class="m-nid-col m-nid-151126" id="comp_td_cost_151126"></td>
                                                    <td class="m-nid-col m-nid-151161" id="comp_td_cost_151161"></td>
                                                    <td class="m-nid-col m-nid-151166" id="comp_td_cost_151166"></td>
                                                    <td class="m-nid-col m-nid-151176" id="comp_td_cost_151176"></td>
                                                    <td class="m-nid-col m-nid-151171" id="comp_td_cost_151171"></td>
                                                    <td class="m-nid-col m-nid-151196" id="comp_td_cost_151196"></td>
                                                    <td class="m-nid-col m-nid-151191" id="comp_td_cost_151191"></td>
                                                    <td class="m-nid-col m-nid-151391" id="comp_td_cost_151391"></td>
                                                    <td class="m-nid-col m-nid-151386" id="comp_td_cost_151386"></td>
                                                    <td class="m-nid-col m-nid-151131" id="comp_td_cost_151131"></td>
                                                    <td class="m-nid-col m-nid-151136" id="comp_td_cost_151136"></td>
                                                    <td class="m-nid-col m-nid-151141" id="comp_td_cost_151141"></td>
                                                    <td class="m-nid-col m-nid-151146" id="comp_td_cost_151146"></td>
                                                    <td class="m-nid-col m-nid-151186" id="comp_td_cost_151186"></td>
                                                    <td class="m-nid-col m-nid-151181" id="comp_td_cost_151181"></td>
                                                    <td class="m-nid-col m-nid-151396" id="comp_td_cost_151396"></td>
                                                    <td class="m-nid-col m-nid-151401" id="comp_td_cost_151401"></td>
                                                    <td class="m-nid-col m-nid-151241" id="comp_td_cost_151241"></td>
                                                    <td class="m-nid-col m-nid-151201" id="comp_td_cost_151201"></td>
                                                    <td class="m-nid-col m-nid-151236" id="comp_td_cost_151236"></td>
                                                    <td class="m-nid-col m-nid-151211" id="comp_td_cost_151211"></td>
                                                    <td class="m-nid-col m-nid-151206" id="comp_td_cost_151206"></td>
                                                    <td class="m-nid-col m-nid-151381" id="comp_td_cost_151381"></td>
                                                    <td class="m-nid-col m-nid-151216" id="comp_td_cost_151216"></td>
                                                    <td class="m-nid-col m-nid-151376" id="comp_td_cost_151376"></td>
                                                    <td class="m-nid-col m-nid-151281" id="comp_td_cost_151281"></td>
                                                    <td class="m-nid-col m-nid-151276" id="comp_td_cost_151276"></td>
                                                    <td class="m-nid-col m-nid-151296" id="comp_td_cost_151296"></td>
                                                    <td class="m-nid-col m-nid-151261" id="comp_td_cost_151261"></td>
                                                    <td class="m-nid-col m-nid-151256" id="comp_td_cost_151256"></td>
                                                    <td class="m-nid-col m-nid-151251" id="comp_td_cost_151251"></td>
                                                    <td class="m-nid-col m-nid-151246" id="comp_td_cost_151246"></td>
                                                    <td class="m-nid-col m-nid-151306" id="comp_td_cost_151306"></td>
                                                    <td class="m-nid-col m-nid-151301" id="comp_td_cost_151301"></td>
                                                    <td class="m-nid-col m-nid-151286" id="comp_td_cost_151286"></td>
                                                    <td class="m-nid-col m-nid-151326" id="comp_td_cost_151326"></td>
                                                    <td class="m-nid-col m-nid-151321" id="comp_td_cost_151321"></td>
                                                    <td class="m-nid-col m-nid-151291" id="comp_td_cost_151291"></td>
                                                    <td class="m-nid-col m-nid-151271" id="comp_td_cost_151271"></td>
                                                    <td class="m-nid-col m-nid-151221" id="comp_td_cost_151221"></td>
                                                    <td class="m-nid-col m-nid-151226" id="comp_td_cost_151226"></td>
                                                    <td class="m-nid-col m-nid-151266" id="comp_td_cost_151266"></td>
                                                    <td class="m-nid-col m-nid-151421" id="comp_td_cost_151421"></td>
                                                    <td class="m-nid-col m-nid-151426" id="comp_td_cost_151426"></td>
                                                    <td class="m-nid-col m-nid-151416" id="comp_td_cost_151416"></td>
                                                    <td class="m-nid-col m-nid-151411" id="comp_td_cost_151411"></td>
                                                    <td class="m-nid-col m-nid-151311" id="comp_td_cost_151311"></td>
                                                    <td class="m-nid-col m-nid-151316" id="comp_td_cost_151316"></td>
                                                    <td class="m-nid-col m-nid-151331" id="comp_td_cost_151331"></td>
                                                    <td class="m-nid-col m-nid-151336" id="comp_td_cost_151336"></td>
                                                    <td class="m-nid-col m-nid-151341" id="comp_td_cost_151341"></td>
                                                    <td class="m-nid-col m-nid-151346" id="comp_td_cost_151346"></td>
                                                    <td class="m-nid-col m-nid-151351" id="comp_td_cost_151351"></td>
                                                    <td class="m-nid-col m-nid-151356" id="comp_td_cost_151356"></td>
                                                    <td class="m-nid-col m-nid-151231" id="comp_td_cost_151231"></td>
                                                    <td class="m-nid-col m-nid-151406" id="comp_td_cost_151406"></td>
                                                    <td class="m-nid-col m-nid-151361" id="comp_td_cost_151361"></td>                            </tr>
                                                <tr class="comp-logo-r">
                                                    <th><img src="/info/sites/all/themes/santander_cms_core/images/123_123lite_select.png" alt="" /></th>
                                                    <td class="comp_table_final_txt">Based on this monthly mortgage cost the annual cashback you could earn is:</td>
                                                </tr>
                                                <tr class="r final-cost">
                                                    <th>Mortgage cashback</th>
                                                    <td class="m-nid-col m-nid-151366" id="comp_td_cost_final_151366"></td>
                                                    <td class="m-nid-col m-nid-151151" id="comp_td_cost_final_151151"></td>
                                                    <td class="m-nid-col m-nid-151156" id="comp_td_cost_final_151156"></td>
                                                    <td class="m-nid-col m-nid-151371" id="comp_td_cost_final_151371"></td>
                                                    <td class="m-nid-col m-nid-151121" id="comp_td_cost_final_151121"></td>
                                                    <td class="m-nid-col m-nid-151126" id="comp_td_cost_final_151126"></td>
                                                    <td class="m-nid-col m-nid-151161" id="comp_td_cost_final_151161"></td>
                                                    <td class="m-nid-col m-nid-151166" id="comp_td_cost_final_151166"></td>
                                                    <td class="m-nid-col m-nid-151176" id="comp_td_cost_final_151176"></td>
                                                    <td class="m-nid-col m-nid-151171" id="comp_td_cost_final_151171"></td>
                                                    <td class="m-nid-col m-nid-151196" id="comp_td_cost_final_151196"></td>
                                                    <td class="m-nid-col m-nid-151191" id="comp_td_cost_final_151191"></td>
                                                    <td class="m-nid-col m-nid-151391" id="comp_td_cost_final_151391"></td>
                                                    <td class="m-nid-col m-nid-151386" id="comp_td_cost_final_151386"></td>
                                                    <td class="m-nid-col m-nid-151131" id="comp_td_cost_final_151131"></td>
                                                    <td class="m-nid-col m-nid-151136" id="comp_td_cost_final_151136"></td>
                                                    <td class="m-nid-col m-nid-151141" id="comp_td_cost_final_151141"></td>
                                                    <td class="m-nid-col m-nid-151146" id="comp_td_cost_final_151146"></td>
                                                    <td class="m-nid-col m-nid-151186" id="comp_td_cost_final_151186"></td>
                                                    <td class="m-nid-col m-nid-151181" id="comp_td_cost_final_151181"></td>
                                                    <td class="m-nid-col m-nid-151396" id="comp_td_cost_final_151396"></td>
                                                    <td class="m-nid-col m-nid-151401" id="comp_td_cost_final_151401"></td>
                                                    <td class="m-nid-col m-nid-151241" id="comp_td_cost_final_151241"></td>
                                                    <td class="m-nid-col m-nid-151201" id="comp_td_cost_final_151201"></td>
                                                    <td class="m-nid-col m-nid-151236" id="comp_td_cost_final_151236"></td>
                                                    <td class="m-nid-col m-nid-151211" id="comp_td_cost_final_151211"></td>
                                                    <td class="m-nid-col m-nid-151206" id="comp_td_cost_final_151206"></td>
                                                    <td class="m-nid-col m-nid-151381" id="comp_td_cost_final_151381"></td>
                                                    <td class="m-nid-col m-nid-151216" id="comp_td_cost_final_151216"></td>
                                                    <td class="m-nid-col m-nid-151376" id="comp_td_cost_final_151376"></td>
                                                    <td class="m-nid-col m-nid-151281" id="comp_td_cost_final_151281"></td>
                                                    <td class="m-nid-col m-nid-151276" id="comp_td_cost_final_151276"></td>
                                                    <td class="m-nid-col m-nid-151296" id="comp_td_cost_final_151296"></td>
                                                    <td class="m-nid-col m-nid-151261" id="comp_td_cost_final_151261"></td>
                                                    <td class="m-nid-col m-nid-151256" id="comp_td_cost_final_151256"></td>
                                                    <td class="m-nid-col m-nid-151251" id="comp_td_cost_final_151251"></td>
                                                    <td class="m-nid-col m-nid-151246" id="comp_td_cost_final_151246"></td>
                                                    <td class="m-nid-col m-nid-151306" id="comp_td_cost_final_151306"></td>
                                                    <td class="m-nid-col m-nid-151301" id="comp_td_cost_final_151301"></td>
                                                    <td class="m-nid-col m-nid-151286" id="comp_td_cost_final_151286"></td>
                                                    <td class="m-nid-col m-nid-151326" id="comp_td_cost_final_151326"></td>
                                                    <td class="m-nid-col m-nid-151321" id="comp_td_cost_final_151321"></td>
                                                    <td class="m-nid-col m-nid-151291" id="comp_td_cost_final_151291"></td>
                                                    <td class="m-nid-col m-nid-151271" id="comp_td_cost_final_151271"></td>
                                                    <td class="m-nid-col m-nid-151221" id="comp_td_cost_final_151221"></td>
                                                    <td class="m-nid-col m-nid-151226" id="comp_td_cost_final_151226"></td>
                                                    <td class="m-nid-col m-nid-151266" id="comp_td_cost_final_151266"></td>
                                                    <td class="m-nid-col m-nid-151421" id="comp_td_cost_final_151421"></td>
                                                    <td class="m-nid-col m-nid-151426" id="comp_td_cost_final_151426"></td>
                                                    <td class="m-nid-col m-nid-151416" id="comp_td_cost_final_151416"></td>
                                                    <td class="m-nid-col m-nid-151411" id="comp_td_cost_final_151411"></td>
                                                    <td class="m-nid-col m-nid-151311" id="comp_td_cost_final_151311"></td>
                                                    <td class="m-nid-col m-nid-151316" id="comp_td_cost_final_151316"></td>
                                                    <td class="m-nid-col m-nid-151331" id="comp_td_cost_final_151331"></td>
                                                    <td class="m-nid-col m-nid-151336" id="comp_td_cost_final_151336"></td>
                                                    <td class="m-nid-col m-nid-151341" id="comp_td_cost_final_151341"></td>
                                                    <td class="m-nid-col m-nid-151346" id="comp_td_cost_final_151346"></td>
                                                    <td class="m-nid-col m-nid-151351" id="comp_td_cost_final_151351"></td>
                                                    <td class="m-nid-col m-nid-151356" id="comp_td_cost_final_151356"></td>
                                                    <td class="m-nid-col m-nid-151231" id="comp_td_cost_final_151231"></td>
                                                    <td class="m-nid-col m-nid-151406" id="comp_td_cost_final_151406"></td>
                                                    <td class="m-nid-col m-nid-151361" id="comp_td_cost_final_151361"></td>
                                            </table>

                                            <a href="javascript:void(0)" class="show-all-btn">Show all</a>

                                        </div>

                                        <div class="rep-title">Representative example</div>
                                        <div class="representative-examples">
                                            <div class="inside">

                                                <div class="representative-example large-loan">
                                                    <p>A mortgage of £1,039,200 payable over 25 years would require 60 monthly payments of £4458.93 and 240 monthly payments of £5182.03.  This is based on an initial fixed rate for 5 years at 60% Loan to Value at 2.09% and then Santander's Follow-on Rate of 3.75% variable (Bank of England base rate, currently 0.50% plus 3.25%) for the remaining 20 years.</p>
                                                    <p>The total amount payable would be £1,511,722 (mortgage including a £1999 product fee, plus £470,024 interest and a £225 account fee).</p>
                                                    <p>The overall cost for comparison is 3.1% APR representative.</p>
                                                </div>

                                                <div class="representative-example mover-loan">
                                                    <p>A mortgage of £147,574 payable over 23 years would require 24 monthly payments of £649.18 and 252 monthly payments of £786.06.  This is based on an initial fixed rate for 2 years at 60% Loan to Value at 1.74% and then Santander's Follow-on Rate of 3.75% variable (Bank of England base rate, currently 0.50% plus 3.25%) for the remaining 21 years.</p>
                                                    <p>The total amount payable would be £214,059 (mortgage including a £0 product fee, plus £66,094 interest and a £225 account fee).</p>
                                                    <p>The overall cost for comparison is 3.5% APR representative.</p>
                                                </div>

                                                <div class="representative-example ftb-loan">
                                                    <p>A mortgage of £147,574 payable over 23 years would require 24 monthly payments of £649.18 and 252 monthly payments of £786.06.  This is based on an initial fixed rate for 2 years at 60% Loan to Value at 1.74% and then Santander's Follow-on Rate of 3.75% variable (Bank of England base rate, currently 0.50% plus 3.25%) for the remaining 21 years.</p>
                                                    <p>The total amount payable would be £214,059 (mortgage including a £0 product fee, plus £66,094 interest and a £225 account fee).</p>
                                                    <p>The overall cost for comparison is 3.5% APR representative.</p>
                                                </div>

                                                <div class="representative-example remortgage-loan">
                                                    <p>A mortgage of £105,000 payable over 15 years would require 60 monthly payments of £682.47 and 120 monthly payments of £737.13.  This is based on an initial fixed rate for 5 years at 60% Loan to Value at 2.14% and then Santander's Follow-on Rate of 3.75% variable (Bank of England base rate, currently 0.50% plus 3.25%) for the remaining 10 years.</p>
                                                    <p>The total amount payable would be £129,664 (mortgage including a £0 product fee, plus £24,404 interest and a £225 account fee).</p>
                                                    <p>The overall cost for comparison is 2.9% APR representative.</p>
                                                </div>

                                            </div>
                                        </div>
                                        <div class="rep-info"><span></span> A representative example is an illustration of a typical mortgage and its total cost.</div>

                                        <div class="step-actions clearfix">
                                            <a href="javascript:void(0)" class="btn btn-default btn-sm btn-back visible-lg-block visible-md-block">Change what you're looking for</a>
                                            <a href="javascript:void(0)" class="btn btn-primary btn-sm disabled btn-next btn-comp visible-lg-block visible-md-block">Compare your choices</a>
                                            <a href="javascript:void(0)" class="btn btn-primary btn-sm btn-mobile-next visible-xs-block visible-sm-block">Next steps</a>
                                            <a href="javascript:void(0)" class="btn btn-default btn-sm btn-back visible-xs-block visible-sm-block">Amend choices</a>
                                            <a href="javascript:void(0)" class="btn btn-default btn-sm btn-table-back" style="display: none">What rates are available?</a>
                                        </div>

                                    </div>


                                </div>

                            </div>

                        </div>
                    </div>  </div>
                <div class="inner-wrapper below-calc-c"><div class="field-collection-container clearfix"><div class="field field-name-field-repr-example field-type-field-collection field-label-hidden">
                            <div class="field-collection-view clearfix view-mode-full field-collection-view-final"></div>		  </div>
                    </div></div></div><div class="container"><div class="inner-wrapper"><div class="field field-name-field-important-info field-type-text-long field-label-hidden text clearfix">
                        <h3>Important information</h3>
                        <h3><span>YOUR HOME MAY BE REPOSSESSED IF YOU DO NOT KEEP UP REPAYMENTS ON YOUR MORTGAGE.</span></h3>
                        <p>All applications are subject to status and our lending criteria. This means that the amount we will lend you will depend on your individual circumstances, the type of property and the amount you borrow. For example, we may require a higher deposit if you are buying a flat or a new build property.</p>
                        <p></p><div class="media media-element-container media-default"><div id="file-15201--3" class="file file-image file-image-jpeg">
                                <img height="110" width="150" style="float: left;" class="media-element file-default" data-delta="3" alt="" title="" src="/info/sites/default/files/146329_1398228_DB201710-28_Mortgage%20awards_1.jpg" /></div>
                        </div><div class="media media-element-container media-default"><div id="file-15206--3" class="file file-image file-image-jpeg">
                                <img height="110" width="150" style="float: left;" class="media-element file-default" data-delta="4" alt="" title="" src="/info/sites/default/files/142000_1378657_Mortgage-Award-logos-update-B.jpg" /></div>
                        </div><div class="media media-element-container media-default"><div id="file-15211--3" class="file file-image file-image-jpeg">
                                <img height="110" width="150" style="float: left;" class="media-element file-default" data-delta="5" alt="" title="" src="/info/sites/default/files/146329_1398228_DB201710-28_Mortgage%20awards_3.jpg" /></div>
                        </div><div class="media media-element-container media-default"><div id="file-15216--3" class="file file-image file-image-jpeg">
                                <img height="110" width="150" style="float: left;" class="media-element file-default" data-delta="6" alt="" title="" src="/info/sites/default/files/142000_1378657_Mortgage-Award-logos-update-A.jpg" /></div>
                        </div><div class="media media-element-container media-default"><div id="file-15221--3" class="file file-image file-image-jpeg">
                                <img height="110" width="150" style="float: left;" class="media-element file-default" data-delta="7" alt="" title="" src="/info/sites/default/files/146329_1398228_DB201710-28_Mortgage%20awards_2.jpg" /></div>
                        </div>
                        <p><!--break--></p>
                        <h3 id="online-exclusive-text">Important information</h3>
                        <ul><li>Rates correct as at 27 February 2018.</li>
                            <li>Santander's Follow-on Rate (FoR) is a variable rate that tracks the Bank of England base rate (Bank of England base rate plus 3.25%).</li>
                            <li>The calculator gives you an idea of what the mortgage costs could be and is for illustrative purposes only. </li>
                            <li>All offers are subject to availability and may be withdrawn at any time.</li>
                            <li><strong>Online exclusives</strong> – these mortgage deals are only available online when you complete a full application on Santander.co.uk. These deals are not available in our branch or telephone channels. Please remember if you apply online you need to be comfortable selecting your own mortgage without receiving advice from a Santander Mortgage Adviser. </li>
                            <li id="htb-exclusive-text"><strong>Santander Help to Buy: ISA exclusives</strong> – these mortgage deals are only available to Santander Help to Buy: ISA customers where the account has been open for at least 30 days. <strong>For joint applications, both applicants must be first time buyers and at least one applicant must have a Santander Help to Buy: ISA</strong>. These deals are only available in branch or by phone.</li>
                            <li id="select-exclusive-text"><strong>Select exclusives - </strong>these mortgage deals are only available to Santander Select customers in branch or by telephone. They are not available online.</li>
                        </ul><h3><span>Early repayment charges</span></h3>
                        <ul><li><strong>Fixed rates</strong> - you can overpay up to 10% of your fixed rate loan amount each calendar year (January to December) without paying an early repayment charge. If you want to pay off more than 10%, you’ll need to pay an early repayment charge. Plus, where the fixed rate mortgage offers the additional benefit of £250 cashback or standard legal fees paid, this will need to be repaid if you pay off your mortgage in the first two years (see section below – Additional benefits).</li>
                            <li><strong>Tracker rates</strong> - you can make unlimited overpayments on our tracker rate mortgages without paying an early repayment charge. Where the tracker rate mortgage offers the additional benefit of £250 cashback or standard legal fees paid, this will need to be repaid if you pay off your mortgage in the first two years (see section below – Additional benefits).</li>
                        </ul><h3>Additional benefits <span>(on eligible mortgages as detailed above)</span></h3>
                        <ul><li><strong>Free valuation</strong> - available if you're moving home or remortgaging to us from another lender on a property valued up to £2.5 million, saving you on average £430. This is Santander's standard valuation fee based on our average property valuation between<span> </span>1 January 2017 and 30 June 2017<span>.</span></li>
                            <li><strong>£250 cashback</strong> if you're moving home. You only need to repay the £250 cashback if you repay your mortgage in the first two years.</li>
                            <li><strong>Standard legal fees paid</strong> if you're remortgaging to us from another lender. You only need to repay the standard legal fees paid (worth £200) if you repay your mortgage in the first two years.</li>
                        </ul><h3>Things you need to know</h3>
                        <ul><li>Mortgage anniversary - on tracker mortgages the anniversary is the date you completed on your mortgage, unless stated otherwise.</li>
                            <li>Monthly costs are calculated on a repayment basis and don’t include the product fee. Product fees are payable upfront. However, on most products, you can add the product fee to the loan. Any fees added to the loan will attract interest.</li>
                            <li>If you'd like information on our fees and charges please see our <a href="/info/sites/default/files/do_ec_280_Santander_tariff_of_mortgage_chargesJAN18_0.pdf" target="_blank">Tariff of Mortgage Charges</a> which will help.</li>
                            <li>Most of our mortgage products have a minimum loan size of £6,000. However, there are some selected products where the minimum loan size is different. Please check with us.</li>
                            <li>The <a href="https://www.santander.co.uk/uk/current-accounts/123-current-account" target="_blank">1|2|3 Current Account</a> and <a href="https://www.santander.co.uk/uk/select/products/select-current-account" target="_blank">Select Current Account</a> have a £5 monthly account fee and the <a href="https://www.santander.co.uk/uk/current-accounts/123-lite-current-account" target="_blank">1|2|3 Lite Current Account</a> has a £1 monthly account fee. To earn cashback you must pay in at least £500 a month (excludes internal transfers) and have at least two active Direct Debits. Select Current Account customers must also pay in at least £5,000 per month into a Select Current Account or have £75,000 in any Santander investment(s), savings or current account. 1|2|3 Lite Current Account customers must also log on to Online or Mobile Banking at least once in every three months.</li>
                            <li><span>Cashback is paid monthly. You may hold a maximum of two 1|2|3 Current Accounts or Select Current Accounts, one in your name and one in joint names. You must be 18 or over and a UK resident. For details of our fees and interest rates, visit <a href="https://www.santander.co.uk" target="_blank">santander.co.uk</a> or ask for the latest Interest Rates and Fees information leaflet at any branch.  </span><span>  </span></li>
                        </ul><p> </p>
                        <h3>YOUR HOME MAY BE REPOSSESSED IF YOU DO NOT KEEP UP REPAYMENTS ON YOUR MORTGAGE.</h3>
                        <p>All applications are subject to status and our lending criteria. This means that the amount we will lend you will depend on your individual circumstances, the type of property and the amount you borrow. For example, we may require a higher deposit if you are buying a flat or a new build property.</p>
                        <p></p><div class="media media-element-container media-default"><div id="file-15201--4" class="file file-image file-image-jpeg">
                                <img height="110" width="150" style="float: left;" class="media-element file-default" data-delta="8" alt="" title="" src="/info/sites/default/files/146329_1398228_DB201710-28_Mortgage%20awards_1.jpg" /></div>
                        </div><div class="media media-element-container media-default"><div id="file-15206--4" class="file file-image file-image-jpeg">
                                <img height="110" width="150" style="float: left;" class="media-element file-default" data-delta="9" alt="" title="" src="/info/sites/default/files/142000_1378657_Mortgage-Award-logos-update-B.jpg" /></div>
                        </div><div class="media media-element-container media-default"><div id="file-15211--4" class="file file-image file-image-jpeg">
                                <img height="110" width="150" style="float: left;" class="media-element file-default" data-delta="10" alt="" title="" src="/info/sites/default/files/146329_1398228_DB201710-28_Mortgage%20awards_3.jpg" /></div>
                        </div><div class="media media-element-container media-default"><div id="file-15216--4" class="file file-image file-image-jpeg">
                                <img height="110" width="150" style="float: left;" class="media-element file-default" data-delta="11" alt="" title="" src="/info/sites/default/files/142000_1378657_Mortgage-Award-logos-update-A.jpg" /></div>
                        </div><div class="media media-element-container media-default"><div id="file-15221--4" class="file file-image file-image-jpeg">
                                <img height="110" width="150" style="float: left;" class="media-element file-default" data-delta="12" alt="" title="" src="/info/sites/default/files/146329_1398228_DB201710-28_Mortgage%20awards_2.jpg" /></div>
                        </div>
                    </div>
                    <div class="field field-name-field-footer field-type-entityreference field-label-hidden">
                        <div id="node-6" class="node node-footer clearfix">



                            <div class="content">
                                <div class="field field-name-body field-type-text-with-summary field-label-hidden text clearfix">
                                    <div class="footer-links"><span> </span><br /><h2 class="element-invisible">Footer links</h2>
                                        <ul><li><a href="http://www.santander.co.uk/uk/about-santander-uk/about-us" target="_blank">About Santander</a> |</li>
                                            <li><a href="http://www.santander.co.uk/uk/accessibility" target="_blank">Accessibility</a> |</li>
                                            <li><a class="ui-link" href="http://www.santander.co.uk/uk/website-legal" target="_blank">Legal</a> |</li>
                                            <li><a href="http://www.santander.co.uk/uk/security-privacy" target="_blank">Privacy</a></li>
                                        </ul></div>
                                    <div> </div>
                                    <div>Santander UK plc. Registered Office: 2 Triton Square, Regent's Place, London, NW1 3AN, United Kingdom. Registered Number 2294747. Registered in England and Wales. <a href="http://www.santander.co.uk" target="_blank">www.santander.co.uk</a>. Telephone <strong>0800 389 7000</strong>. Calls may be recorded or monitored. Authorised by the Prudential Regulation Authority and regulated by the Financial Conduct Authority and the Prudential Regulation Authority. Our Financial Services Register number is 106054. You can check this on the Financial Services Register by visiting the FCA’s website <a href="http://www.fca.org.uk/register" target="_blank">www.fca.org.uk/register</a>. Santander and the flame logo are registered trademarks.<br /> </div>
                                    <div> </div>
                                </div>
                            </div>


                        </div>
                    </div>
                </div></div>  </div>
    </section>
</div>
</body>
</html>
