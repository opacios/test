 ;(function($) {

   var calcBarrow = {

     $step1Container : null,
     $step2Container : null,
     $step3Container : null,
     $step4Container : null,

     step2Initialized : false,
     step3Initialized : false,
     step4Initialized : false,

     //mortage step values
     mortgage : {
       applicants : 0,
       buyers : 0,
       dependants : 0,
       terms : 0,
       deposit : 0,
       extra : 0,
       buyer_type : null
     },

     //income step values
     income : {
       basic : {
         a1 : {
           taxable : 0
         },
         a2 : {
           taxable : 0
         }
       },
       guaranteed : {
         a1 : {
           taxable : 0,
           nonTaxable : 0
         },
         a2 : {
           taxable : 0,
           nonTaxable : 0
         }
       },
       regular : {
         a1 : {
           taxable : 0,
           nonTaxable : 0
         },
         a2 : {
           taxable : 0,
           nonTaxable : 0
         }
       }
     },

     commitments : {
       creditCard: 0,
       loans: 0,
       outgoings: 0
     },

     loan : 0,

     init: function () {
       var that = this;
       sCalculator.initTooltips();

       this.$step1Container = $(".calc-steps .step_1");
       this.$step2Container = $(".calc-steps .step_2");
       this.$step3Container = $(".calc-steps .step_3");
       this.$step4Container = $(".calc-steps .step_4");


       $(".flat-checkbox span").click(function(){
         var $container = $(this).parent();
         $("span", $container).removeClass('active');
         $(this).addClass("active");

         if($container.data('linkedres')) {
           $("#" + $container.data('linkedres')).html($(this).html()).parent().addClass('res-value-set');
         }

         if($container.data('name')) {
           var name = $container.data('name');
           $container.addClass('value-set');
           switch(name) {
             case 'applicants':
             case 'buyers':
             case 'dependants':
             case 'extra':
               that.mortgage[name] = $(this).data('value');
               that.step1OnChangeValue();
               break;
           }
         }

       });


       this.step1Init();


       /*
       $(".agree_step").addClass("non_active");
       $(".calc-steps").addClass("active");
       this.step3SetActive();
       */

     },//end init


     //mortgage step
     step1Init : function() {
       var that = this;

       $("#mortgage-terms").val('empty');

       $("#mortgage-terms").change(function() {
         var valueSet = false;
         var term_val = '-';
         if($(this).val() != 'empty') {
           term_val = $(this).val() + ' years';
           that.mortgage['terms'] = $(this).val();
           valueSet = true;
         }
         $("#res-mortgage-terms").html(term_val);
           $(this)[ valueSet ? 'addClass' : 'removeClass' ]('value-set');
         that.step1OnChangeValue();
       }).trigger('change');

       $("#buyer-type").change(function() {
         var valueSet = false;
         $('.calc-field-extra-money').hide();
         var bt_val = '-';
         if($(this).val() != 'empty') {
           bt_val = $(this).val();
           that.mortgage['buyer_type'] = $(this).val();
           valueSet = true;

           switch($(this).val()) {
               case 'ftb':
                 bt_val = 'First time buyer';
                 $('.calc-field-extra-money .flat-checkbox-2').removeClass('value-set');
                 break;
               case 'mover':
                 bt_val = 'Moving home';
                 $('.calc-field-extra-money .flat-checkbox-2').removeClass('value-set');
                 break;
               case 'remortgage':
                 bt_val = 'Remortgage';
                 $('.calc-field-extra-money').show();
                 break;
           }

         }
             $("#res-mortgage-buyer-type").html(bt_val);
           $(this)[ valueSet ? 'addClass' : 'removeClass' ]('value-set');
             that.step1OnChangeValue();
         }).trigger('change');

       $("#field-deposit")
         .on('change keyup', function() {
           //var v = parseFloat($(this).val());
           var v = sCalculator.getNumericFieldVal($(this));
           var valueSet = false;
           if(!isNaN(v)) {
             $("#res-mortgage-deposit").html( sCalculator.formatMoney(v, 0));
             that.mortgage['deposit'] = v;
             if(v > 0) valueSet = true;
           }
           else {
             $("#res-mortgage-deposit").html('-');
             that.mortgage['deposit'] = 0;
           }
           $(this)[ valueSet ? 'addClass' : 'removeClass' ]('value-set');
           $("#res-mortgage-deposit").parent()[ valueSet ? 'addClass' : 'removeClass' ]('res-value-set');


           that.step1OnChangeValue();
         })
         .numericField({decimalPlaces: 0, negative: false});

       $(".btn-next", this.$step1Container).click(function() {
         if(!$(this).hasClass('disabled')) {
           that.step2SetActive();
         }
       });
     },

     step1SetActive : function() {
       if($('#calculator-results-area', this.$step1Container).length == 0) {
         this.$step1Container.append($("#calculator-results-area"));
       }

       $(".calc-steps .calc-step").removeClass("active");
       $(".calc-steps .step_1").addClass("active");
     },

     step1OnChangeValue : function() {
       if(this.mortgage['buyer_type'] == 'remortgage') {
         if($(".value-set", this.$step1Container).length == 6) {
             $(".btn-next", this.$step1Container).removeClass('disabled');
         }
         else {
             $(".btn-next", this.$step1Container).addClass('disabled');
         }

       }
       else if($(".value-set", this.$step1Container).length == 5) {
         $(".btn-next", this.$step1Container).removeClass('disabled');
       }
       else {
         $(".btn-next", this.$step1Container).addClass('disabled');
       }
     },


     //income step
     step2Init : function() {
       var that = this;

       this.step2Initialized = true;

       $("input.form-number", this.$step2Container).on('keyup change', function() {
         that.step2OnChangeValue();
       })
         .numericField({decimalPlaces: 0, negative: false});;
       //end add income row

       $(".btn-back", this.$step2Container).click(function() {
         that.step1SetActive();
       });
       $(".btn-next", this.$step2Container).click(function() {
         if(!$(this).hasClass('disabled')) {
           that.step2CalcIncomeValues();
           that.step3SetActive();
         }
       });

     },

     step2CalcIncomeValues : function() {
       var that = this;

       var sum, total = 0;
       var sections = ['basic', 'guaranteed', 'regular', 'csa'];

       //initialize values
       this.income = {
         basic : {
           a1 : {
             taxable : 0
           },
           a2 : {
             taxable : 0
           }
         },
         guaranteed : {
           a1 : {
             taxable : 0,
             nonTaxable : 0
           },
           a2 : {
             taxable : 0,
             nonTaxable : 0
           }
         },
         regular : {
           a1 : {
             taxable : 0,
             nonTaxable : 0
           },
           a2 : {
             taxable : 0,
             nonTaxable : 0
           }
         }
       };


       for(var applicantInd = 1; applicantInd <= 2; applicantInd ++) {
         if(applicantInd == 2 && this.mortgage.applicants != 2 ) continue;

         var $mainContainer = $(".applicant-" + applicantInd + "-fields", this.$step2Container);
         for (var sInd = 0; sInd < 4; sInd++) {
           sum = 0;
           $(".calc-field-income-" + sections[sInd] + " input.form-number", $mainContainer).each(function () {

             var v = sCalculator.getNumericFieldVal($(this));
             if(v > 0) {
               if(sInd == 0) { //basic
                 that.income.basic['a' + applicantInd].taxable += v;
               }
               else if(sInd == 1) { //guaranteed
                 var type = $("select", $(this).closest('.income-row')).val();
                 if(type == 'allowances') {
                   that.income.guaranteed['a' + applicantInd].taxable += v;
                 }
                 else {
                   that.income.regular['a' + applicantInd].taxable += v;
                 }
               }
               else if(sInd == 2) { //regular
                 that.income.guaranteed['a' + applicantInd].nonTaxable += v;
               }
               else if(sInd == 3) { //csa
                 that.income.regular['a' + applicantInd].nonTaxable += v;
               }
             }
           });
         }
       }
       //console.log(this.income);
     },

     step2OnChangeValue : function() {
       var sum, total = 0;
       var sections = ['basic', 'guaranteed', 'regular', 'csa'];

       for(var applicantInd = 1; applicantInd <= 2; applicantInd ++) {
         if (applicantInd == 2 && this.mortgage.applicants != 2) continue;

         var $mainContainer = $(".applicant-" + applicantInd + "-fields", this.$step2Container);

         for (var sInd = 0; sInd < 4; sInd++) {
           sum = 0;
           $(".calc-field-income-" + sections[sInd] + " input.form-number", $mainContainer).each(function () {
        	   var tmpVal = sCalculator.getNumericFieldVal($(this));
        	   sum += tmpVal;
           });
           total += sum;
           if (sum == 0) sum = '-';
           else sum = sCalculator.formatMoney(sum, 0);
           $("#res-income-" + sections[sInd] + applicantInd).html(sum).parent()[sum > 0 ? 'addClass' : 'removeClass']('res-value-set');
         }
       }
       $(".btn-next", this.$step2Container)[ total > 0 ? 'removeClass' : 'addClass']('disabled');
     },

     setSelectOptions : function($el, options, empty, defaultVal) {
       var selectOptions = [];
       selectOptions.push('<option value="">' + empty + '</option>');
       for(var i = 0 ; i < options.length; i++) {
         selectOptions.push('<option value="' + options[i].name + '" ' +( defaultVal ==  options[i].name ? ' selected ' : '' )+ '>' + options[i].title + '</option>');
       }
       $el.html(selectOptions);
     },

     step2SetActive : function() {
       if(!this.step2Initialized) {
         this.step2Init();
       }
       if($('#calculator-results-area', this.$step2Container).length == 0) {
         this.$step2Container.append($("#calculator-results-area"));
       }

       $(".calc-steps .calc-step").removeClass("active");
       $(".calc-steps .step_2").addClass("active");

       if(this.mortgage.applicants == 1) {
         $(".applicant-2-fields", this.$step2Container).hide();
         $(".left-zone h2", this.$step2Container).hide();
         $("#calculator-results-area").find('.result-income-section').removeClass('res-applicants-join').addClass('res-applicants-single');
       }
       else {
         $(".applicant-2-fields", this.$step2Container).show();
         $(".left-zone h2", this.$step2Container).show();
         $("#calculator-results-area").find('.result-income-section').addClass('res-applicants-join').removeClass('res-applicants-single');
       }

       this.step2OnChangeValue();
     },

     //commitments step
     step3Init : function() {
       this.step3Initialized = true;

       var that = this;

       $("#field-commitments-creditCard, #field-commitments-loans, #field-commitments-outgoings")
         .on('change keyup', function() {
           var $fieldContainer = $(this).closest('.calc-field');

         //  var v = parseFloat($(this).val());
           var v = sCalculator.getNumericFieldVal($(this));
           var valueSet = false;
           if(!isNaN(v)) {
             $("#" + $fieldContainer.data('linkedres')).html( sCalculator.formatMoney(v, 0));
             that.commitments[$fieldContainer.data('name')] = v;
             if(v > 0) valueSet = true;
           }
           else {
             $("#" + $fieldContainer.data('linkedres')).html('-');
             that.commitments[$fieldContainer.data('name')] = 0;
           }
           $(this)[ valueSet ? 'addClass' : 'removeClass' ]('value-set');
           $("#" + $fieldContainer.data('linkedres')).parent()[ valueSet ? 'addClass' : 'removeClass' ]('res-value-set');
         })
         .numericField({decimalPlaces: 0, negative: false});


       $(".btn-back", this.$step3Container).click(function() {
         that.step2SetActive();
       });
       $(".btn-next", this.$step3Container).click(function() {
         if(!$(this).hasClass('disabled')) {
           //to do
           //that.step2CalcIncomeValues();
           //that.step3SetActive(); ??
           that.calculateResult();
         }
       });
     },

     step3SetActive : function() {
       if(!this.step3Initialized) {
         this.step3Init();
       }
       if($('#calculator-results-area', this.$step3Container).length == 0) {
         this.$step3Container.append($("#calculator-results-area"));
       }

       $(".calc-steps .calc-step").removeClass("active");
       $(".calc-steps .step_3").addClass("active");

       $('html, body').animate({
         scrollTop: $(".left-zone", this.$step3Container).offset().top
       }, 100);

     },

     calculateResult : function() {
       var that = this;

       var data = {
         applicants: this.mortgage.applicants,
         buyers: this.mortgage.buyers,
         dependants: this.mortgage.dependants,
         term: this.mortgage.terms,
         deposit: this.mortgage.deposit,
         buyer_type: this.mortgage.buyer_type,
         extra: this.mortgage.extra,
         basicA1Taxable: this.income.basic.a1.taxable,
         basicA2Taxable: this.income.basic.a2.taxable,
         guaranteedA1Taxable: this.income.guaranteed.a1.taxable,
         guaranteedA1NonTaxable: this.income.guaranteed.a1.nonTaxable,
         guaranteedA2Taxable: this.income.guaranteed.a2.taxable,
         guaranteedA2NonTaxable: this.income.guaranteed.a2.nonTaxable,
         regularA1Taxable: this.income.regular.a1.taxable,
         regularA1NonTaxable: this.income.regular.a1.nonTaxable,
         regularA2Taxable: this.income.regular.a2.taxable,
         regularA2NonTaxable: this.income.regular.a2.nonTaxable,
         creditCard: this.commitments.creditCard,
         loans: this.commitments.loans,
         outgoings: this.commitments.outgoings
       };

       //console.log(data);

       this.loan = 0;

       $.ajax({
         type: "POST",
         url: 'borrow_result.php',
         data: data,
         success: function(jsonRez) {
           //console.log(jsonRez);
           that.loan = jsonRez.loan;
           if(that.loan < 0) that.loan = 0;
           that.step4SetActive();
         },
         dataType: 'json'
       });
     },

     step4Init : function() {
       var that = this;

       this.step4Initialized = true;

       $(".btn-back", this.$step4Container).click(function() {
         that.step3SetActive();
       });
     },

     step4SetActive : function() {
       if(!this.step4Initialized) {
         this.step4Init();
       }

       if($('#calculator-results-area', this.$step4Container).length == 0) {
         this.$step4Container.append($("#calculator-results-area"));
       }

       $(".calc-steps .calc-step").removeClass("active");
       $(".calc-steps .step_4").addClass("active");

       $("#result-loan").html( sCalculator.formatMoney(this.loan, 0));

       var nextUrl = $(".btn-next", this.$step4Container).data('url');
       if(!nextUrl) {
         nextUrl = $(".btn-next", this.$step4Container).attr('href');
         $(".btn-next", this.$step4Container).data('url', nextUrl);
       }
       $(".btn-next", this.$step4Container).attr('href', nextUrl + '?lend=' + this.loan);


       $('html, body').animate({
         scrollTop: $(".left-zone", this.$step4Container).offset().top
       }, 100);
     }
   };

   $(document).ready(function() {
     calcBarrow.init();
       
      if($(".agree").size()) {
    	  var ref = document.referrer;
    	  var checkboxClicked = sessionStorage.getItem('checkboxClicked');
    	  var hideAgreeCheckbox = false;
    	  var url = window.location.href;
    	  
    	  if(!!ref.match(/compare-our-mortgages/i)) {
    		  hideAgreeCheckbox = !!checkboxClicked;
    	  }
    	  else {
    		  if(url.indexOf('?again=1') != -1) {
    			  hideAgreeCheckbox = !!checkboxClicked;
    		  }
    		  else {
    			  sessionStorage.removeItem('checkboxClicked');
    		  }
    	  }
    	  
    	  if(hideAgreeCheckbox) {
    		  $(".agree_step").addClass("non_active");
              $(".calc-steps").addClass("active");
              calcBarrow.step1SetActive();
    	  }
        $(".agree input[type=checkbox]").click(function() {
            $(".btn", $(this).closest('.agree'))[ this.checked ? 'removeClass' : 'addClass' ]('disabled');
        });

        $(".agree .btn").click(function(){
          if(!$(this).hasClass('disabled')) {
            $(".agree_step").addClass("non_active");
            $(".calc-steps").addClass("active");
            sessionStorage.setItem('checkboxClicked', true);
            calcBarrow.step1SetActive();
          }
        });
      }
   });

})(jQuery);
