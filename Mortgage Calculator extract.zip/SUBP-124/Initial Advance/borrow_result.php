<?php
/*
 * For the purpose of testing
 * Equivalent Front-End fields to the testing spreadsheet
 *
 * Question 1 - main annual income
 * FRONTEND: - all dropdown options
 * CODE: basic taxable
 * TESTSHEET: Annual Basic Income
 *
 * Question 2 - other employed annual income
 * FRONTEND: employed allowances
 * CODE: guaranteed taxable
 * TESTSHEET: primary taxable
 *
 * FRONTEND: bonus, commision, overtime
 * CODE: regular taxable
 * TESTSHEET: secondary taxable
 *
 * Question 3 - other annual income
 * FRONTEND: working tax and child tax credit
 * CODE: guaranteed nonTaxable
 * TESTSHEET: primary nonTaxable
 *
 * FRONTEND: child benefit
 * CODE: guaranteed nonTaxable
 * TESTSHEET: primary nonTaxable
 *
 * FRONTEND: child maintenance or csa payments
 * CODE: regular nonTaxable
 * TESTSHEET: secondary nonTaxable
 *
 */

define('__ROOT__', dirname(__FILE__));

require_once(__ROOT__.'/src/SantanderBorrowResultIncome.php');
require_once(__ROOT__.'/src/SantanderBorrowResultExpenditure.php');
require_once(__ROOT__.'/src/SantanderBorrowResultCredit.php');
require_once(__ROOT__.'/src/SantanderBorrowResultLoan.php');
require_once(__ROOT__.'/src/SantanderBorrowResult.php');

$data = $_POST;
$result = new SantanderBorrowResult();
$validated = $result->validate($data);
$result->setParams($data);

$loan = $result->calculate();

print json_encode( array('loan' => $loan, 'validated' => $validated) );

?>