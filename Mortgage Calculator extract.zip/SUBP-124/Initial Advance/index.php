<!DOCTYPE HTML>
<html lang="en-gb" dir="ltr">
<head>
  <meta charset="utf-8" />
  <meta http-equiv="X-UA-Compatible" content="IE=edge" /><script type="text/javascript">window.NREUM||(NREUM={}),__nr_require=function(e,t,n){function r(n){if(!t[n]){var o=t[n]={exports:{}};e[n][0].call(o.exports,function(t){var o=e[n][1][t];return r(o||t)},o,o.exports)}return t[n].exports}if("function"==typeof __nr_require)return __nr_require;for(var o=0;o<n.length;o++)r(n[o]);return r}({1:[function(e,t,n){function r(){}function o(e,t,n){return function(){return i(e,[f.now()].concat(u(arguments)),t?null:this,n),t?void 0:this}}var i=e("handle"),a=e(2),u=e(3),c=e("ee").get("tracer"),f=e("loader"),s=NREUM;"undefined"==typeof window.newrelic&&(newrelic=s);var p=["setPageViewName","setCustomAttribute","setErrorHandler","finished","addToTrace","inlineHit","addRelease"],d="api-",l=d+"ixn-";a(p,function(e,t){s[t]=o(d+t,!0,"api")}),s.addPageAction=o(d+"addPageAction",!0),s.setCurrentRouteName=o(d+"routeName",!0),t.exports=newrelic,s.interaction=function(){return(new r).get()};var m=r.prototype={createTracer:function(e,t){var n={},r=this,o="function"==typeof t;return i(l+"tracer",[f.now(),e,n],r),function(){if(c.emit((o?"":"no-")+"fn-start",[f.now(),r,o],n),o)try{return t.apply(this,arguments)}catch(e){throw c.emit("fn-err",[arguments,this,e],n),e}finally{c.emit("fn-end",[f.now()],n)}}}};a("setName,setAttribute,save,ignore,onEnd,getContext,end,get".split(","),function(e,t){m[t]=o(l+t)}),newrelic.noticeError=function(e){"string"==typeof e&&(e=new Error(e)),i("err",[e,f.now()])}},{}],2:[function(e,t,n){function r(e,t){var n=[],r="",i=0;for(r in e)o.call(e,r)&&(n[i]=t(r,e[r]),i+=1);return n}var o=Object.prototype.hasOwnProperty;t.exports=r},{}],3:[function(e,t,n){function r(e,t,n){t||(t=0),"undefined"==typeof n&&(n=e?e.length:0);for(var r=-1,o=n-t||0,i=Array(o<0?0:o);++r<o;)i[r]=e[t+r];return i}t.exports=r},{}],4:[function(e,t,n){t.exports={exists:"undefined"!=typeof window.performance&&window.performance.timing&&"undefined"!=typeof window.performance.timing.navigationStart}},{}],ee:[function(e,t,n){function r(){}function o(e){function t(e){return e&&e instanceof r?e:e?c(e,u,i):i()}function n(n,r,o,i){if(!d.aborted||i){e&&e(n,r,o);for(var a=t(o),u=m(n),c=u.length,f=0;f<c;f++)u[f].apply(a,r);var p=s[y[n]];return p&&p.push([b,n,r,a]),a}}function l(e,t){v[e]=m(e).concat(t)}function m(e){return v[e]||[]}function w(e){return p[e]=p[e]||o(n)}function g(e,t){f(e,function(e,n){t=t||"feature",y[n]=t,t in s||(s[t]=[])})}var v={},y={},b={on:l,emit:n,get:w,listeners:m,context:t,buffer:g,abort:a,aborted:!1};return b}function i(){return new r}function a(){(s.api||s.feature)&&(d.aborted=!0,s=d.backlog={})}var u="nr@context",c=e("gos"),f=e(2),s={},p={},d=t.exports=o();d.backlog=s},{}],gos:[function(e,t,n){function r(e,t,n){if(o.call(e,t))return e[t];var r=n();if(Object.defineProperty&&Object.keys)try{return Object.defineProperty(e,t,{value:r,writable:!0,enumerable:!1}),r}catch(i){}return e[t]=r,r}var o=Object.prototype.hasOwnProperty;t.exports=r},{}],handle:[function(e,t,n){function r(e,t,n,r){o.buffer([e],r),o.emit(e,t,n)}var o=e("ee").get("handle");t.exports=r,r.ee=o},{}],id:[function(e,t,n){function r(e){var t=typeof e;return!e||"object"!==t&&"function"!==t?-1:e===window?0:a(e,i,function(){return o++})}var o=1,i="nr@id",a=e("gos");t.exports=r},{}],loader:[function(e,t,n){function r(){if(!x++){var e=h.info=NREUM.info,t=d.getElementsByTagName("script")[0];if(setTimeout(s.abort,3e4),!(e&&e.licenseKey&&e.applicationID&&t))return s.abort();f(y,function(t,n){e[t]||(e[t]=n)}),c("mark",["onload",a()+h.offset],null,"api");var n=d.createElement("script");n.src="https://"+e.agent,t.parentNode.insertBefore(n,t)}}function o(){"complete"===d.readyState&&i()}function i(){c("mark",["domContent",a()+h.offset],null,"api")}function a(){return E.exists&&performance.now?Math.round(performance.now()):(u=Math.max((new Date).getTime(),u))-h.offset}var u=(new Date).getTime(),c=e("handle"),f=e(2),s=e("ee"),p=window,d=p.document,l="addEventListener",m="attachEvent",w=p.XMLHttpRequest,g=w&&w.prototype;NREUM.o={ST:setTimeout,SI:p.setImmediate,CT:clearTimeout,XHR:w,REQ:p.Request,EV:p.Event,PR:p.Promise,MO:p.MutationObserver};var v=""+location,y={beacon:"bam.nr-data.net",errorBeacon:"bam.nr-data.net",agent:"js-agent.newrelic.com/nr-1071.min.js"},b=w&&g&&g[l]&&!/CriOS/.test(navigator.userAgent),h=t.exports={offset:u,now:a,origin:v,features:{},xhrWrappable:b};e(1),d[l]?(d[l]("DOMContentLoaded",i,!1),p[l]("load",r,!1)):(d[m]("onreadystatechange",o),p[m]("onload",r)),c("mark",["firstbyte",u],null,"api");var x=0,E=e(4)},{}]},{},["loader"]);</script>
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
  <meta name="description" content="Fill in our handy calculators to find out how much you could borrow with us, check our rates and see what your mortgage payments might be each month." />
  <link type="text/css" rel="stylesheet" href="http://hogarthsantander.prod.acquia-sites.com/info/sites/default/files/css/css_w8xk9_LdffDX1osjOMil0_i1x1J9F-pK5pzIjdhIFdc.css" media="all" />
  <link type="text/css" rel="stylesheet" href="http://hogarthsantander.prod.acquia-sites.com/info/sites/default/files/css/css_6LGNMr85VATs82JJZA1UmhKmIERt0Zio5wS7IMleoAE.css" media="all" />
  <link type="text/css" rel="stylesheet" href="http://hogarthsantander.prod.acquia-sites.com/info/sites/default/files/css/css_C3qIE2nQ_Vc8XV1gONZNiR3D7cKcg2QOyLOlyLKkCf8.css" media="all" />
  <title>How Much Could I Borrow | Mortgage Tool - Santander UK | Santander UK</title>
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
  <script src="js/santander_calculator.js"></script>
  <script src="js/calculator_borrow.js"></script>
</head>

<body class="html not-front logged-in no-sidebars page-taxonomy page-taxonomy-term page-taxonomy-term- page-taxonomy-term-5296" >
<div class="main-container">
  <div class="region region-header">
    <section id="block-santander-header-banner" class="block block-santander clearfix">



      <header id="node-header-216" class="node-product-header ">
        <div class="page-logo">
          <div class="container"><img src="http://hogarthsantander.prod.acquia-sites.com/info/sites/all/themes/santander_cms_core/logo.svg" width="262" alt="Santander" /></div>
        </div>


        <img class="img-header visible-xs" src="http://hogarthsantander.prod.acquia-sites.com/info/sites/default/files/styles/sm-full/public/hero_216.jpg?itok=0S38qx1Z" alt="" />
        <img src="http://hogarthsantander.prod.acquia-sites.com/info/sites/default/files/styles/lg-full/public/hero_216.jpg?itok=4od50w02" alt="" width="0" height="0" style="display: none;" />
        <div class="page-header" style="background-image: url(http://hogarthsantander.prod.acquia-sites.com/info/sites/default/files/styles/lg-full/public/hero_216.jpg?itok=4od50w02);">

          <div class="container onecol" >
            <div class="row inner">

              <div class="header-main">
                <div class="brackets">
                  <div class="b-top-left"></div>
                  <div class="b-top-right"></div>
                  <div class="b-bottom-right"></div>
                  <div class="b-bottom-left"></div>
                </div>

                <h1>How much could I borrow?</h1>
                <h2 class="field-name-field-subhead">See how much you may be able to borrow by answering a few questions about your income and outgoings.</h2>

              </div>


            </div>
          </div>
        </div>
      </header>


    </section>
  </div>


  <a id="main-content"></a>

  <div class="region region-content">
    <section id="block-system-main" class="block block-system clearfix">



      <div id="node-216" class="node node-product view-mode-full clearfix">
        <div class="container"><div class="field field-name-field-calculator-link field-type-calculator-link field-label-hidden">

            <div id="borrow-compmortgage" class="feature-box node-calculator node-borrow">
              <div class="page-content">
                <ul class="nav nav-tabs" role="navigation">
                  <li class="active"><a class="active">How much could I borrow?</a><span class="element-invisible">(active tab)</span></li>
                  <li><a href="/info/mortgages/compare-our-mortgages">Compare our mortgages</a></li>
                </ul>

                <div class="agree_step">
                  <div class="field field-name-body field-type-text-with-summary field-label-hidden text clearfix">
                    <h2>Can I get a mortgage?</h2>
                    <p>To apply for a mortgage with us you need to:</p>
                    <ul><li>be at least 18 years of age and a UK resident</li>
                      <li>want the mortgage for a property in the UK (but not in the Isle of Man)</li>
                      <li>intend to live in the property</li>
                      <li>have never had a home repossessed</li>
                      <li>have never been declared bankrupt or subject to an individual voluntary arrangement</li>
                      <li>be able to provide confirmation of all types of income</li>
                    </ul>		  </div>

                  <div class="agree">
                    <input type="checkbox" id="agree-check" />
                    <label for="agree-check">
                      <p>Tick the box to confirm you qualify</p>
                      <a href="javascript:void(0)" class="btn btn-primary btn-sm disabled">Continue</a>
                    </label>
                  </div>
                </div>

                <div class="calc-steps">

                  <div class="inner-content">
                    <div class="step_1 calc-step">
                      <div class="left-zone">

                        <ul class="nav nav-pills">
                          <li class="active"><span class="no">1</span><span class="txt">Your<br />mortgage</span></li>
                          <li><span class="no">2</span><span class="txt">Your<br />income</span></li>
                          <li><span class="no">3</span><span class="txt">Your<br />commitments</span></li>
                          <li><span class="no">4</span><span class="txt">Your<br />results</span></li>
                        </ul>


                        <div class="top-help-txt">Please use the <span class="tooltip_ico" style="cursor:auto;"></span> buttons to guide you through what to put in each box.</div>


                        <div class="calc-field calc-field-buyer-type calc-field-terms">
                          <div class="txt-label "><label>What type of buyer are you?</label></div>              <select name="buyer_type_select" id="buyer-type">
                            <option value="empty">Please select</option>
                            <option value="ftb">First time buyer</option>
                            <option value="mover">Moving home</option>
                            <option value="remortgage">Remortgaging to us</option>
                          </select>
                        </div>
                        <div class="calc-field calc-field-extra-money">
                          <div class="txt-label "><label>Do you want to borrow more money as part of this mortgage?</label></div>              <div class="flat-checkbox flat-checkbox-2" data-name="extra" data-linkedres="res-mortgage-extra-money">
                            <span data-value="1">Yes</span>
                            <span data-value="0">No</span>
                          </div>
                        </div>
                        <div class="calc-field calc-field-applicants">
                          <div class="txt-label "><label>Are you interested in a single or joint mortgage?</label></div>            <div class="flat-checkbox flat-checkbox-2" data-name="applicants" data-linkedres="res-mortgage-applicants">
                            <span data-value="1">Single</span>
                            <span data-value="2">Joint</span>
                          </div>
                        </div>

                        <div class="calc-field calc-field-dependants">
                          <div class="txt-label "><label>How many people are you financially responsible for (excluding the applicants)?</label></div>            <div class="flat-checkbox flat-checkbox-4" data-name="dependants" data-linkedres="res-mortgage-dependants">
                            <span data-value="0">0</span>
                            <span data-value="1">1</span>
                            <span data-value="2">2</span>
                            <span data-value="3">3+</span>
                          </div>
                        </div>

                        <div class="calc-field calc-field-terms">
                          <div class="txt-label "><label>How long would you like your mortgage for?</label></div>            <select name="terms" id="mortgage-terms">
                            <option value="empty">Please select</option>
                            <option value="5">5 years</option>
                            <option value="6">6 years</option>
                            <option value="7">7 years</option>
                            <option value="8">8 years</option>
                            <option value="9">9 years</option>
                            <option value="10">10 years</option>
                            <option value="11">11 years</option>
                            <option value="12">12 years</option>
                            <option value="13">13 years</option>
                            <option value="14">14 years</option>
                            <option value="15">15 years</option>
                            <option value="16">16 years</option>
                            <option value="17">17 years</option>
                            <option value="18">18 years</option>
                            <option value="19">19 years</option>
                            <option value="20">20 years</option>
                            <option value="21">21 years</option>
                            <option value="22">22 years</option>
                            <option value="23">23 years</option>
                            <option value="24">24 years</option>
                            <option value="25">25 years</option>
                            <option value="26">26 years</option>
                            <option value="27">27 years</option>
                            <option value="28">28 years</option>
                            <option value="29">29 years</option>
                            <option value="30">30 years</option>
                            <option value="31">31 years</option>
                            <option value="32">32 years</option>
                            <option value="33">33 years</option>
                            <option value="34">34 years</option>
                            <option value="35">35 years</option>
                          </select>
                        </div>


                        <div class="calc-field calc-field-deposit">
                          <div class="amount-tooltip clearfix"><div class="amount-field-label"><label for="field-deposit">How much deposit/equity do you have?</label> <span class="tooltip_ico" aria-describedby="tooltip-field-deposit">help</span>  <div class="tooltip_txt" id="tooltip-field-deposit" aria-hidden="true"><p>Please enter the amount of deposit or equity you have. If you are moving or remortgaging, your equity is the value of your property less any mortgage balance outstanding on that property.</p>
                              </div></div><div class="form-type-numberfield form-item-submitted-deposit form-item">
                              <input id="field-deposit" class="form-control form-text form-number" type="number" name="submitted[deposit]" value="0" step="1" min="0" />
                            </div>
                          </div>          </div>

                        <div class="step-actions clearfix">
                          <a href="javascript:void(0)" class="btn btn-primary btn-sm disabled btn-next">Continue</a>
                        </div>

                      </div>

                      <div class="calculator-results-area" id="calculator-results-area">
                        <div class="content clearfix">
                          <div class="results-label">Summary</div>
                          <div class="result-section">
                            <h3>Your mortgage</h3>
                            <table border="0" width="100%" cellpadding="0" cellspacing="0">
                              <tr><th>Buyer type</th><td id="res-mortgage-buyer-type">-</td></tr>
                              <tr><th>Additional borrowing</th><td id="res-mortgage-extra-money">-</td></tr>
                              <tr><th>Mortgage type</th><td id="res-mortgage-applicants">-</td></tr>
                              <tr><th>Number of dependants</th><td id="res-mortgage-dependants">0</td></tr>
                              <tr><th>Mortgage term</th><td id="res-mortgage-terms">0 years</td></tr>
                              <tr><th>Deposit/equity</th><td id="res-mortgage-deposit">0</td></tr>
                            </table>
                          </div>
                          <div class="result-section result-income-section res-applicants-single">
                            <h3>Your income</h3>
                            <h4>Applicant 1</h4>
                            <div class="res-applicant-table">
                              <table border="0" width="100%" cellpadding="0" cellspacing="0">
                                <tr><th>Main income (gross)</th><td id="res-income-basic1">-</td></tr>
                                <tr><th>Bonus, commission or overtime</th><td id="res-income-guaranteed1">-</td></tr>
                                <tr><th>Other income (gross)</th><td id="res-income-regular1">-</td></tr>
                                <tr><th>Child maintenance/CSA payments</th><td id="res-income-csa1">-</td></tr>
                              </table>
                            </div>
                            <h4>Applicant 2</h4>
                            <div class="res-applicant-table res-applicant-2">
                              <table border="0" width="100%" cellpadding="0" cellspacing="0">
                                <tr><th>Main income (gross)</th><td id="res-income-basic2">-</td></tr>
                                <tr><th>Bonus, commission or overtime</th><td id="res-income-guaranteed2">-</td></tr>
                                <tr><th>Other income (gross)</th><td id="res-income-regular2">-</td></tr>
                                <tr><th>Child maintenance/CSA payments</th><td id="res-income-csa2">-</td></tr>
                              </table>
                            </div>
                          </div>
                          <div class="result-section">
                            <h3>Your commitments</h3>
                            <table border="0" width="100%" cellpadding="0" cellspacing="0">
                              <tr><th>Total outstanding credit card balances</th><td id="res-commitments-creditCard">-</td></tr>
                              <tr><th>Monthly payment of any outstanding loans</th><td id="res-commitments-loans">-</td></tr>
                              <tr><th>Other committed monthly spend</th><td id="res-commitments-outgoings">-</td></tr>
                            </table>
                          </div>
                        </div>
                      </div>
                    </div>

                    <div class="step_2 calc-step">
                      <div class="left-zone">

                        <ul class="nav nav-pills">
                          <li class="checked"><span class="no">1</span><span class="txt">Your<br />mortgage</span></li>
                          <li class="active"><span class="no">2</span><span class="txt">Your<br />income</span></li>
                          <li><span class="no">3</span><span class="txt">Your<br />commitments</span></li>
                          <li><span class="no">4</span><span class="txt">Your<br />results</span></li>
                        </ul>

                        <div class="top-help-txt">Please use the <span class="tooltip_ico" style="cursor:auto;"></span> buttons to guide you through what to put in each box.</div>


                        <h2>Applicant 1</h2>
                        <div class="applicant-1-fields">

                          <div class="calc-field calc-field-select calc-field-income-basic" id="income-basic-a1">
                            <div class="txt-label "><label>Your main annual income (gross)</label><div class="descr-txt">e.g. basic salary including any employed allowances such as car allowances, London weighting, net profit if self-employed or pension income if retired</div></div>
                            <div class="income-rows">
                              <div class="income-row">
                                <div class="form-type-numberfield form-item-income-amount form-item form-group">
                                  <input name="income-basic-a1-amount[]" class="form-control form-text form-number" type="number" value="0" step="1" min="0" placeholder="0.00">
                                </div>
                              </div>
                            </div>



                          </div>
                          <div class="calc-field calc-field-select calc-field-income-guaranteed" id="income-guaranteed-a1">
                            <div class="txt-label "><label>Annual bonus, commission or overtime income (gross)</label></div>
                            <div class="income-rows">
                              <div class="income-row">
                                <div class="form-type-numberfield form-item-income-amount form-item form-group">
                                  <input name="income-guaranteed-a1-amount[]" class="form-control form-text form-number" type="number" value="0" step="1" min="0" placeholder="0.00">
                                </div>
                              </div>
                            </div>



                          </div>
                          <div class="calc-field calc-field-select calc-field-income-regular" id="income-regular-a1">
                            <div class="txt-label "><label>Any other annual income (gross)</label><div class="descr-txt">e.g. child benefit or Tax Credits</div></div>
                            <div class="income-rows">
                              <div class="income-row">
                                <div class="form-type-numberfield form-item-income-amount form-item form-group">
                                  <input name="income-regular-a1-amount[]" class="form-control form-text form-number" type="number" value="0" step="1" min="0" placeholder="0.00">
                                </div>
                              </div>
                            </div>



                          </div>
                          <div class="calc-field calc-field-select calc-field-income-csa" id="income-csa-a1">
                            <div class="txt-label "><label>Child maintenance or CSA payments</label></div>
                            <div class="income-rows">
                              <div class="income-row">
                                <div class="form-type-numberfield form-item-income-amount form-item form-group">
                                  <input name="income-csa-a1-amount[]" class="form-control form-text form-number" type="number" value="0" step="1" min="0" placeholder="0.00">
                                </div>
                              </div>
                            </div>



                          </div>
                        </div>


                        <h2>Applicant 2</h2>
                        <div class="applicant-2-fields">

                          <div class="calc-field calc-field-select calc-field-income-basic" id="income-basic-a2">
                            <div class="txt-label "><label>Your main annual income (gross)</label><div class="descr-txt">e.g. basic salary including any employed allowances such as car allowances, London weighting, net profit if self-employed or pension income if retired</div></div>
                            <div class="income-rows">
                              <div class="income-row">
                                <div class="form-type-numberfield form-item-income-amount form-item form-group">
                                  <input name="income-basic-a2-amount[]" class="form-control form-text form-number" type="number" value="0" step="1" min="0" placeholder="0.00">
                                </div>
                              </div>
                            </div>



                          </div>
                          <div class="calc-field calc-field-select calc-field-income-guaranteed" id="income-guaranteed-a2">
                            <div class="txt-label "><label>Annual bonus, commission or overtime income (gross)</label></div>
                            <div class="income-rows">
                              <div class="income-row">
                                <div class="form-type-numberfield form-item-income-amount form-item form-group">
                                  <input name="income-guaranteed-a2-amount[]" class="form-control form-text form-number" type="number" value="0" step="1" min="0" placeholder="0.00">
                                </div>
                              </div>
                            </div>



                          </div>
                          <div class="calc-field calc-field-select calc-field-income-regular" id="income-regular-a2">
                            <div class="txt-label "><label>Any other annual income (gross)</label><div class="descr-txt">e.g. child benefit or Tax Credits</div></div>
                            <div class="income-rows">
                              <div class="income-row">
                                <div class="form-type-numberfield form-item-income-amount form-item form-group">
                                  <input name="income-regular-a2-amount[]" class="form-control form-text form-number" type="number" value="0" step="1" min="0" placeholder="0.00">
                                </div>
                              </div>
                            </div>



                          </div>
                          <div class="calc-field calc-field-select calc-field-income-csa" id="income-csa-a2">
                            <div class="txt-label "><label>Child maintenance or CSA payments</label></div>
                            <div class="income-rows">
                              <div class="income-row">
                                <div class="form-type-numberfield form-item-income-amount form-item form-group">
                                  <input name="income-csa-a2-amount[]" class="form-control form-text form-number" type="number" value="0" step="1" min="0" placeholder="0.00">
                                </div>
                              </div>
                            </div>



                          </div>
                        </div>


                        <div class="step-actions clearfix">
                          <a href="javascript:void(0)" class="btn btn-default btn-sm btn-back">Back</a>
                          <a href="javascript:void(0)" class="btn btn-primary btn-sm disabled btn-next">Continue</a>
                        </div>

                      </div>

                    </div>


                    <div class="step_3 calc-step">
                      <div class="left-zone">

                        <ul class="nav nav-pills">
                          <li class="checked"><span class="no">1</span><span class="txt">Your<br />mortgage</span></li>
                          <li class="checked"><span class="no">2</span><span class="txt">Your<br />income</span></li>
                          <li class="active"><span class="no">3</span><span class="txt">Your<br />commitments</span></li>
                          <li><span class="no">4</span><span class="txt">Your<br />results</span></li>
                        </ul>

                        <div class="top-help-txt">Please use the <span class="tooltip_ico" style="cursor:auto;"></span> buttons to guide you through what to put in each box.</div>

                        <div class="calc-field calc-field-creditCard" data-linkedres="res-commitments-creditCard" data-name="creditCard">
                          <div class="amount-tooltip clearfix"><div class="amount-field-label"><label for="field-commitments-creditCard">Your total outstanding credit card balances</label> <span class="tooltip_ico" aria-describedby="tooltip-field-commitments-creditCard">help</span>  <div class="tooltip_txt" id="tooltip-field-commitments-creditCard" aria-hidden="true"><p><span>Please enter your total monthly credit card(s) balance. Even if you pay it off in full each month you still need to enter this amount.</span></p>
                              </div></div><div class="form-type-numberfield form-item-submitted-commitments-creditCard form-item">
                              <input id="field-commitments-creditCard" class="form-control form-text form-number" type="number" name="submitted[commitments_creditCard]" value="0" step="1" min="0" />
                            </div>
                          </div>          </div>
                        <div class="calc-field calc-field-loans" data-linkedres="res-commitments-loans" data-name="loans">
                          <div class="amount-tooltip clearfix"><div class="amount-field-label"><label for="field-commitments-loans">Your monthly payments of any outstanding loans</label> <span class="tooltip_ico" aria-describedby="tooltip-field-commitments-loans">help</span>  <div class="tooltip_txt" id="tooltip-field-commitments-loans" aria-hidden="true"><p>Please enter your total monthly payments for any outstanding loans, hire purchase or credit agreements. If you are moving home or remortgaging to us from another lender, then you should not include your current monthly mortgage payment.</p>
                              </div><div class="descr-txt">(excluding credit cards)</div></div><div class="form-type-numberfield form-item-submitted-commitments-loans form-item">
                              <input id="field-commitments-loans" class="form-control form-text form-number" type="number" name="submitted[commitments_loans]" value="0" step="1" min="0" />
                            </div>
                          </div>          </div>
                        <div class="calc-field calc-field-outgoings" data-linkedres="res-commitments-outgoings" data-name="outgoings">
                          <div class="amount-tooltip clearfix"><div class="amount-field-label"><label for="field-commitments-outgoings">Other committed monthly spend</label> <span class="tooltip_ico" aria-describedby="tooltip-field-commitments-outgoings">help</span>  <div class="tooltip_txt" id="tooltip-field-commitments-outgoings" aria-hidden="true"><p>Please enter your total monthly payments for things you’re committed to such as school fees or the costs of any other properties you may own. Don’t include personal or household spend as we’ll take averages into account when we consider lending to you.</p>
                              </div><div class="descr-txt">such as school fees (not everyday personal or household spending)</div></div><div class="form-type-numberfield form-item-submitted-commitments-outgoings form-item">
                              <input id="field-commitments-outgoings" class="form-control form-text form-number" type="number" name="submitted[commitments_outgoings]" value="0" step="1" min="0" />
                            </div>
                          </div>          </div>

                        <div class="step-actions clearfix">
                          <a href="javascript:void(0)" class="btn btn-default btn-sm btn-back">Back</a>
                          <a href="javascript:void(0)" class="btn btn-primary btn-sm btn-next">Continue</a>
                        </div>

                      </div>

                    </div>

                    <div class="step_4 calc-step">
                      <div class="left-zone">

                        <ul class="nav nav-pills">
                          <li class="checked"><span class="no">1</span><span class="txt">Your<br />mortgage</span></li>
                          <li class="checked"><span class="no">2</span><span class="txt">Your<br />income</span></li>
                          <li class="checked"><span class="no">3</span><span class="txt">Your<br />commitments</span></li>
                          <li class="active"><span class="no">4</span><span class="txt">Your<br />results</span></li>
                        </ul>

                        <div class="display-result">
                          <div class="result-loan-title">You could borrow <span id="result-loan"></span></div>

                          <div class="result-loan-text">
                            <div id="field-step-4-result" class="text richtext"><p style="">This amount is an indication of how much you could borrow based on a repayment mortgage. It does not constitute a mortgage offer. The actual amount you can borrow will be confirmed following a full mortgage application, property valuation and credit check.</p>
                            </div>            </div>
                        </div>

                        <div class="next-steps">
                          <h2>Next steps?</h2>
                          <div class="next-step-1">
                            <div id="field-next-step1" class="text richtext"><p><a href="http://www.santander.co.uk/info/mortgages/compare-our-mortgages" target="_blank">Compare our mortgages</a> and see how much it could cost each month.</p>
                            </div>              </div>
                          <div class="next-step-4">
                            <div id="field-next-step4" class="text richtext"><p>Get a decision in principle and then apply for a mortgage:</p>

                              <ul>
                                <li style="margin-left: 0.19in;"><a href="http://www.santander.co.uk/uk/mortgages/pre-apply"><u>online</u></a></li>
                                <li style="margin-left: 0.19in;">by phone by calling us on <strong>0800 068 6064</strong>. Lines are open 9am to 7pm Monday to Friday and 9am to 2pm Saturdays.</li>
                                <li style="margin-left: 0.19in;"><a href="https://branchlocator.santander.com/?view=gb&amp;defaultLanguage=en" target="_blank"><u>in branch</u></a></li>
                              </ul>
                            </div>              </div>
                        </div>


                        <div class="step-actions clearfix">
                          <a href="javascript:void(0)" class="btn btn-default btn-sm btn-back">Back</a>
                          <div class="clearfix"></div>
                          <a href="/info/mortgages/how-much-can-i-borrow?again=1" class="btn btn-default btn-sm btn-start-again">Start again</a>
                        </div>

                      </div>

                    </div>
                  </div>

                </div>

              </div>
            </div>
          </div>
          <div class="inner-wrapper below-calc-c"><div class="field-collection-container clearfix"><div class="field field-name-field-repr-example field-type-field-collection field-label-hidden">
                <div class="field-collection-view clearfix view-mode-full field-collection-view-final"></div>		  </div>
            </div></div></div><div class="container"><div class="inner-wrapper"><div class="field field-name-field-important-info field-type-text-long field-label-hidden text clearfix">
              <h3>Important information</h3>
              <h3>YOUR HOME MAY BE REPOSSESSED IF YOU DO NOT KEEP UP REPAYMENTS ON YOUR MORTGAGE.</h3>
              <p>All applications are subject to status and our lending criteria. This means that the amount we will lend you will depend on your individual circumstances, the type of property and the amount you borrow. For example, we may require a higher deposit if you are buying a flat or a new build property.</p>
            </div>
            <div class="field field-name-field-footer field-type-entityreference field-label-hidden">
              <div id="node-6" class="node node-footer clearfix">



                <div class="content">
                  <div class="field field-name-body field-type-text-with-summary field-label-hidden text clearfix">
                    <div class="footer-links"><span> </span><br /><h2 class="element-invisible">Footer links</h2>
                      <ul><li><a href="http://www.santander.co.uk/uk/about-santander-uk/about-us" target="_blank">About Santander</a> |</li>
                        <li><a href="http://www.santander.co.uk/uk/accessibility" target="_blank">Accessibility</a> |</li>
                        <li><a class="ui-link" href="http://www.santander.co.uk/uk/website-legal" target="_blank">Legal</a> |</li>
                        <li><a href="http://www.santander.co.uk/uk/security-privacy" target="_blank">Privacy</a></li>
                      </ul></div>
                    <div> </div>
                    <div>Santander UK plc. Registered Office: 2 Triton Square, Regent's Place, London, NW1 3AN, United Kingdom. Registered Number 2294747. Registered in England and Wales. <a href="http://www.santander.co.uk" target="_blank">www.santander.co.uk</a>. Telephone <strong>0800 389 7000</strong>. Calls may be recorded or monitored. Authorised by the Prudential Regulation Authority and regulated by the Financial Conduct Authority and the Prudential Regulation Authority. Our Financial Services Register number is 106054. You can check this on the Financial Services Register by visiting the FCA’s website <a href="http://www.fca.org.uk/register" target="_blank">www.fca.org.uk/register</a>. Santander and the flame logo are registered trademarks.<br /> </div>
                    <div> </div>
                  </div>
                </div>


              </div>
            </div>
          </div></div>  </div>
    </section>
  </div>
</div>
</body>
</html>
