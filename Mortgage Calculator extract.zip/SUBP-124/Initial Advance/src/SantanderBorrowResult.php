<?php

class SantanderBorrowResult {


  static function round_up($n, $d=0) {
    return round($n, $d);
  }


  /**
   * @var array
   */
  private $mortgage = array(
    'applicants' => 1,
    'buyers' => '',
    'dependants' => 0,
    'term' => 25,
    'deposit' => 0
  );

  /**
   * @var array
   */
  private $income = array(
    'basic' => array(
      'a1' => array('taxable' => 0),
      'a2' => array('taxable' => 0)
    ),
    'guaranteed' => array(
      'a1' => array('taxable' => 0, 'nonTaxable' => 0),
      'a2' => array('taxable' => 0, 'nonTaxable' => 0)
    ),
    'regular' => array(
      'a1' => array('taxable' => 0, 'nonTaxable' => 0),
      'a2' => array('taxable' => 0, 'nonTaxable' => 0)
    )
  );

  /**
   * @var array
   */
  private $commitments = array(
    'creditCard' => 0,
    'loans' => 0,
    'outgoings' => 0
  );

  /**
   * Set Params
   *
   * @param $data
   */
  public function setParams($data) {
    $this->mortgage['applicants'] = $data['applicants'];
    $this->mortgage['buyers'] = ($data['buyers'] == 'yes' || $data['buyers'] == '1') ? 'yes' : 'no';
    $this->mortgage['dependants'] = ($data['dependants'] == '+3') ? 3 : $data['dependants'];
    $this->mortgage['term'] = $data['term'];
    $this->mortgage['deposit'] = $data['deposit'];
    $this->mortgage['buyer_type'] = $data['buyer_type'];
    $this->mortgage['extra'] = $data['extra'];
    $this->income['basic']['a1']['taxable'] = $data['basicA1Taxable'];
    $this->income['basic']['a2']['taxable'] = $data['basicA2Taxable'];
    $this->income['guaranteed']['a1']['taxable'] = $data['guaranteedA1Taxable'];
    $this->income['guaranteed']['a1']['nonTaxable'] = $data['guaranteedA1NonTaxable'];
    $this->income['guaranteed']['a2']['taxable'] = $data['guaranteedA2Taxable'];
    $this->income['guaranteed']['a2']['nonTaxable'] = $data['guaranteedA2NonTaxable'];
    $this->income['regular']['a1']['taxable'] = $data['regularA1Taxable'];
    $this->income['regular']['a1']['nonTaxable'] = $data['regularA1NonTaxable'];
    $this->income['regular']['a2']['taxable'] = $data['regularA2Taxable'];
    $this->income['regular']['a2']['nonTaxable'] = $data['regularA2NonTaxable'];
    $this->commitments['creditCard'] = $data['creditCard'];
    $this->commitments['loans'] = $data['loans'];
    $this->commitments['outgoings'] = $data['outgoings'];
  }

  public function validate(&$data) {
    $error = false;

    $fields = array(
      'applicants' => array('required' => true),
      'buyers' => array('required' => true),
      'dependants' => array('required' => true),
      'dependants' => array('required' => true, 'type' => 'numeric', 'min' => 0, 'max' => 4),
      'term' => array('required' => true, 'type' => 'numeric', 'min' => 5, 'max' => 35),
      'deposit' => array('required' => true, 'type' => 'numeric', 'min' => 0),
      'basicA1Taxable' => array('required' => true, 'type' => 'numeric', 'min' => 0),
      'basicA2Taxable' => array('required' => true, 'type' => 'numeric', 'min' => 0),
      'guaranteedA1Taxable' => array('required' => true, 'type' => 'numeric', 'min' => 0),
      'guaranteedA1NonTaxable' => array('required' => true, 'type' => 'numeric', 'min' => 0),
      'guaranteedA2Taxable' => array('required' => true, 'type' => 'numeric', 'min' => 0),
      'guaranteedA2NonTaxable' => array('required' => true, 'type' => 'numeric', 'min' => 0),
      'regularA1Taxable' => array('required' => true, 'type' => 'numeric', 'min' => 0),
      'regularA1NonTaxable' => array('required' => true, 'type' => 'numeric', 'min' => 0),
      'regularA2Taxable' => array('required' => true, 'type' => 'numeric', 'min' => 0),
      'regularA2NonTaxable' => array('required' => true, 'type' => 'numeric', 'min' => 0),
      'creditCard' => array('required' => true, 'type' => 'numeric', 'min' => 0),
      'loans' => array('required' => true, 'type' => 'numeric', 'min' => 0),
      'outgoings' => array('required' => true, 'type' => 'numeric', 'min' => 0),
    );


    foreach($fields as $name => $fieldInfo) {
      if(!isset($data[$name]) && $fieldInfo['required']) {
        return false;
      }

      if(isset($fieldInfo['type']) && $fieldInfo['type'] == 'numeric') {
        $data[$name] = floatval($data[$name]);
        if(isset($fieldInfo['min']) && $data[$name] < $fieldInfo['min']) {
          return false;
        }
        if(isset($fieldInfo['max']) && $data[$name] > $fieldInfo['max']) {
          return false;
        }
      }
    }

    return true;
    /*
  'applicants' => 'required|in:single,joint',
  'buyers' => 'required|in:yes,no',
  'dependants' => 'required|in:0,1,2,+3',
  'term' => 'required|numeric|between:5,35',
  'deposit' => 'required|numeric|min:0',
  'basicA1Taxable' => 'required|numeric|min:0',
  'basicA2Taxable' => 'required|numeric|min:0',
  'guaranteedA1Taxable' => 'required|numeric|min:0',
  'guaranteedA1NonTaxable' => 'required|numeric|min:0',
  'guaranteedA2Taxable' => 'required|numeric|min:0',
  'guaranteedA2NonTaxable' => 'required|numeric|min:0',
  'regularA1Taxable' => 'required|numeric|min:0',
  'regularA1NonTaxable' => 'required|numeric|min:0',
  'regularA2Taxable' => 'required|numeric|min:0',
  'regularA2NonTaxable' => 'required|numeric|min:0',
  'creditCard' => 'required|numeric|min:0',
  'loans' => 'required|numeric|min:0',
  'outgoings' => 'required|numeric|min:0'
*/
  }

  public function calculate() {
    $i = $this->calculateIncome();
    $e = $this->calculateExpenditure($i);
    $c = $this->calculateCredit();
    $l = $this->calculateLoan($i, $e, $c);

    /*
    $fileHandle = fopen("test.log", "a");
    fwrite($fileHandle,   "MORTGAGE \n");
    fwrite($fileHandle, print_r($this->mortgage, TRUE) . "\n");
    fwrite($fileHandle,   "INCOME \n");
    fwrite($fileHandle, print_r($this->income, TRUE) . "\n");
    fclose($fileHandle);
  */

    return $l['loan'];
  }

  // Calculate Total NET monthly income
  private function calculateIncome() {
    $o = new SantanderBorrowResultIncome($this->income);
    return $o->getIncome();
  }

  // Calculate Expenditure (low/medium)
  private function calculateExpenditure($i) {
    $o = new SantanderBorrowResultExpenditure($this->mortgage, $this->income, $i);
    return $o->getExpenditure();
  }

  // Calculate credit commitments
  private function calculateCredit() {
    $o = new SantanderBorrowResultCredit($this->commitments);
    return $o->getCredit();
  }

  // Calculate max loan
  private function calculateLoan($i, $e, $c) {
    $o = new SantanderBorrowResultLoan($this->mortgage, $this->income, $this->commitments, $i, $e, $c);
    return $o->getLoan();
  }

}

?>