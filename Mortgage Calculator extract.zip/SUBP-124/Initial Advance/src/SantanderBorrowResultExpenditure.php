<?php

class SantanderBorrowResultExpenditure {

  private $quintiles = array(
    'Q1' => array(
      'without' => array(
        'lower' => 0,
        'upper' => 987
      ),
      'with' => array(
        'lower' => 0,
        'upper' => 814
      )
    ),
    'Q2' => array(
      'without' => array(
        'lower' => 988,
        'upper' => 1865
      ),
      'with' => array(
        'lower' => 815,
        'upper' => 1550
      )
    ),
    'Q3' => array(
      'without' => array(
        'lower' => 1866,
        'upper' => 2703
      ),
      'with' => array(
        'lower' => 1551,
        'upper' => 2317
      )
    ),
    'Q4' => array(
      'without' => array(
        'lower' => 2704,
        'upper' => 3699
      ),
      'with' => array(
        'lower' => 2318,
        'upper' => 3314
      )
    ),
    'Q5' => array(
      'without' => array(
        'lower' => 3700,
        'upper' => 5727
      ),
      'with' => array(
        'lower' => 3315,
        'upper' => 5242
      )
    ),
    'Q6' => array(
      'without' => array(
        'lower' => 5728,
        'upper' => 7030
      ),
      'with' => array(
        'lower' => 5243,
        'upper' => 7030
      )
    ),
    'Q7' => array(
      'without' => array(
        'lower' => 7031,
        'upper' => 11897
      ),
      'with' => array(
        'lower' => 7031,
        'upper' => 11897
      )
    ),
    'Q8' => array(
      'without' => array(
        'lower' => 11898,
        'upper' => 11898
      ),
      'with' => array(
        'lower' => 11898,
        'upper' => 11898
      )
    )
  );

  private $rates = array(
    '1_0_Q1' => array(
      'min' => 637,
      'max' => 637
    ),
    '1_1_Q1' => array(
      'min' => 678,
      'max' => 678
    ),
    '1_2_Q1' => array(
      'min' => 719,
      'max' => 719
    ),
    '1_3+_Q1' => array(
      'min' => 778,
      'max' => 778
    ),
    '1_0_Q2' => array(
      'min' => 637,
      'max' => 839
    ),
    '1_1_Q2' => array(
      'min' => 678,
      'max' => 827
    ),
    '1_2_Q2' => array(
      'min' => 719,
      'max' => 870
    ),
    '1_3+_Q2' => array(
      'min' => 778,
      'max' => 930
    ),
    '1_0_Q3' => array(
      'min' => 839,
      'max' => 917
    ),
    '1_1_Q3' => array(
      'min' => 827,
      'max' => 952
    ),
    '1_2_Q3' => array(
      'min' => 870,
      'max' => 1042
    ),
    '1_3+_Q3' => array(
      'min' => 930,
      'max' => 1105
    ),
    '1_0_Q4' => array(
      'min' => 917,
      'max' => 977
    ),
    '1_1_Q4' => array(
      'min' => 952,
      'max' => 1008
    ),
    '1_2_Q4' => array(
      'min' => 1042,
      'max' => 1092
    ),
    '1_3+_Q4' => array(
      'min' => 1105,
      'max' => 1153
    ),
    '1_0_Q5' => array(
      'min' => 977,
      'max' => 1051
    ),
    '1_1_Q5' => array(
      'min' => 1008,
      'max' => 1116
    ),
    '1_2_Q5' => array(
      'min' => 1092,
      'max' => 1252
    ),
    '1_3+_Q5' => array(
      'min' => 1153,
      'max' => 1349
    ),
    '1_0_Q6' => array(
      'min' => 1051,
      'max' => 1150
    ),
    '1_1_Q6' => array(
      'min' => 1116,
      'max' => 1318
    ),
    '1_2_Q6' => array(
      'min' => 1252,
      'max' => 1479
    ),
    '1_3+_Q6' => array(
      'min' => 1349,
      'max' => 1593
    ),
    '1_0_Q7' => array(
      'min' => 1150,
      'max' => 1509
    ),
    '1_1_Q7' => array(
      'min' => 1318,
      'max' => 1730
    ),
    '1_2_Q7' => array(
      'min' => 1479,
      'max' => 1941
    ),
    '1_3+_Q7' => array(
      'min' => 1593,
      'max' => 2091
    ),
    '1_0_Q8' => array(
      'min' => 1509,
      'max' => 1509
    ),
    '1_1_Q8' => array(
      'min' => 1730,
      'max' => 1730
    ),
    '1_2_Q8' => array(
      'min' => 1941,
      'max' => 1941
    ),
    '1_3+_Q8' => array(
      'min' => 2091,
      'max' => 2091
    ),
    '2+_0_Q1' => array(
      'min' => 994,
      'max' => 994
    ),
    '2+_1_Q1' => array(
      'min' => 1041,
      'max' => 1041
    ),
    '2+_2_Q1' => array(
      'min' => 1081,
      'max' => 1081
    ),
    '2+_3+_Q1' => array(
      'min' => 1139,
      'max' => 1139
    ),
    '2+_0_Q2' => array(
      'min' => 994,
      'max' => 1127
    ),
    '2+_1_Q2' => array(
      'min' => 1041,
      'max' => 1110
    ),
    '2+_2_Q2' => array(
      'min' => 1081,
      'max' => 1196
    ),
    '2+_3+_Q2' => array(
      'min' => 1139,
      'max' => 1257
    ),
    '2+_0_Q3' => array(
      'min' => 1127,
      'max' => 1230
    ),
    '2+_1_Q3' => array(
      'min' => 1110,
      'max' => 1218
    ),
    '2+_2_Q3' => array(
      'min' => 1196,
      'max' => 1308
    ),
    '2+_3+_Q3' => array(
      'min' => 1257,
      'max' => 1371
    ),
    '2+_0_Q4' => array(
      'min' => 1230,
      'max' => 1372
    ),
    '2+_1_Q4' => array(
      'min' => 1218,
      'max' => 1352
    ),
    '2+_2_Q4' => array(
      'min' => 1308,
      'max' => 1436
    ),
    '2+_3+_Q4' => array(
      'min' => 1371,
      'max' => 1496
    ),
    '2+_0_Q5' => array(
      'min' => 1372,
      'max' => 1534
    ),
    '2+_1_Q5' => array(
      'min' => 1352,
      'max' => 1584
    ),
    '2+_2_Q5' => array(
      'min' => 1436,
      'max' => 1720
    ),
    '2+_3+_Q5' => array(
      'min' => 1496,
      'max' => 1817
    ),
    '2+_0_Q6' => array(
      'min' => 1534,
      'max' => 1763
    ),
    '2+_1_Q6' => array(
      'min' => 1584,
      'max' => 1870
    ),
    '2+_2_Q6' => array(
      'min' => 1720,
      'max' => 2031
    ),
    '2+_3+_Q6' => array(
      'min' => 1817,
      'max' => 2145
    ),
    '2+_0_Q7' => array(
      'min' => 1763,
      'max' => 2314
    ),
    '2+_1_Q7' => array(
      'min' => 1870,
      'max' => 2455
    ),
    '2+_2_Q7' => array(
      'min' => 2031,
      'max' => 2666
    ),
    '2+_3+_Q7' => array(
      'min' => 2145,
      'max' => 2816
    ),
    '2+_0_Q8' => array(
      'min' => 2314,
      'max' => 2314
    ),
    '2+_1_Q8' => array(
      'min' => 2455,
      'max' => 2455
    ),
    '2+_2_Q8' => array(
      'min' => 2666,
      'max' => 2666
    ),
    '2+_3+_Q8' => array(
      'min' => 2816,
      'max' => 2816
    )
  );

  private $scalingFactor = 1.00;

  // Mortgage

  private $mortgage = null;

  // Income

  private $income = null;

  // Income gross

  private $gross = null;

  // Expenditure

  private $expenditure = array(
    'gross' => 0, // ÂŁ
    'net' => 0, // ÂŁ
    'applicants' => 0,
    'dependants' => 0,
    'quintile' => 0,
    'concat' => '',
    'min' => 0, // ÂŁ
    'max' => 0, // ÂŁ
    'lowerLimit' => 0, // ÂŁ
    'upperLimit' => 0, // ÂŁ
    'quintileDifference' => 0, // ÂŁ
    'incomeLowerQuintileDifference' => 0, // ÂŁ
    'proportion' => 0, // %
    'difference' => 0, // ÂŁ
    'raw' => 0, // ÂŁ
    'final' => 0 // ÂŁ
  );

  // Constructor

  public function __construct(array $mortgage, array $income, array $gross) {
    $this->mortgage = $mortgage;
    $this->income = $income;
    $this->gross = $gross;
  }

  // Calculate low/medium expenditure

  public function getExpenditure() {
    // Calculate total joint gross income
    $this->expenditure['gross'] = $this->totalJointGrossIncome(array(
      $this->income['basic']['a1']['taxable'],
      $this->income['guaranteed']['a1']['taxable'],
      $this->income['guaranteed']['a1']['nonTaxable'],
      $this->income['regular']['a1']['taxable'],
      $this->income['regular']['a1']['nonTaxable'],
      $this->income['basic']['a2']['taxable'],
      $this->income['guaranteed']['a2']['taxable'],
      $this->income['guaranteed']['a2']['nonTaxable'],
      $this->income['regular']['a2']['taxable'],
      $this->income['regular']['a2']['nonTaxable']
    ));
    // Calculate total joint net income
    $this->expenditure['net'] = $this->totalJointNetIncome(array(
      $this->gross['a1']['monthly']['total'],
      $this->gross['a2']['monthly']['total']
    ));
    // Calculate number of applicants
    $this->expenditure['applicants'] = $this->numberOfApplicants($this->mortgage['applicants']);
    // Calculate number of dependants
    $this->expenditure['dependants'] = $this->numberOfDependants($this->mortgage['dependants']);
    // Calculate income quintile
    $this->expenditure['quintile'] = $this->incomeQuintile();
    // Concat
    $this->expenditure['concat'] = $this->concat();
    // Calculate min/max expenditure
    $this->expenditure['min'] = $this->minMaxExpenditure($this->expenditure['applicants'], 'min');
    $this->expenditure['max'] = $this->minMaxExpenditure($this->expenditure['applicants'], 'max');
    // Calculate quintile lower/upper limit
    $this->expenditure['lowerLimit'] = $this->quintileLimit($this->expenditure['dependants'], 'lower');
    $this->expenditure['upperLimit'] = $this->quintileLimit($this->expenditure['dependants'], 'upper');
    // Calculate quintile differences
    $this->expenditure['quintileDifference'] = $this->quintileDifferences();
    // Calculate income to lower quintile difference
    $this->expenditure['incomeLowerQuintileDifference'] = $this->incomeLowerQuintileDifference();
    // Calculate proportion
    $this->expenditure['proportion'] = $this->proportion();
    // Calculate expenditure difference
    $this->expenditure['difference'] = $this->difference();
    // Calculate raw expenditure
    $this->expenditure['raw'] = $this->raw();
    // Calculate final expenditure
    $this->expenditure['final'] = $this->finalExpenditure();
    return $this->expenditure;
  }

  // Calculate total joint gross income

  public function totalJointGrossIncome(array $arr) {
    return array_sum($arr);
  }

  // Calculate total joint net income

  public function totalJointNetIncome(array $arr) {
    return array_sum($arr);
  }

  // Calculate number of applicants

  public function numberOfApplicants($a) {
    if ($a > 1) {
      return '2+';
    } else {
      return $a;
    }
  }

  // Calculate number of dependants

  public function numberOfDependants($a) {
    if ($a > 2) {
      return '3+';
    } else {
      return $a;
    }
  }

  // Calculate income quintile

  public function incomeQuintile() {
    $q = '';
    if ($this->expenditure['dependants'] == 0) {
      if ($this->expenditure['net'] > $this->quintiles['Q7']['without']['upper']) {
        $q = 'Q8';
      } else {
        if ($this->expenditure['net'] > $this->quintiles['Q6']['without']['upper']) {
          $q = 'Q7';
        } else {
          if ($this->expenditure['net'] > $this->quintiles['Q5']['without']['upper']) {
            $q = 'Q6';
          } else {
            if ($this->expenditure['net'] > $this->quintiles['Q4']['without']['upper']) {
              $q = 'Q5';
            } else {
              if ($this->expenditure['net'] > $this->quintiles['Q3']['without']['upper']) {
                $q = 'Q4';
              } else {
                if ($this->expenditure['net'] > $this->quintiles['Q2']['without']['upper']) {
                  $q = 'Q3';
                } else {
                  if ($this->expenditure['net'] > $this->quintiles['Q1']['without']['upper']) {
                    $q = 'Q2';
                  } else {
                    $q = 'Q1';
                  }
                }
              }
            }
          }
        }
      }
    } else {
      if ($this->expenditure['net'] > $this->quintiles['Q7']['with']['upper']) {
        $q = 'Q8';
      } else {
        if ($this->expenditure['net'] > $this->quintiles['Q6']['with']['upper']) {
          $q = 'Q7';
        } else {
          if ($this->expenditure['net'] > $this->quintiles['Q5']['with']['upper']) {
            $q = 'Q6';
          } else {
            if ($this->expenditure['net'] > $this->quintiles['Q4']['with']['upper']) {
              $q = 'Q5';
            } else {
              if ($this->expenditure['net'] > $this->quintiles['Q3']['with']['upper']) {
                $q = 'Q4';
              } else {
                if ($this->expenditure['net'] > $this->quintiles['Q2']['with']['upper']) {
                  $q = 'Q3';
                } else {
                  if ($this->expenditure['net'] > $this->quintiles['Q1']['with']['upper']) {
                    $q = 'Q2';
                  } else {
                    $q = 'Q1';
                  }
                }
              }
            }
          }
        }
      }
    }
    return $q;
  }

  // Concat

  public function concat() {
    return $this->expenditure['applicants'].'_'.$this->expenditure['dependants'].'_'.$this->expenditure['quintile'];
  }

  // Calculate min/max expenditure

  public function minMaxExpenditure($a, $b) {
    if ($a == 0) {
      return 0;
    } else {
      return $this->rates[$this->expenditure['concat']][$b];
    }
  }

  // Calculate quintile lower/upper limit

  public function quintileLimit($a, $b) {
    if ($a == 0) {
      return $this->quintiles[$this->expenditure['quintile']]['without'][$b];
    } else {
      return $this->quintiles[$this->expenditure['quintile']]['with'][$b];
    }
  }

  // Calculate quintile differences

  public function quintileDifferences() {
    return $this->expenditure['upperLimit'] - $this->expenditure['lowerLimit'];
  }

  // Calculate income to lower quintile difference

  public function incomeLowerQuintileDifference() {
    return $this->expenditure['net'] - $this->expenditure['lowerLimit'];
  }

  // Calculate proportion

  public function proportion() {
    return $this->expenditure['incomeLowerQuintileDifference'] / ($this->expenditure['quintileDifference'] + 1);
  }

  // Calculate expenditure difference

  public function difference() {
    return $this->expenditure['max'] - $this->expenditure['min'];
  }

  // Calculate raw expenditure

  public function raw() {
    return SantanderBorrowResult::round_up(array_sum(array(
      $this->expenditure['proportion'] * $this->expenditure['difference'],
      $this->expenditure['min']
    )));
  }

  // Calculate final expenditure

  public function finalExpenditure() {
    return $this->expenditure['raw'] *$this->scalingFactor;
  }

}

?>