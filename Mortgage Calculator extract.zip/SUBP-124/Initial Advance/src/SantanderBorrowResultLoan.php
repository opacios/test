<?php

class SantanderBorrowResultLoan {

  // LTV

  private $ltv = array(
    'low' => array(
      'rate' => 0.0675, // %
      'single' => 5,
      'joint' => 5,
      'ftb_rate' => 4.45
    ),
    'medium' => array(
      'rate' => 0.0675, // %
      'single' => 5,
      'joint' => 5,
      'ftb_rate' => 4.45
    ),
    'high' => array(
      'rate' => 0.0675, // %
      'single' => 5,
      'joint' => 5,
      'ftb_rate' => 4.45
    ),
    'higher' => array(
      'rate' => 0.0675, // %
      'single' => 4.45,
      'joint' => 4.45,
      'ftb_rate' => 4.45
    )
  );

  // Mortgage

  private $mortgage = null;

  // Income

  private $income = null;

  // Secondary Weighting

  private $secondaryWeighting = 0.65; // 65%

  // Commitments

  private $commitments = null;

  // Gross

  private $gross = null;

  // Expenditure

  private $expenditure = null;

  // Credit

  private $credit = null;

  // Loan

  private $loan = array(
    'allowable' => 0, // ÂŁ
    'disposable' => 0, // ÂŁ
    'ltv' => array(
      'low' => array(
        'affordable' => 0, // ÂŁ
        'multiple' => 0, // ÂŁ
        'ltv' => 0, // ÂŁ
        'restricted' => 0, // ÂŁ
        'percentage' => 0 // %
      ),
      'medium' => array(
        'affordable' => 0, // ÂŁ
        'multiple' => 0, // ÂŁ
        'ltv' => 0, // ÂŁ
        'restricted' => 0, // ÂŁ
        'percentage' => 0 // %
      ),
      'high' => array(
        'affordable' => 0, // ÂŁ
        'multiple' => 0, // ÂŁ
        'ltv' => 0, // ÂŁ
        'restricted' => 0, // ÂŁ
        'percentage' => 0 // %
      ),
      'higher' => array(
        'affordable' => 0, // ÂŁ
        'multiple' => 0, // ÂŁ
        'restricted' => 0, // ÂŁ
        'percentage' => 0 // %
      )
    ),
    'loan' => 0 // ÂŁ
  );

  // Constructor

  public function __construct($mortgage, $income, $commitments, $i, $e, $c) {
    $this->mortgage = $mortgage;
    $this->income = $income;
    $this->commitments = $commitments;
    $this->gross = $i;
    $this->expenditure = $e;
    $this->credit = $c;
  }

  // Calculate max loan

  public function getLoan()
  {
    $this->loan['allowable'] = $this->allowableIncome();
    $this->loan['disposable'] = $this->disposableIncome();

    $this->loan['ltv']['low']['affordable'] = $this->lowAffortable();
    $this->loan['ltv']['low']['multiple'] = $this->maxAmountMultiple('low');
    $this->loan['ltv']['low']['ltv'] = $this->lowMaxAmountLTV();
    $this->loan['ltv']['low']['restricted'] = $this->lowRestrictedAmount();
    $this->loan['ltv']['low']['percentage'] = $this->maxAmountLTVPercentage('low');

    $this->loan['ltv']['medium']['affordable'] = $this->mediumAffortable();
    $this->loan['ltv']['medium']['multiple'] = $this->maxAmountMultiple('medium');
    $this->loan['ltv']['medium']['ltv'] = $this->mediumMaxAmountLTV();
    $this->loan['ltv']['medium']['restricted'] = $this->mediumRestrictedAmount();
    $this->loan['ltv']['medium']['percentage'] = $this->maxAmountLTVPercentage('medium');

    $this->loan['ltv']['high']['affordable'] = $this->highAffortable();
    $this->loan['ltv']['high']['multiple'] = $this->maxAmountMultiple('high');
    $this->loan['ltv']['high']['ltv'] = $this->highMaxAmountLTV();
    $this->loan['ltv']['high']['restricted'] = $this->highRestrictedAmount();
    $this->loan['ltv']['high']['percentage'] = $this->maxAmountLTVPercentage('high');

    $this->loan['ltv']['higher']['affordable'] = $this->higherAffortable();
    $this->loan['ltv']['higher']['multiple'] = $this->maxAmountMultiple('higher');
    $this->loan['ltv']['higher']['restricted'] = $this->higherRestrictedAmount();
    $this->loan['ltv']['higher']['percentage'] = $this->maxAmountLTVPercentage('higher');

    $this->loan['loan'] = $this->maxLoanAmount();

    /*
    $fileHandle = fopen("test.log", "a");
    fwrite($fileHandle,   "\n\n LOAN \n");
    fwrite($fileHandle, print_r($this->loan, TRUE) . "\n");
*/

    return $this->loan;
  }

  // Calculate allowable income
  public function allowableIncome()
  {
    $sum1 = $this->income['basic']['a1']['taxable']
      + $this->income['basic']['a2']['taxable']
      + $this->income['guaranteed']['a1']['taxable']
      + $this->income['guaranteed']['a2']['taxable']
      + $this->income['guaranteed']['a1']['nonTaxable']
      + $this->income['guaranteed']['a2']['nonTaxable'];

    $sum2 = $this->income['regular']['a1']['taxable']
      + $this->income['regular']['a1']['nonTaxable']
      + $this->income['regular']['a2']['taxable']
      + $this->income['regular']['a2']['nonTaxable'];

    $final = $sum1 + $this->secondaryWeighting * $sum2;

    return $final;

  }

  // Calculate disposable income
  public function disposableIncome()
  {
    /*
    $fileHandle = fopen("test.log", "a");
    fwrite($fileHandle, '$this->grosstotalMonthly '.$this->gross['totalMonthly'].'  -  final:'.$this->expenditure['final'].'  - credit:'.$this->credit.' - outgoings:'.$this->commitments['outgoings']. "\n");
    fclose($fileHandle);
    */
    return $this->gross['totalMonthly'] - $this->expenditure['final'] - $this->credit - $this->commitments['outgoings'];
  }

  // Calculate low LTV max amount affordable
  public function lowAffortable()
  {
    return max(array(
      (
        $this->loan['disposable'] *
        (1 - pow((1 + ($this->ltv['low']['rate'] / 12)), (-1 * (12 * $this->mortgage['term']))))
      ) / ($this->ltv['low']['rate'] / 12)
    ));
  }

  // Calculate medium LTV max amount affordable
  public function mediumAffortable()
  {
    return max(array(
      (
        $this->loan['disposable'] *
        (1 - pow((1 + ($this->ltv['medium']['rate'] / 12)), (-1 * (12 * $this->mortgage['term']))))
      ) / ($this->ltv['medium']['rate'] / 12)
    ));
  }

  // Calculate high LTV max amount affordable
  public function highAffortable()
  {
    $affordable =  max(array(
      (
        $this->loan['disposable'] *
        (1 - pow((1 + ($this->ltv['high']['rate'] / 12)), (-1 * (12 * $this->mortgage['term']))))
      ) / ($this->ltv['high']['rate'] / 12)
    ));

    return $affordable;
  }

  // Calculate higher LTV max amount affordable
  public function higherAffortable()
  {
    $affordable = max(array(
      (
        $this->loan['disposable'] *
        (1 - pow((1 + ($this->ltv['higher']['rate'] / 12)), (-1 * (12 * $this->mortgage['term']))))
      ) / ($this->ltv['higher']['rate'] / 12)
    ));

    return $affordable;
  }

  // Calculate max amount multiple
  public function maxAmountMultiple($a)
  {
    if($this->mortgage['buyers'] == 'yes') {
      $maxAmount = $this->ltv[$a]['ftb_rate'] * $this->loan['allowable'];
    } else {
      if ($this->mortgage['applicants'] == 1) {
        $maxAmount = $this->ltv[$a]['single'] * $this->loan['allowable'];
      } else {
        $maxAmount = $this->ltv[$a]['joint'] * $this->loan['allowable'];
      }
    }

    return $maxAmount;
  }

  // Calculate low max amount LTV
  public function lowMaxAmountLTV()
  {
    return (0.75 / 0.25) * $this->mortgage['deposit'];
  }

  // Calculate medium max amount LTV
  public function mediumMaxAmountLTV()
  {
    return (0.85 / 0.15) * $this->mortgage['deposit'];
  }

  // Calculate high max amount LTV
  public function highMaxAmountLTV()
  {
    return (0.9 / 0.1) * $this->mortgage['deposit'];
  }

  // Calculate low restricted amount
  public function lowRestrictedAmount()
  {
    return min(array(
      $this->loan['ltv']['low']['affordable'],
      $this->loan['ltv']['low']['multiple'],
      $this->loan['ltv']['low']['ltv']
    ));
  }

  // Calculate medium restricted amount
  public function mediumRestrictedAmount()
  {
    return min(array(
      $this->loan['ltv']['medium']['affordable'],
      $this->loan['ltv']['medium']['multiple'],
      $this->loan['ltv']['medium']['ltv']
    ));
  }

  // Calculate high restricted amount
  public function highRestrictedAmount()
  {
    return min(array(
      $this->loan['ltv']['high']['affordable'],
      $this->loan['ltv']['high']['multiple'],
      $this->loan['ltv']['high']['ltv']
    ));
  }

  // Calculate higher restricted amount
  public function higherRestrictedAmount()
  {
    return min(array(
      $this->loan['ltv']['higher']['affordable'],
      $this->loan['ltv']['higher']['multiple']
    ));
  }

  // Calculate max amount LTV (percentage)
  public function maxAmountLTVPercentage($a)
  {
    if (($this->mortgage['deposit'] + $this->loan['ltv'][$a]['restricted']) == 0) {
      return '';
    }

    return $this->loan['ltv'][$a]['restricted'] / ($this->loan['ltv'][$a]['restricted'] + $this->mortgage['deposit']);
  }

  // Calculate maximum loan amount
  public function maxLoanAmount()
  {
    if ($this->mortgage['buyer_type'] == 'remortgage' && $this->mortgage['extra'] == 0) {
      return min(floor($this->loan['ltv']['low']['restricted']), $this->mortgage['deposit']);
    }
    if ($this->loan['ltv']['higher']['percentage'] > 0.9) {
      return floor($this->loan['ltv']['higher']['restricted']);
    }

    if ($this->loan['ltv']['high']['percentage'] > 0.85) {
      return floor($this->loan['ltv']['high']['restricted']);
    }

    if ($this->loan['ltv']['medium']['percentage'] > 0.75) {
      return floor($this->loan['ltv']['medium']['restricted']);
    }

    return floor($this->loan['ltv']['low']['restricted']);
  }
}

?>