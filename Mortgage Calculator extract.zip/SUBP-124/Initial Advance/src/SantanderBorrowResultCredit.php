<?php

class SantanderBorrowResultCredit {

  // Commitments
  private $commitments = null;

  // Credit
  private $credit = 0; // ÂŁ

  // Constructor
  public function __construct(array $commitments) {
    $this->commitments = $commitments;
  }

  // Calculate credit commitments

  public function getCredit() {
    $this->credit = $this->monthlyCreditCommitments();
    return $this->credit;
  }

  // Calculate credit commitments
  public function monthlyCreditCommitments() {
    return SantanderBorrowResult::round_up(
      array_sum(array(
        $this->commitments['loans'],
        0.03 * $this->commitments['creditCard']
      ))
    );
  }
}

?>